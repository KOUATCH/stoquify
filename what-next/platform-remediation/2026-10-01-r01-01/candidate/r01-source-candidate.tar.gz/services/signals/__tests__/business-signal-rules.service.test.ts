import type {
  BranchOperatingMetrics,
  CloseReadinessMetrics,
  InventoryLossMetrics,
  InventoryCashMetrics,
  PaymentTruthMetrics,
  SnapshotResult,
  TenantOperatingMetrics,
} from "@/services/snapshots/snapshot-contracts";

import {
  buildBusinessSignalsFromFacts,
  buildBusinessSignalsFromSnapshots,
} from "../business-signal-rules.service";

describe("Kontava business signal rules", () => {
  it.each([0, 1, 100])("does not infer dead stock from a quiet period with %s adjustments/transfers", activity => {
    const source = tenantOperatingSnapshot()
    const inventory: SnapshotResult<InventoryCashMetrics> = {
      ...source, kind: "inventory.cash", sourceModules: ["inventory"],
      metrics: { ...source.metrics.inventoryCash, trackedItemCount: 1, inventoryLevelCount: 1, inventoryValue: 2_000_000, periodTransactionCount: 0, periodAdjustmentCount: activity, periodTransferCount: activity },
    }
    expect(buildBusinessSignalsFromSnapshots({ organizationId: "org-1", snapshots: [inventory], now: source.generatedAt })).toEqual([])
    const signals = buildBusinessSignalsFromSnapshots({ organizationId: "org-1", snapshots: [{ ...inventory, metrics: { ...inventory.metrics, zeroStockLevelCount: 1 } }], now: source.generatedAt })
    expect(signals).toHaveLength(1)
    expect(signals[0]).toMatchObject({ signalType: "stockout_risk", requiredPermission: "inventory.items.read", actionPath: "/dashboard/inventory/items", sourceHash: inventory.sourceHash })
  })
  it.each([undefined, null, 0])("does not infer receiving delay from pending orders without a positive overdue count (%s)", overduePurchaseOrderCount => {
    for (const snapshot of [tenantOperatingSnapshot({ pendingPurchaseOrderCount: 99, overduePurchaseOrderCount }), branchOperatingSnapshot({ pendingPurchaseOrderCount: 99, overduePurchaseOrderCount })]) {
      expect(buildBusinessSignalsFromSnapshots({ organizationId: "org-1", snapshots: [snapshot], now: snapshot.generatedAt }).filter(signal => signal.signalType === "purchase_order_receiving_delay")).toEqual([])
    }
  })
  it("bases receiving severity on overdue counts and retains source evidence", () => {
    for (const snapshot of [tenantOperatingSnapshot({ pendingPurchaseOrderCount: 99, overduePurchaseOrderCount: 1 }), branchOperatingSnapshot({ pendingPurchaseOrderCount: 99, overduePurchaseOrderCount: 1 })]) {
      const signal = buildBusinessSignalsFromSnapshots({ organizationId: "org-1", snapshots: [snapshot], now: snapshot.generatedAt }).find(value => value.signalType === "purchase_order_receiving_delay")!
      expect(signal).toMatchObject({ severity: "medium", sourceHash: snapshot.sourceHash, payload: { pendingPurchaseOrderCount: 99, overduePurchaseOrderCount: 1 } })
      expect(signal.detail).toBe("1 pending purchase order(s) have passed their recorded expected delivery time.")
    }
  })
  it("dedupes repeated facts by stable key and keeps the strongest signal", () => {
    const signals = buildBusinessSignalsFromFacts(
      [
        {
          organizationId: "org-1",
          signalType: "open_payment_suspense",
          moduleSlug: "payment_reconciliation",
          sourceModule: "payments",
          subjectType: "payment.suspense",
          subjectId: "suspense-1",
          severity: "medium",
          payload: { amount: 250_000 },
        },
        {
          organizationId: "org-1",
          signalType: "open_payment_suspense",
          moduleSlug: "payment_reconciliation",
          sourceModule: "payments",
          subjectType: "payment.suspense",
          subjectId: "suspense-1",
          severity: "critical",
          payload: { amount: 1_500_000 },
        },
      ],
      { now: "2026-06-20T08:00:00.000Z" },
    );

    expect(signals).toHaveLength(1);
    expect(signals[0]).toMatchObject({
      severity: "critical",
      requiredPermission: "payments.reconciliation.read",
      assignedRole: "finance",
    });
  });

  it("redacts sensitive payload fields before returning signal payloads", () => {
    const [signal] = buildBusinessSignalsFromFacts(
      [
        {
          organizationId: "org-1",
          signalType: "duplicate_provider_reference",
          moduleSlug: "payment_reconciliation",
          sourceModule: "payments",
          subjectType: "provider.transaction",
          subjectId: "txn-1",
          payload: {
            providerReference: "MTN-MOMO-SECRET-123456",
            count: 2,
          },
          redactions: [
            {
              id: "provider-reference-redaction",
              field: "providerReference",
              reason:
                "Provider reference is masked unless reconciliation permission passes.",
              policy: "kontava-payment-provider-reference-mask-policy",
            },
          ],
        },
      ],
      { now: "2026-06-20T08:00:00.000Z" },
    );

    expect(signal.payload.providerReference).toBe("[REDACTED:SIGNAL]");
    expect(JSON.stringify(signal)).not.toContain("MTN-MOMO-SECRET-123456");
    expect(signal.redactions).toHaveLength(1);
  });

  it("creates actionable payment and close signals from snapshot metrics", () => {
    const paymentSnapshot: SnapshotResult<PaymentTruthMetrics> = {
      kind: "payment.truth",
      organizationId: "org-1",
      locationId: null,
      periodStart: "2026-06-01T00:00:00.000Z",
      periodEnd: "2026-06-20T00:00:00.000Z",
      status: "partial",
      uiState: "partial",
      evidenceGrade: "reconciled",
      freshness: {
        generatedAt: "2026-06-20T08:00:00.000Z",
        sourceMaxUpdatedAt: "2026-06-20T07:30:00.000Z",
        maxAgeMinutes: 1440,
        stale: false,
        staleReason: null,
      },
      sourceHash: "hash-payment",
      generatedAt: "2026-06-20T08:00:00.000Z",
      sourceModules: ["payments"],
      metrics: {
        providerAccountCount: 1,
        activeProviderAccountCount: 1,
        recentRunCount: 1,
        readyForSignoffCount: 0,
        signedRunCount: 0,
        openExceptionCount: 2,
        criticalExceptionCount: 1,
        openSuspenseCount: 3,
        openSuspenseAmount: 750_000,
        pendingTransactionCount: 4,
      },
      blockers: [],
      redactions: [],
    };
    const closeSnapshot: SnapshotResult<CloseReadinessMetrics> = {
      ...paymentSnapshot,
      kind: "close.readiness",
      uiState: "blocked",
      evidenceGrade: "blocked",
      sourceHash: "hash-close",
      sourceModules: ["close", "accounting"],
      metrics: {
        accountingPeriodCount: 1,
        openPeriodCount: 1,
        recentCloseRunCount: 1,
        certifiedCloseRunCount: 0,
        blockedCloseRunCount: 1,
        averageReadinessScore: 62,
        openFindingCount: 4,
        criticalOpenFindingCount: 1,
        unavailableEvidenceCount: 2,
      },
    };

    const signals = buildBusinessSignalsFromSnapshots({
      organizationId: "org-1",
      snapshots: [paymentSnapshot, closeSnapshot],
    });

    expect(signals).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          signalType: "open_payment_suspense",
          evidenceGrade: "reconciled",
          requiredPermission: "payments.reconciliation.read",
        }),
        expect.objectContaining({
          signalType: "close_blocker",
          severity: "critical",
          requiredPermission: "accounting.close.read",
          actionPath: "/dashboard/accounting/close",
        }),
      ]),
    );
  });

  it("creates redacted payroll exposure signals for active employee balance recovery", () => {
    const tenantSnapshot: SnapshotResult<TenantOperatingMetrics> = {
      kind: "tenant.operating",
      organizationId: "org-1",
      locationId: null,
      periodStart: "2026-06-01T00:00:00.000Z",
      periodEnd: "2026-06-20T00:00:00.000Z",
      status: "blocked",
      uiState: "blocked",
      evidenceGrade: "blocked",
      freshness: {
        generatedAt: "2026-06-20T08:00:00.000Z",
        sourceMaxUpdatedAt: "2026-06-20T07:30:00.000Z",
        maxAgeMinutes: 1440,
        stale: false,
        staleReason: null,
      },
      sourceHash: "hash-tenant",
      generatedAt: "2026-06-20T08:00:00.000Z",
      sourceModules: ["dashboard", "payroll", "accounting", "finance"],
      metrics: {
        activeLocationCount: 1,
        completedSalesCount: 0,
        completedSalesRevenue: 0,
        cashCollected: 0,
        pendingPurchaseOrderCount: 0,
        approvedOrPaidPayrollRunCount: 0,
        activeEmployeeBalanceCaseCount: 3,
        openEmployeeBalanceCaseCount: 2,
        partiallySettledEmployeeBalanceCaseCount: 1,
        employeeBalanceOutstandingAmount: 600000,
        periodEmployeeBalanceSettlementCount: 2,
        periodEmployeeBalanceSettlementAmount: 100000,
        postedJournalEntryCount: 1,
        sourceLinkCount: 1,
        paymentTruth: {
          providerAccountCount: 1,
          activeProviderAccountCount: 1,
          recentRunCount: 0,
          readyForSignoffCount: 0,
          signedRunCount: 0,
          openExceptionCount: 0,
          criticalExceptionCount: 0,
          openSuspenseCount: 0,
          openSuspenseAmount: 0,
          pendingTransactionCount: 0,
        },
        inventoryCash: {
          trackedItemCount: 0,
          inventoryLevelCount: 0,
          quantityOnHand: 0,
          quantityAvailable: 0,
          quantityReserved: 0,
          quantityInTransit: 0,
          quantityOnOrder: 0,
          inventoryValue: 0,
          zeroStockLevelCount: 0,
          negativeStockLevelCount: 0,
          periodTransactionCount: 0,
          periodAdjustmentCount: 0,
          periodTransferCount: 0,
        },
        closeReadiness: {
          accountingPeriodCount: 1,
          openPeriodCount: 1,
          recentCloseRunCount: 0,
          certifiedCloseRunCount: 0,
          blockedCloseRunCount: 0,
          averageReadinessScore: 80,
          openFindingCount: 0,
          criticalOpenFindingCount: 0,
          unavailableEvidenceCount: 0,
        },
        payrollFinanceForecast: payrollForecastMetrics(),
      },
      blockers: [],
      redactions: [],
    };

    const [signal] = buildBusinessSignalsFromSnapshots({
      organizationId: "org-1",
      snapshots: [tenantSnapshot],
      now: "2026-06-20T08:00:00.000Z",
    });

    expect(signal).toMatchObject({
      signalType: "payroll_exposure",
      subjectType: "payroll.employee_balance",
      subjectId: "active-employee-balance",
      severity: "high",
      actionPath: "/dashboard/payroll/payments",
      requiredPermission: "payments.reconciliation.read",
      additionalRequiredPermissions: ["payroll.command.read"],
      payload: expect.objectContaining({
        activeEmployeeBalanceCaseCount: 3,
        employeeBalanceOutstandingAmount: 600000,
        personLevelAmounts: "[REDACTED:SIGNAL]",
      }),
    });
  });

  it("creates payroll forecast proof signals with payroll-specific blockers and redacted payloads", () => {
    const tenantSnapshot = tenantOperatingSnapshot(
      {
        approvedOrPaidPayrollRunCount: 0,
        payrollFinanceForecast: payrollForecastMetrics({
          status: "NON_AUTHORITATIVE",
          authoritative: false,
          reasonCode: "PAYROLL_FORECAST_PROOF_INCOMPLETE",
          message:
            "Upcoming payroll finance forecasts are withheld because payroll proof is incomplete.",
          upcomingNetPayAmount: 0,
          upcomingStatutoryLiabilityAmount: 0,
          totalUpcomingAmount: 0,
          blockerCodes: ["PAYROLL_FORECAST_PAYMENT_EVIDENCE_MISSING"],
        }),
      },
      {
        status: "blocked",
        uiState: "blocked",
        evidenceGrade: "blocked",
        blockers: [
          {
            id: "tenant-payroll-finance-forecast-payment-evidence-missing",
            severity: "high",
            gate: "payroll_finance_forecast",
            title: "Payroll payment proof is missing",
            detail:
              "Upcoming net-pay forecast is withheld until released payment batches include immutable payment and ledger evidence.",
            sourceTables: ["payroll_runs", "payroll_payment_batches"],
          },
          {
            id: "tenant-unrelated-close-blocker",
            severity: "high",
            gate: "close_readiness",
            title: "Close blocker",
            detail: "Close is blocked.",
            sourceTables: ["close_runs"],
          },
        ],
      },
    );

    const [signal] = buildBusinessSignalsFromSnapshots({
      organizationId: "org-1",
      snapshots: [tenantSnapshot],
      now: "2026-06-20T08:00:00.000Z",
    });

    expect(signal).toMatchObject({
      signalType: "payroll_exposure",
      title: "Payroll forecast proof is blocked",
      subjectType: "payroll.forecast",
      subjectId: "payroll-finance-forecast",
      severity: "high",
      evidenceGrade: "blocked",
      actionPath: "/dashboard/payroll/payments",
      requiredPermission: "payments.reconciliation.read",
      additionalRequiredPermissions: ["payroll.command.read"],
      blockers: [expect.objectContaining({ gate: "payroll_finance_forecast" })],
      payload: expect.objectContaining({
        blockerCodes: ["PAYROLL_FORECAST_PAYMENT_EVIDENCE_MISSING"],
        totalUpcomingAmount: 0,
        personLevelAmounts: "[REDACTED:SIGNAL]",
      }),
    });
    expect(signal.blockers).toEqual(
      expect.not.arrayContaining([
        expect.objectContaining({ gate: "close_readiness" }),
      ]),
    );
  });

  it("creates redacted branch payroll allocation signals from branch operating snapshots", () => {
    const branchSnapshot = branchOperatingSnapshot(
      {
        completedSalesCount: 8,
        completedSalesRevenue: 500000,
        posShiftCount: 5,
        closedPosShiftCount: 4,
        payrollEmployeeAtLocationCount: 3,
        frozenAttendanceSnapshotCount: 0,
        approvedPayrollRunLineCount: 2,
        unallocatedPayrollRunLineCount: 1,
        payrollGrossAmount: 180000,
        payrollEmployerChargeAmount: 40000,
        payrollNetPayAmount: 140000,
        payrollAllocatedCostAmount: 220000,
        payrollProfitContribution: 280000,
      },
      {
        status: "partial",
        uiState: "partial",
        blockers: [
          {
            id: "branch-payroll-attendance-proof-missing",
            severity: "medium",
            gate: "branch_payroll_inputs",
            title: "POS shift evidence is not frozen for payroll",
            detail:
              "POS sessions exist, but payroll attendance proof is missing.",
            sourceTables: ["pos_sessions", "payroll_attendance_snapshots"],
          },
        ],
      },
    );

    const signals = buildBusinessSignalsFromSnapshots({
      organizationId: "org-1",
      snapshots: [branchSnapshot],
      now: "2026-06-20T08:00:00.000Z",
    });

    expect(signals).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          signalType: "payroll_exposure",
          title: "Branch payroll allocation proof needs review",
          subjectType: "payroll.branch_allocation",
          subjectId: "loc-1:payroll-allocation",
          actionPath: "/dashboard/payroll/runs",
          requiredPermission: "payroll.runs.review",
          blockers: [
            expect.objectContaining({ gate: "branch_payroll_inputs" }),
          ],
          payload: expect.objectContaining({
            payrollAllocatedCostAmount: 220000,
            payrollProfitContribution: 280000,
            personLevelAmounts: "[REDACTED:SIGNAL]",
          }),
        }),
      ]),
    );
  });

  it("creates a provenance-linked non-causal review signal from complete loss evidence", () => {
    const [signal] = buildBusinessSignalsFromSnapshots({
      organizationId: "org-1",
      snapshots: [inventoryLossSnapshot()],
      now: "2026-06-20T08:00:00.000Z",
    });
    const [updatedSignal] = buildBusinessSignalsFromSnapshots({
      organizationId: "org-1",
      snapshots: [
        inventoryLossSnapshot(
          {},
          {
            sourceHash: "hash-inventory-loss-updated",
            generatedAt: "2026-06-21T08:00:00.000Z",
          },
        ),
      ],
      now: "2026-06-21T08:00:00.000Z",
    });

    expect(signal).toMatchObject({
      signalType: "inventory_loss_review",
      moduleSlug: "inventory",
      sourceModule: "inventory",
      sourceSnapshotKind: "inventory.loss",
      sourceHash: "hash-inventory-loss",
      subjectType: "inventory.loss",
      subjectId: "loc-1:recorded-loss",
      severity: "medium",
      severityScore: 50,
      assignedRole: "manager",
      requiredPermission: "inventory.levels.read",
      actionPath: "/dashboard/inventory/loss-control",
      evidenceGrade: "operational",
      payload: {
        lossLineCount: 2,
        adjustmentCount: 1,
        totalLossValue: 250,
        currency: "XAF",
        countVarianceLineCount: 1,
        damagedLineCount: 1,
        expiredLineCount: 0,
        recordedTheftCategoryLineCount: 0,
        writeOffLineCount: 0,
        evidenceCoveragePercent: 100,
        valuationCoveragePercent: 100,
        approvalCoveragePercent: 100,
        missingEvidenceLineCount: 0,
        missingValuationLineCount: 0,
        missingApprovalAttributionLineCount: 0,
        sourceTruncated: false,
      },
    });
    expect(signal.detail).toContain("does not identify who caused the loss");
    expect(signal.redactions).toEqual([
      expect.objectContaining({
        policy: "INVENTORY_LOSS_EVIDENCE_REDACTION",
      }),
    ]);
    expect(updatedSignal.id).toBe(signal.id);
    expect(updatedSignal.dedupeKey).toBe(signal.dedupeKey);
    expect(updatedSignal.sourceHash).toBe("hash-inventory-loss-updated");
  });

  it.each([
    ["source truncation", { sourceTruncated: true }],
    ["missing proof", { missingEvidenceLineCount: 1 }],
    ["source-recorded theft category", { recordedTheftCategoryLineCount: 1 }],
    ["ten recorded lines", { lossLineCount: 10 }],
  ] satisfies Array<[string, Partial<InventoryLossMetrics>]>)(
    "raises %s to high-priority review without assigning blame",
    (label, metrics) => {
      const truncated = metrics.sourceTruncated === true;
      const blocker = {
        id: `inventory-loss-${label.replace(/[^a-z]+/g, "-")}`,
        severity: (truncated ? "high" : "medium") as "high" | "medium",
        gate: "inventory_loss_evidence",
        title: "Inventory loss evidence needs review",
        detail: "Recorded evidence is incomplete.",
        sourceTables: ["stock_adjustment_lines"],
      };
      const [signal] = buildBusinessSignalsFromSnapshots({
        organizationId: "org-1",
        snapshots: [
          inventoryLossSnapshot(metrics, {
            status: truncated ? "blocked" : "partial",
            uiState: truncated ? "blocked" : "partial",
            evidenceGrade: truncated ? "blocked" : "raw",
            blockers: [blocker],
          }),
        ],
        now: "2026-06-20T08:00:00.000Z",
      });

      expect(signal).toMatchObject({
        signalType: "inventory_loss_review",
        severity: "high",
        evidenceGrade: truncated ? "blocked" : "raw",
        blockers: [expect.objectContaining({ id: blocker.id })],
      });
      expect(signal.detail).toContain("does not identify who caused the loss");
    },
  );

  it("does not create a review signal for a complete zero-record snapshot", () => {
    const signals = buildBusinessSignalsFromSnapshots({
      organizationId: "org-1",
      snapshots: [
        inventoryLossSnapshot({
          lossLineCount: 0,
          adjustmentCount: 0,
          totalLossValue: 0,
          countVarianceLineCount: 0,
          damagedLineCount: 0,
          expiredLineCount: 0,
          recordedTheftCategoryLineCount: 0,
          writeOffLineCount: 0,
          evidenceCoveredLineCount: 0,
          valuationCoveredLineCount: 0,
          approvalAttributedLineCount: 0,
        }),
      ],
      now: "2026-06-20T08:00:00.000Z",
    });

    expect(signals).toEqual([]);
  });
});

function inventoryLossSnapshot(
  metricOverrides: Partial<InventoryLossMetrics> = {},
  snapshotOverrides: Partial<SnapshotResult<InventoryLossMetrics>> = {},
): SnapshotResult<InventoryLossMetrics> {
  return {
    kind: "inventory.loss",
    organizationId: "org-1",
    locationId: "loc-1",
    periodStart: "2026-06-01T00:00:00.000Z",
    periodEnd: "2026-06-20T23:59:59.999Z",
    status: "fresh",
    uiState: "redacted",
    evidenceGrade: "operational",
    freshness: {
      generatedAt: "2026-06-20T08:00:00.000Z",
      sourceMaxUpdatedAt: null,
      maxAgeMinutes: 1440,
      stale: false,
      staleReason: null,
    },
    sourceHash: "hash-inventory-loss",
    generatedAt: "2026-06-20T08:00:00.000Z",
    sourceModules: ["inventory"],
    metrics: {
      lossLineCount: 2,
      adjustmentCount: 1,
      totalLossValue: 250,
      currency: "XAF",
      countVarianceLineCount: 1,
      damagedLineCount: 1,
      expiredLineCount: 0,
      recordedTheftCategoryLineCount: 0,
      writeOffLineCount: 0,
      evidenceCoveredLineCount: 2,
      evidenceCoveragePercent: 100,
      valuationCoveredLineCount: 2,
      valuationCoveragePercent: 100,
      approvalAttributedLineCount: 2,
      approvalCoveragePercent: 100,
      missingEvidenceLineCount: 0,
      missingValuationLineCount: 0,
      missingApprovalAttributionLineCount: 0,
      sourceTruncated: false,
      ...metricOverrides,
    },
    blockers: [],
    redactions: [
      {
        id: "inventory-loss-evidence-hashes-redacted",
        field: "records.evidence.*Hash",
        reason: "Source evidence hashes remain server-side.",
        policy: "INVENTORY_LOSS_EVIDENCE_REDACTION",
      },
    ],
    ...snapshotOverrides,
  };
}

function branchOperatingSnapshot(
  metricOverrides: Partial<BranchOperatingMetrics> = {},
  snapshotOverrides: Partial<SnapshotResult<BranchOperatingMetrics>> = {},
): SnapshotResult<BranchOperatingMetrics> {
  return {
    kind: "branch.operating",
    organizationId: "org-1",
    locationId: "loc-1",
    periodStart: "2026-06-01T00:00:00.000Z",
    periodEnd: "2026-06-20T00:00:00.000Z",
    status: "fresh",
    uiState: "fresh",
    evidenceGrade: "operational",
    freshness: {
      generatedAt: "2026-06-20T08:00:00.000Z",
      sourceMaxUpdatedAt: "2026-06-20T07:30:00.000Z",
      maxAgeMinutes: 1440,
      stale: false,
      staleReason: null,
    },
    sourceHash: "hash-branch",
    generatedAt: "2026-06-20T08:00:00.000Z",
    sourceModules: ["dashboard", "sales", "pos", "payroll", "accounting"],
    metrics: {
      locationActive: true,
      completedSalesCount: 0,
      completedSalesRevenue: 0,
      cashCollected: 0,
      inventoryValue: 0,
      inventoryTransactionCount: 0,
      pendingPurchaseOrderCount: 0,
      openTransferCount: 0,
      postedJournalLineCount: 0,
      posShiftCount: 0,
      closedPosShiftCount: 0,
      payrollEmployeeAtLocationCount: 0,
      frozenAttendanceSnapshotCount: 0,
      approvedPayrollRunLineCount: 0,
      unallocatedPayrollRunLineCount: 0,
      payrollGrossAmount: 0,
      payrollEmployerChargeAmount: 0,
      payrollNetPayAmount: 0,
      payrollAllocatedCostAmount: 0,
      payrollProfitContribution: null,
      ...metricOverrides,
    },
    blockers: [],
    redactions: [],
    ...snapshotOverrides,
  };
}
function tenantOperatingSnapshot(
  metricOverrides: Partial<TenantOperatingMetrics> = {},
  snapshotOverrides: Partial<SnapshotResult<TenantOperatingMetrics>> = {},
): SnapshotResult<TenantOperatingMetrics> {
  return {
    kind: "tenant.operating",
    organizationId: "org-1",
    locationId: null,
    periodStart: "2026-06-01T00:00:00.000Z",
    periodEnd: "2026-06-20T00:00:00.000Z",
    status: "fresh",
    uiState: "fresh",
    evidenceGrade: "operational",
    freshness: {
      generatedAt: "2026-06-20T08:00:00.000Z",
      sourceMaxUpdatedAt: "2026-06-20T07:30:00.000Z",
      maxAgeMinutes: 1440,
      stale: false,
      staleReason: null,
    },
    sourceHash: "hash-tenant",
    generatedAt: "2026-06-20T08:00:00.000Z",
    sourceModules: ["dashboard", "payroll", "accounting", "finance"],
    metrics: {
      activeLocationCount: 1,
      completedSalesCount: 0,
      completedSalesRevenue: 0,
      cashCollected: 0,
      pendingPurchaseOrderCount: 0,
      approvedOrPaidPayrollRunCount: 1,
      activeEmployeeBalanceCaseCount: 0,
      openEmployeeBalanceCaseCount: 0,
      partiallySettledEmployeeBalanceCaseCount: 0,
      employeeBalanceOutstandingAmount: 0,
      periodEmployeeBalanceSettlementCount: 0,
      periodEmployeeBalanceSettlementAmount: 0,
      postedJournalEntryCount: 1,
      sourceLinkCount: 1,
      paymentTruth: {
        providerAccountCount: 1,
        activeProviderAccountCount: 1,
        recentRunCount: 0,
        readyForSignoffCount: 0,
        signedRunCount: 0,
        openExceptionCount: 0,
        criticalExceptionCount: 0,
        openSuspenseCount: 0,
        openSuspenseAmount: 0,
        pendingTransactionCount: 0,
      },
      inventoryCash: {
        trackedItemCount: 0,
        inventoryLevelCount: 0,
        quantityOnHand: 0,
        quantityAvailable: 0,
        quantityReserved: 0,
        quantityInTransit: 0,
        quantityOnOrder: 0,
        inventoryValue: 0,
        zeroStockLevelCount: 0,
        negativeStockLevelCount: 0,
        periodTransactionCount: 0,
        periodAdjustmentCount: 0,
        periodTransferCount: 0,
      },
      closeReadiness: {
        accountingPeriodCount: 1,
        openPeriodCount: 1,
        recentCloseRunCount: 0,
        certifiedCloseRunCount: 0,
        blockedCloseRunCount: 0,
        averageReadinessScore: 80,
        openFindingCount: 0,
        criticalOpenFindingCount: 0,
        unavailableEvidenceCount: 0,
      },
      payrollFinanceForecast: payrollForecastMetrics(),
      ...metricOverrides,
    },
    blockers: [],
    redactions: [],
    ...snapshotOverrides,
  };
}

function payrollForecastMetrics(
  overrides: Partial<TenantOperatingMetrics["payrollFinanceForecast"]> = {},
): TenantOperatingMetrics["payrollFinanceForecast"] {
  return {
    status: "AUTHORITATIVE",
    authoritative: true,
    reasonCode: "PAYROLL_FORECAST_SOURCE_LINKED",
    message: "Forecast is source linked.",
    horizonStart: "2026-06-20T00:00:00.000Z",
    horizonEnd: "2026-07-20T23:59:59.999Z",
    upcomingNetPayAmount: 350000,
    upcomingStatutoryLiabilityAmount: 90000,
    totalUpcomingAmount: 440000,
    payrollPeriodCount: 1,
    payrollRunCount: 1,
    paymentBatchCount: 1,
    declarationCount: 1,
    sourceLinkCount: 2,
    evidenceHashCount: 4,
    nextPayDate: "2026-06-30T00:00:00.000Z",
    nextDeclarationDueDate: "2026-07-15T00:00:00.000Z",
    personLevelAmountsRedacted: true,
    blockerCodes: [],
    ...overrides,
  };
}

it.each([1, 20])("does not infer payroll exposure from %i approved or completed runs alone", count => {
  const source = tenantOperatingSnapshot({ approvedOrPaidPayrollRunCount: count })
  const before = JSON.stringify(source)
  expect(buildBusinessSignalsFromSnapshots({ organizationId: source.organizationId, snapshots: [source], now: source.generatedAt })).toEqual([])
  expect(source.metrics.approvedOrPaidPayrollRunCount).toBe(count)
  expect(JSON.stringify(source)).toBe(before)
})


it.each([
  ["PAYROLL_FORECAST_DECLARATION_EVIDENCE_MISSING", "/dashboard/payroll/declarations", "payroll.command.read"],
  ["PAYROLL_FORECAST_PAYMENT_EVIDENCE_MISSING", "/dashboard/payroll/payments", "payments.reconciliation.read"],
  ["PAYROLL_FORECAST_PROVIDER_EVIDENCE_MISSING", "/dashboard/payroll/payments", "payments.reconciliation.read"],
  ["PAYROLL_FORECAST_REGISTER_EVIDENCE_MISSING", "/dashboard/payroll/register", "payroll.reports.read"],
])("links %s to the current destination read contract", (code, actionPath, requiredPermission) => {
  const source = tenantOperatingSnapshot({ approvedOrPaidPayrollRunCount: 0, payrollFinanceForecast: payrollForecastMetrics({ authoritative: false, blockerCodes: [code] }) })
  const signal = buildBusinessSignalsFromSnapshots({ organizationId: "org-1", snapshots: [source], now: source.generatedAt }).find(item => item.subjectType === "payroll.forecast")!
  expect(signal).toMatchObject({ actionPath, requiredPermission, additionalRequiredPermissions: ["payroll.command.read"] })
  const { payrollRouteByRoute } = require("@/app/[locale]/(dashboard)/dashboard/payroll/payroll-route-data-access")
  expect(payrollRouteByRoute[actionPath].permissions).toContain(requiredPermission)
})
