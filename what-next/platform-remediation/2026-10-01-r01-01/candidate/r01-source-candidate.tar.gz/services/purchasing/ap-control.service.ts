import { assertPaymentRequestApprovalTerms, readVerifiedPaymentApproval } from "./payment-request-evidence"
import { lockSupplierPaymentSources, readSupplierPaymentBalances } from "./supplier-payment-balance"
import { createHash } from "crypto"
import {
  AccountingPostingPurpose,
  AccountingSourceType,
  ExceptionSeverity,
  GoodsReceiptStatus,
  JournalEntryStatus,
  JournalType,
  LedgerEntryType,
  LedgerPostingBatchStatus,
  PaymentDirection,
  PaymentExceptionStatus,
  PaymentExceptionType,
  PaymentMethod,
  PaymentTransactionState,
  PostingRuleAmountSource,
  PostingRuleLineSide,
  Prisma,
  PurchaseOrderStatus,
  SupplierBankAccountStatus,
  SupplierBankChangeStatus,
  SupplierInvoiceStatus,
  SupplierInvoiceMatchExceptionStatus,
  SupplierPaymentStatus,
  ThreeWayMatchStatus,
} from "@prisma/client"

import { db } from "@/prisma/db"
import { invoicePreparationSourceHash } from "./invoice-source-evidence"
import { resolveInvoiceReceiptRecognition } from "./invoice-receipt-recognition"
import { netUninvoicedReceiptReturns } from "./receipt-invoice-capacity"
import { recordPostedJournalCloseInvalidationInTx } from "@/services/accounting/journal-close-invalidation.service"
import { createLedgerPostingBatch, linkAccountingSource } from "@/services/accounting/posting.service"
import { getOpenPeriodForDate } from "@/services/accounting/periods.service"
import { getActivePostingRule } from "@/services/accounting/posting-rules.service"
import { ApplicationError, BusinessRuleError, ConflictError, NotFoundError } from "@/services/_shared/action-errors"
import {
  auditSensitiveActionDecision,
  assertSensitiveActionAllowed,
  evaluateSensitiveAction,
  type SensitiveActionEvaluationInput,
} from "@/services/controls/sensitive-action.service"
import {
  hashBusinessPayload,
  markBusinessEventAppliedInTx,
  recordBusinessEventInTx,
} from "@/services/events/business-event.service"
import {
  resolveRegulatoryParameter,
  type RegulatoryResolutionResult,
} from "@/services/regulatory/regulatory-capability.service"

import {
  approveSupplierBankChangeInputSchema,
  approveSupplierInvoiceInputSchema,
  approveSupplierPaymentInputSchema,
  postSupplierInvoiceInputSchema,
  releaseSupplierPaymentInputSchema,
  requestSupplierInvoiceMatchExceptionInputSchema,
  requestSupplierBankChangeInputSchema,
  reviewSupplierInvoiceMatchExceptionInputSchema,
  type ApproveSupplierBankChangeInput,
  type ApproveSupplierInvoiceInput,
  type ApproveSupplierPaymentInput,
  type PostSupplierInvoiceInput,
  type ReleaseSupplierPaymentInput,
  type RequestSupplierInvoiceMatchExceptionInput,
  type RequestSupplierBankChangeInput,
  type ReviewSupplierInvoiceMatchExceptionInput,
} from "./ap-control.schemas"

type DbClient = typeof db | Prisma.TransactionClient

export const EXACT_THREE_WAY_MATCH_EXCEPTION_POLICY_VERSION = "EXACT_THREE_WAY_MATCH_EXCEPTION_V1"

type InvoiceLinePlan = {
  availableQuantity: Prisma.Decimal
  purchaseOrderLineId: string
  goodsReceiptLineId: string
  goodsReceiptId: string
  itemId: string
  description: string
  quantity: Prisma.Decimal
  unitCost: Prisma.Decimal
  taxRate: Prisma.Decimal
  taxAmount: Prisma.Decimal
  lineSubtotal: Prisma.Decimal
  lineTotal: Prisma.Decimal
  priceVariance: Prisma.Decimal
}

type LedgerBlockerInput = {
  organizationId: string
  periodId?: string | null
  sourceType: AccountingSourceType
  sourceId: string
  postingPurpose: AccountingPostingPurpose
  actorId?: string | null
  documentHash?: string | null
  blockerCode: string
  message: string
  metadata?: Prisma.InputJsonValue
}

type APCountryPackStatus = {
  countryPackStatus: "RESOLVED" | "MISSING_COUNTRY" | "UNRESOLVED"
  countryCode: string | null
  countryPackVersion: string | null
  countryPackResolutionHash: string | null
  taxTreatmentStatus: string
  withholdingTreatmentStatus: string
  operatorActionRequired: boolean
  errorCode?: string | null
  errorMessage?: string | null
}

export type APPostingStatus = {
  ledgerBatch: {
    id: string
    status?: LedgerPostingBatchStatus | null
    errorMessage?: string | null
  }
  ledgerStatus: "POSTED" | "BLOCKED_PENDING_RULES"
  blockerCode?: string | null
  blockerMessage?: string | null
  journalEntryId?: string | null
  accountingSourceLinkId?: string | null
}

export type APControlActorContext = {
  organizationId: string
  actorId: string
  actorPermissions: readonly string[]
  lastAuthAt?: Date | number | string | null
}

type PostingAmountContext = {
  sourceAmount: Prisma.Decimal
  netAmount: Prisma.Decimal
  grossAmount: Prisma.Decimal
  taxAmount: Prisma.Decimal
  costAmount?: Prisma.Decimal
  varianceAmount?: Prisma.Decimal
}

export type APWorkbenchData = {
  organizationId: string
  asOf: string
  counts: {
    postedInvoices: number
    paymentPendingInvoices: number
    matchExceptions: number
    pendingBankChanges: number
    releasedPayments: number
    ledgerBlockers: number
    reconciliationBlockers: number
  }
  queues: {
    recentInvoices: Array<{
      id: string
      invoiceNumber: string
      supplierName: string
      status: SupplierInvoiceStatus
      total: string
      amountPaid: string
      currency: string
      invoiceDate: string
      ledgerPostingBatchId: string | null
      ledgerStatus: string
      ledgerBlockerCode: string | null
      ledgerBlockerMessage: string | null
      countryPackStatus: string | null
      countryPackVersion: string | null
      countryPackResolutionHash: string | null
      taxTreatmentStatus: string | null
      withholdingTreatmentStatus: string | null
      operatorActionRequired: boolean
    }>
    pendingBankChanges: Array<{
      id: string
      supplierId: string
      supplierName: string
      requestedById: string
      requestedAt: string
      reason: string | null
      bankAccountId: string | null
    }>
    releasedPayments: Array<{
      id: string
      paymentNumber: string
      supplierName: string
      amount: string
      currency: string
      method: PaymentMethod
      paymentDate: string
      ledgerPostingBatchId: string | null
      postedBusinessEventId: string | null
      ledgerStatus: string
      ledgerBlockerCode: string | null
      ledgerBlockerMessage: string | null
      reconciliationStatus: string | null
      paymentTransactionId: string | null
      paymentExceptionId: string | null
      countryPackStatus: string | null
      withholdingTreatmentStatus: string | null
      operatorActionRequired: boolean
    }>
    ledgerBlockers: Array<{
      id: string
      sourceType: AccountingSourceType
      sourceId: string
      postingPurpose: AccountingPostingPurpose
      status: LedgerPostingBatchStatus
      errorMessage: string | null
      createdAt: string
    }>
  }
}

function hasTransaction(client: DbClient): client is typeof db {
  return typeof (client as typeof db).$transaction === "function"
}

async function inTransaction<T>(client: DbClient, work: (tx: Prisma.TransactionClient) => Promise<T>) {
  if (hasTransaction(client)) {
    return client.$transaction((tx) => work(tx))
  }

  return work(client as Prisma.TransactionClient)
}

function assertControlActorMatches(
  control: APControlActorContext,
  organizationId: string,
  actorIds: Array<string | null | undefined>,
) {
  if (control.organizationId !== organizationId) {
    throw new BusinessRuleError("Actor organization does not match the AP control tenant.")
  }

  if (actorIds.some((actorId) => actorId && actorId !== control.actorId)) {
    throw new BusinessRuleError("Authenticated actor does not match the AP approval context.")
  }
}

function sensitiveInput(
  control: APControlActorContext,
  input: Omit<SensitiveActionEvaluationInput, "actorId" | "organizationId" | "actorPermissions" | "lastAuthAt">,
): SensitiveActionEvaluationInput {
  return {
    ...input,
    actorId: control.actorId,
    organizationId: control.organizationId,
    actorPermissions: control.actorPermissions,
    lastAuthAt: control.lastAuthAt ?? Date.now(),
  }
}

async function auditDeniedSensitiveAction(client: DbClient, input: SensitiveActionEvaluationInput) {
  const decision = evaluateSensitiveAction(input)
  if (decision.allowed) return decision

  return inTransaction(client, async (tx) => {
    await auditSensitiveActionDecision(tx, decision)
    assertSensitiveActionAllowed(decision)
    return decision
  })
}

async function auditAllowedSensitiveAction(tx: Prisma.TransactionClient, input: SensitiveActionEvaluationInput) {
  const decision = evaluateSensitiveAction(input)
  await auditSensitiveActionDecision(tx, decision)
  return assertSensitiveActionAllowed(decision)
}

async function loadSupplierBankChangeApprovalSubject(
  client: DbClient,
  organizationId: string,
  changeRequestId: string,
) {
  return client.supplierBankChangeRequest.findFirst({
    where: {
      id: changeRequestId,
      organizationId,
    },
    select: {
      id: true,
      supplierId: true,
      requestedById: true,
    },
  })
}

async function loadSupplierPaymentControlSubject(client: DbClient, organizationId: string, supplierPaymentId: string) {
  return client.supplierPayment.findFirst({
    where: {
      id: supplierPaymentId,
      organizationId,
      deletedAt: null,
    },
    select: {
      id: true,
      supplierId: true,
      bankAccountId: true,
      requestedById: true,
      approvedById: true,
      status: true,
    },
  })
}

function decimal2(value: Prisma.Decimal.Value | null | undefined) {
  return new Prisma.Decimal(value ?? 0).toDecimalPlaces(2)
}

function decimal3(value: Prisma.Decimal.Value | null | undefined) {
  return new Prisma.Decimal(value ?? 0).toDecimalPlaces(3)
}

function parseDate(value: Date | string | undefined, fallback = new Date()) {
  if (!value) return fallback
  const parsed = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(parsed.getTime())) throw new BusinessRuleError("Invalid AP document date.")
  return parsed
}

function normalizeCurrency(currency?: string | null) {
  return (currency || "XAF").trim().toUpperCase()
}

function decimalString(value: Prisma.Decimal.Value | null | undefined) {
  return decimal2(value).toFixed(2)
}

function normalizeInvoiceNumber(value: string) {
  return value.trim().replace(/\s+/g, "").toUpperCase()
}

function compactDate(date: Date) {
  return date.toISOString().slice(0, 10).replace(/-/g, "")
}

function safeJson(value: unknown): Prisma.InputJsonValue {
  return value as Prisma.InputJsonValue
}

function prefixedHash(value: unknown) {
  return `sha256:${hashBusinessPayload(value)}`
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {}
}

function metadataString(value: unknown, key: string) {
  const entry = asRecord(value)[key]
  return typeof entry === "string" ? entry : null
}

function metadataBoolean(value: unknown, key: string) {
  const entry = asRecord(value)[key]
  return typeof entry === "boolean" ? entry : false
}

function assertIdempotencyPayloadMatches(
  metadata: unknown,
  requestPayloadHash: string | null,
  message: string,
  metadataKey = "idempotencyPayloadHash",
) {
  if (!requestPayloadHash) return
  const existingPayloadHash = metadataString(metadata, metadataKey)
  if (existingPayloadHash && existingPayloadHash !== requestPayloadHash) {
    throw new ConflictError(message)
  }
}

function normalizeCountryCode(value?: string | null) {
  const normalized = value?.trim().toUpperCase()
  if (!normalized) return null
  if (normalized === "CAMEROON") return "CM"
  return normalized.length === 2 ? normalized : null
}

function normalizeMappingKey(value?: string | null) {
  const trimmed = value?.trim()
  return trimmed ? trimmed.toUpperCase() : null
}

function conditionMatches(condition: Prisma.JsonValue | null | undefined, context: Record<string, unknown>) {
  if (!condition || typeof condition !== "object" || Array.isArray(condition)) return true

  return Object.entries(condition as Record<string, unknown>).every(([key, expected]) => {
    // Historical invoices had no recognition context. Keep their legacy rule
    // branch available without changing retained posting request hashes.
    const actual = key === "receiptRecognition" ? (context[key] ?? "LEGACY") : context[key]
    if (Array.isArray(expected)) return expected.includes(actual)
    return actual === expected
  })
}

function amountForSource(source: PostingRuleAmountSource, amounts: PostingAmountContext) {
  switch (source) {
    case PostingRuleAmountSource.FIXED:
      return new Prisma.Decimal(1)
    case PostingRuleAmountSource.SOURCE_AMOUNT:
      return amounts.sourceAmount
    case PostingRuleAmountSource.NET_AMOUNT:
      return amounts.netAmount
    case PostingRuleAmountSource.GROSS_AMOUNT:
      return amounts.grossAmount
    case PostingRuleAmountSource.TAX_AMOUNT:
      return amounts.taxAmount
    case PostingRuleAmountSource.COST_AMOUNT:
    case PostingRuleAmountSource.QUANTITY_COST:
      return amounts.costAmount ?? new Prisma.Decimal(0)
    case PostingRuleAmountSource.VARIANCE_AMOUNT:
      return amounts.varianceAmount ?? new Prisma.Decimal(0)
    default:
      return new Prisma.Decimal(0)
  }
}

function hashSecret(value?: string | null) {
  const normalized = value?.trim().replace(/\s+/g, "")
  if (!normalized) return null
  return createHash("sha256").update(normalized.toUpperCase()).digest("hex")
}

function maskSecret(value?: string | null) {
  const normalized = value?.trim().replace(/\s+/g, "")
  if (!normalized) return null
  if (normalized.length <= 4) return "****"
  return `${"*".repeat(Math.max(4, normalized.length - 4))}${normalized.slice(-4)}`
}

export function duplicateFingerprint(input: {
  organizationId: string
  supplierId: string
  invoiceNumber: string
  total: Prisma.Decimal
  currency: string
}) {
  return createHash("sha256")
    .update(
      [
        input.organizationId,
        input.supplierId,
        normalizeInvoiceNumber(input.invoiceNumber),
        input.total.toFixed(2),
        normalizeCurrency(input.currency),
      ].join("|"),
    )
    .digest("hex")
}

async function createLedgerBlocker(tx: Prisma.TransactionClient, input: LedgerBlockerInput) {
  const batch = await createLedgerPostingBatch(
    {
      organizationId: input.organizationId,
      periodId: input.periodId ?? null,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      postingPurpose: input.postingPurpose,
      idempotencyKey: `${input.sourceType}:${input.sourceId}:${input.postingPurpose}:blocked`,
      metadata: {
        blockerCode: input.blockerCode,
        documentHash: input.documentHash ?? null,
        ...(input.metadata && typeof input.metadata === "object" ? { details: input.metadata } : {}),
      },
    },
    tx,
  )

  const blocked = await tx.ledgerPostingBatch.update({
    where: { id: batch.id },
    data: {
      status: LedgerPostingBatchStatus.FAILED,
      errorMessage: input.message,
      metadata: {
        blockerCode: input.blockerCode,
        documentHash: input.documentHash ?? null,
        apPostingRequestHash: metadataString(input.metadata, "apPostingRequestHash"),
        details: input.metadata ?? null,
      },
    },
  })

  await tx.ledgerAuditEvent.create({
    data: {
      organizationId: input.organizationId,
      actorId: input.actorId ?? null,
      action: "PURCHASING_AP_LEDGER_BLOCKED",
      resourceType: "LedgerPostingBatch",
      resourceId: blocked.id,
      postingBatchId: blocked.id,
      message: input.message,
      metadata: {
        blockerCode: input.blockerCode,
        sourceType: input.sourceType,
        sourceId: input.sourceId,
        postingPurpose: input.postingPurpose,
        documentHash: input.documentHash ?? null,
      },
    },
  })

  return blocked
}

export async function resolveAPCountryPackStatus(
  tx: Prisma.TransactionClient,
  input: {
    organizationId: string
    documentDate: Date
    taxAmount?: Prisma.Decimal
    purpose: "SUPPLIER_INVOICE" | "SUPPLIER_PAYMENT"
  },
): Promise<APCountryPackStatus> {
  const organization = await tx.organization.findFirst({
    where: { id: input.organizationId, deletedAt: null },
    select: {
      country: true,
      accountingSettings: {
        select: {
          countryPack: true,
          taxRegime: true,
        },
      },
    },
  })

  const countryCode = normalizeCountryCode(organization?.country)
  if (!countryCode) {
    return {
      countryPackStatus: "MISSING_COUNTRY",
      countryCode: null,
      countryPackVersion: null,
      countryPackResolutionHash: null,
      taxTreatmentStatus: input.taxAmount?.gt(0) ? "UNVERIFIED_COUNTRY_MISSING" : "NO_INPUT_VAT_AMOUNT",
      withholdingTreatmentStatus: "UNVERIFIED_COUNTRY_MISSING",
      operatorActionRequired: input.taxAmount?.gt(0) ?? false,
      errorCode: "COUNTRY_MISSING",
      errorMessage: "Organization country is required before AP tax treatment can be certified.",
    }
  }

  let vatResolution: RegulatoryResolutionResult<number> | null = null
  try {
    vatResolution = resolveRegulatoryParameter<number>("taxes.vat.standardRateBps", {
      countryCode,
      date: input.documentDate,
      pinnedPackVersion: organization?.accountingSettings?.countryPack ?? undefined,
      purpose: `AP_${input.purpose}_INPUT_VAT`,
      entityProfile: {
        countryCode,
        taxRegime: organization?.accountingSettings?.taxRegime ?? null,
      },
    })
  } catch (error) {
    const regulatoryError = error as {
      regulatoryCode?: string
      message?: string
    }
    return {
      countryPackStatus: "UNRESOLVED",
      countryCode,
      countryPackVersion: null,
      countryPackResolutionHash: null,
      taxTreatmentStatus: input.taxAmount?.gt(0) ? "UNRESOLVED_INPUT_VAT" : "NO_INPUT_VAT_AMOUNT",
      withholdingTreatmentStatus: "UNRESOLVED_WITHHOLDING",
      operatorActionRequired: input.taxAmount?.gt(0) ?? false,
      errorCode: regulatoryError.regulatoryCode ?? "REGULATORY_RESOLUTION_FAILED",
      errorMessage: regulatoryError.message ?? "AP country-pack tax treatment could not be resolved.",
    }
  }

  let withholdingTreatmentStatus = "NOT_CONFIGURED"
  try {
    resolveRegulatoryParameter("taxes.withholding.supplierPayments", {
      countryCode,
      date: input.documentDate,
      pinnedPackVersion: organization?.accountingSettings?.countryPack ?? undefined,
      purpose: `AP_${input.purpose}_WITHHOLDING`,
      entityProfile: {
        countryCode,
        taxRegime: organization?.accountingSettings?.taxRegime ?? null,
      },
    })
    withholdingTreatmentStatus = "RESOLVED"
  } catch {
    withholdingTreatmentStatus = "NOT_CONFIGURED"
  }

  return {
    countryPackStatus: "RESOLVED",
    countryCode,
    countryPackVersion: vatResolution.packVersion,
    countryPackResolutionHash: vatResolution.resolutionHash,
    taxTreatmentStatus: input.taxAmount?.gt(0) ? "INPUT_VAT_PACK_RESOLVED" : "NO_INPUT_VAT_AMOUNT",
    withholdingTreatmentStatus,
    operatorActionRequired: false,
  }
}

type APLedgerPostingInput = Parameters<typeof writeAPLedgerPosting>[1]

function apPostingRequestHash(input: APLedgerPostingInput) {
  return prefixedHash({
    organizationId: input.organizationId, periodId: input.periodId,
    sourceType: input.sourceType, sourceId: input.sourceId, sourceNumber: input.sourceNumber,
    sourceDate: input.sourceDate.toISOString(), postingPurpose: input.postingPurpose,
    journalType: input.journalType, supplierId: input.supplierId, currency: input.currency,
    documentHash: input.documentHash ?? null,
    amounts: Object.fromEntries(Object.entries(input.amounts).sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => [key, new Prisma.Decimal(value).toString()])),
    conditionContext: input.conditionContext ?? {},
  })
}

export function apJournalEvidenceHash(entry: Prisma.JournalEntryGetPayload<{ include: { lines: true } }>) {
  return prefixedHash({
    id: entry.id, organizationId: entry.organizationId, postingBatchId: entry.postingBatchId,
    journalId: entry.journalId, periodId: entry.periodId, entryNumber: entry.entryNumber,
    entryDate: entry.entryDate.toISOString(), currency: entry.currency, reference: entry.reference,
    sourceType: entry.sourceType, sourceId: entry.sourceId, postingPurpose: entry.postingPurpose,
    postedAt: entry.postedAt?.toISOString(), postedById: entry.postedById,
    lines: [...entry.lines].sort((a, b) => a.lineNumber - b.lineNumber).map(line => ({
      id: line.id, organizationId: line.organizationId, accountId: line.accountId,
      lineNumber: line.lineNumber, debit: line.debit.toString(), credit: line.credit.toString(),
      currency: line.currency, exchangeRate: line.exchangeRate.toString(),
      baseDebit: line.baseDebit?.toString(), baseCredit: line.baseCredit?.toString(), supplierId: line.supplierId,
    })),
  })
}

// Internal domain kernel: callers remain responsible for current authority and
// approved source evidence. All effects must run in the caller's transaction.
export async function createAPLedgerPosting(tx: Prisma.TransactionClient, input: APLedgerPostingInput): Promise<APPostingStatus> {
  const lockKey = JSON.stringify(["ap-posting", input.organizationId, input.sourceType, input.sourceId, input.postingPurpose])
  await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended(${lockKey}, 0))::text`
  await tx.$queryRaw`SELECT id FROM ledger_posting_batches WHERE "organizationId" = ${input.organizationId} AND "sourceType"::text = ${input.sourceType} AND "sourceId" = ${input.sourceId} AND "postingPurpose"::text = ${input.postingPurpose} FOR UPDATE`
  const source = { sourceType: input.sourceType, sourceId: input.sourceId, postingPurpose: input.postingPurpose }
  const batches = await tx.ledgerPostingBatch.findMany({
    where: { organizationId: input.organizationId, OR: [source, { idempotencyKey: { in: [
      `${input.sourceType}:${input.sourceId}:${input.postingPurpose}:blocked`,
      `${input.sourceType}:${input.sourceId}:${input.postingPurpose}:posted`,
    ] } }] }, include: { sourceLinks: true },
  })
  const batch = batches[0]
  if (batches.length > 1 || (batch && (batch.sourceType !== input.sourceType || batch.sourceId !== input.sourceId || batch.postingPurpose !== input.postingPurpose || (batch.periodId && batch.periodId !== input.periodId)))) {
    throw new ConflictError("AP posting batch evidence conflicts with this source. Accounting review is required.")
  }
  const entries = await tx.journalEntry.findMany({
    where: { organizationId: input.organizationId, OR: [source, ...(batch ? [{ postingBatchId: batch.id }] : [])] },
    include: { lines: true },
  })
  const requestHash = apPostingRequestHash(input)
  if (batch?.status === LedgerPostingBatchStatus.POSTED) {
    const entry = entries[0], link = batch.sourceLinks[0]
    if (metadataString(batch.metadata, "apPostingRequestHash") !== requestHash || entries.length !== 1 ||
      !entry || entry.status !== JournalEntryStatus.POSTED || entry.postingBatchId !== batch.id ||
      entry.sourceType !== input.sourceType || entry.sourceId !== input.sourceId || entry.postingPurpose !== input.postingPurpose ||
      !batch.postedAt || !entry.postedAt || entry.reversedAt || entry.reversalOfEntryId ||
      metadataString(batch.metadata, "apJournalEvidenceHash") !== apJournalEvidenceHash(entry) ||
      batch.sourceLinks.length !== 1 || !link || link.organizationId !== input.organizationId ||
      link.journalEntryId !== entry.id || link.sourceType !== input.sourceType || link.sourceId !== input.sourceId ||
      link.sourceNumber !== input.sourceNumber || link.sourceDate?.getTime() !== input.sourceDate.getTime() ||
      metadataString(link.metadata, "documentHash") !== (input.documentHash ?? null)) {
      throw new ConflictError("AP posting evidence is incomplete or changed. Review the existing journal before retrying.")
    }
    return { ledgerBatch: batch, ledgerStatus: "POSTED", journalEntryId: entry.id, accountingSourceLinkId: link.id }
  }
  if (entries.length || (batch && (batch.sourceLinks.length || batch.postedAt || batch.reversedAt || batch.status !== LedgerPostingBatchStatus.FAILED))) {
    throw new ConflictError("AP posting has unresolved or reversed effects. Accounting review is required before recovery.")
  }
  const previousHash = batch && metadataString(batch.metadata, "apPostingRequestHash")
  if (batch && ((previousHash && previousHash !== requestHash) || metadataString(batch.metadata, "documentHash") !== (input.documentHash ?? null))) {
    throw new ConflictError("The blocked AP source evidence changed. Review it before recovery.")
  }
  await tx.$queryRaw`SELECT id FROM accounting_periods WHERE id = ${input.periodId} AND "organizationId" = ${input.organizationId} FOR SHARE`
  const period = await getOpenPeriodForDate(input.organizationId, input.sourceDate, tx)
  if (period.id !== input.periodId) throw new ConflictError("AP posting period does not match the effective source date.")
  return writeAPLedgerPosting(tx, { ...input, metadata: { ...input.metadata, apPostingRequestHash: requestHash } })
}

async function writeAPLedgerPosting(
  tx: Prisma.TransactionClient,
  input: {
    organizationId: string
    periodId: string
    sourceType: AccountingSourceType
    sourceId: string
    sourceNumber: string
    sourceDate: Date
    postingPurpose: AccountingPostingPurpose
    journalType: JournalType
    journalPrefix: "APINV" | "APPAY" | "APRET" | "APCR" | "APGR"
    actorId?: string | null
    supplierId: string
    currency: string
    memo: string
    documentHash?: string | null
    amounts: PostingAmountContext
    conditionContext?: Record<string, unknown>
    metadata?: Record<string, unknown>
    blockerCode: string
    blockerMessage: string
  },
): Promise<APPostingStatus> {
  const rule = await getActivePostingRule(
    input.organizationId,
    {
      sourceType: input.sourceType,
      postingPurpose: input.postingPurpose,
      effectiveAt: input.sourceDate,
    },
    tx,
  )

  if (!rule) {
    const ledgerBatch = await createLedgerBlocker(tx, {
      organizationId: input.organizationId,
      periodId: input.periodId,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      postingPurpose: input.postingPurpose,
      actorId: input.actorId,
      documentHash: input.documentHash,
      blockerCode: input.blockerCode,
      message: input.blockerMessage,
      metadata: safeJson(input.metadata ?? {}),
    })

    return {
      ledgerBatch,
      ledgerStatus: "BLOCKED_PENDING_RULES",
      blockerCode: input.blockerCode,
      blockerMessage: input.blockerMessage,
    }
  }

  const journal = await tx.journal.findFirst({
    where: {
      organizationId: input.organizationId,
      type: input.journalType,
      isDefault: true,
      isActive: true,
    },
    select: { id: true, code: true },
  })

  if (!journal) {
    const message = `AP posting requires an active default ${input.journalType} journal.`
    const ledgerBatch = await createLedgerBlocker(tx, {
      organizationId: input.organizationId,
      periodId: input.periodId,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      postingPurpose: input.postingPurpose,
      actorId: input.actorId,
      documentHash: input.documentHash,
      blockerCode: "AP_DEFAULT_JOURNAL_MISSING",
      message,
      metadata: safeJson({ ...input.metadata, journalType: input.journalType }),
    })

    return {
      ledgerBatch,
      ledgerStatus: "BLOCKED_PENDING_RULES",
      blockerCode: "AP_DEFAULT_JOURNAL_MISSING",
      blockerMessage: message,
    }
  }

  const mappingKeys = rule.lines.map((line) => normalizeMappingKey(line.mappingKey)).filter(Boolean) as string[]
  const mappedAccounts = mappingKeys.length
    ? await tx.chartOfAccount.findMany({
        where: {
          organizationId: input.organizationId,
          mappingKey: { in: Array.from(new Set(mappingKeys)) },
          deletedAt: null,
          isActive: true,
        },
        include: { _count: { select: { children: true } } },
      })
    : []
  const accountByMapping = new Map(mappedAccounts.map((account) => [normalizeMappingKey(account.mappingKey), account]))

  const postingLines = rule.lines
    .filter((line) => conditionMatches(line.condition, input.conditionContext ?? {}))
    .map((line) => {
      const account = line.account ?? accountByMapping.get(normalizeMappingKey(line.mappingKey))
      if (!account) {
        throw new BusinessRuleError(`Posting rule ${rule.code} line ${line.lineNumber} does not resolve to an account.`)
      }
      if (!account.isActive || account.deletedAt) {
        throw new BusinessRuleError(`Posting rule ${rule.code} account ${account.code} is not active.`)
      }
      const childCount =
        "_count" in account ? Number((account as { _count?: { children?: number } })._count?.children ?? 0) : 0
      if (childCount > 0) {
        throw new BusinessRuleError(`Posting rule ${rule.code} account ${account.code} must be a leaf account.`)
      }

      const multiplier = new Prisma.Decimal(line.multiplier ?? 1)
      const amount = amountForSource(line.amountSource, input.amounts).times(multiplier).toDecimalPlaces(2)
      if (amount.lt(0)) {
        throw new BusinessRuleError(`Posting rule ${rule.code} line ${line.lineNumber} produced a negative amount.`)
      }
      if (amount.eq(0)) return null

      return {
        accountId: account.id,
        lineNumber: line.lineNumber,
        description: line.description ?? input.memo,
        debit: line.side === PostingRuleLineSide.DEBIT ? amount : new Prisma.Decimal(0),
        credit: line.side === PostingRuleLineSide.CREDIT ? amount : new Prisma.Decimal(0),
        mappingKey: normalizeMappingKey(line.mappingKey),
        resolvedMappingKey: normalizeMappingKey(account.mappingKey),
        amountSource: line.amountSource,
        explicitNonStockTreatment: !!line.condition && typeof line.condition === "object" && !Array.isArray(line.condition) && line.condition.receiptResidualTreatment === "NON_STOCK",
      }
    })
    .filter(Boolean) as Array<{
    accountId: string
    lineNumber: number
    description: string
    debit: Prisma.Decimal
    credit: Prisma.Decimal
    mappingKey: string | null
    resolvedMappingKey: string | null
    amountSource: PostingRuleAmountSource
    explicitNonStockTreatment: boolean
  }>

  const debitTotal = postingLines
    .reduce((total, line) => total.plus(line.debit), new Prisma.Decimal(0))
    .toDecimalPlaces(2)
  const creditTotal = postingLines
    .reduce((total, line) => total.plus(line.credit), new Prisma.Decimal(0))
    .toDecimalPlaces(2)

  if (input.sourceType === AccountingSourceType.GOODS_RECEIPT) {
    const zero = new Prisma.Decimal(0)
    const cost = input.amounts.costAmount ?? input.amounts.sourceAmount
    const expected = new Map([
      ["INVENTORY", { debit: cost, credit: zero }],
      ["GRNI", { debit: zero, credit: cost }],
    ])
    const matches = input.postingPurpose === AccountingPostingPurpose.GOODS_RECEIPT && cost.gt(0) &&
      input.amounts.sourceAmount.eq(cost) && input.amounts.netAmount.eq(cost) &&
      input.amounts.grossAmount.eq(cost) && input.amounts.taxAmount.eq(0) &&
      postingLines.every(line => !!line.resolvedMappingKey && expected.has(line.resolvedMappingKey)) &&
      [...expected].every(([key, amount]) => {
        const lines = postingLines.filter(line => line.resolvedMappingKey === key)
        return lines.reduce((sum, line) => sum.plus(line.debit), zero).eq(amount.debit) &&
          lines.reduce((sum, line) => sum.plus(line.credit), zero).eq(amount.credit)
      })
    if (!matches) {
      const blockerCode = "GOODS_RECEIPT_RULE_REVIEW"
      const message = "Receipt rules must recognize the accepted inventory cost against the goods-received accrual. Review the resolved accounts and amounts before recovery."
      const ledgerBatch = await createLedgerBlocker(tx, {
        organizationId: input.organizationId, periodId: input.periodId, sourceType: input.sourceType,
        sourceId: input.sourceId, postingPurpose: input.postingPurpose, actorId: input.actorId,
        documentHash: input.documentHash, blockerCode, message,
        metadata: safeJson({ ...input.metadata, postingRuleId: rule.id, postingRuleCode: rule.code }),
      })
      return { ledgerBatch, ledgerStatus: "BLOCKED_PENDING_RULES", blockerCode, blockerMessage: message }
    }
  }

  if (input.sourceType === AccountingSourceType.PURCHASE_RETURN) {
    const zero = new Prisma.Decimal(0), cost = input.amounts.costAmount ?? zero
    const grni = input.amounts.varianceAmount ?? zero
    const expected = new Map([
      ["INVENTORY", { debit: zero, credit: cost }],
      ["SUPPLIER_RETURN_CLAIM", { debit: input.amounts.netAmount, credit: zero }],
      ["GRNI", { debit: grni, credit: zero }],
    ])
    const matches = input.postingPurpose === AccountingPostingPurpose.PURCHASE_RETURN &&
      input.conditionContext?.receiptReturnRecognition === "VERIFIED" &&
      typeof input.conditionContext.receiptReturnRecognitionHash === "string" &&
      input.conditionContext.receiptReturnRecognitionHash.length > 0 &&
      cost.gt(0) && input.amounts.netAmount.gte(0) && grni.gte(0) &&
      input.amounts.sourceAmount.eq(cost) && input.amounts.grossAmount.eq(cost) &&
      input.amounts.netAmount.plus(grni).eq(cost) && input.amounts.taxAmount.eq(0) &&
      postingLines.every(line => !!line.resolvedMappingKey && expected.has(line.resolvedMappingKey)) &&
      [...expected].every(([key, amount]) => {
        const lines = postingLines.filter(line => line.resolvedMappingKey === key)
        return lines.reduce((sum, line) => sum.plus(line.debit), zero).eq(amount.debit) &&
          lines.reduce((sum, line) => sum.plus(line.credit), zero).eq(amount.credit)
      })
    if (!matches) {
      const blockerCode = "PURCHASE_RETURN_RECOGNITION_RULE_REVIEW"
      const message = "Return rules must release only verified inventory cost, supplier claims and goods-received accruals. Review the source allocation and resolved accounts."
      const ledgerBatch = await createLedgerBlocker(tx, {
        organizationId: input.organizationId, periodId: input.periodId, sourceType: input.sourceType,
        sourceId: input.sourceId, postingPurpose: input.postingPurpose, actorId: input.actorId,
        documentHash: input.documentHash, blockerCode, message,
        metadata: safeJson({ ...input.metadata, postingRuleId: rule.id, postingRuleCode: rule.code }),
      })
      return { ledgerBatch, ledgerStatus: "BLOCKED_PENDING_RULES", blockerCode, blockerMessage: message }
    }
  }

  if (input.sourceType === AccountingSourceType.SUPPLIER_CREDIT_NOTE && input.conditionContext?.receiptCreditRecognition === "VERIFIED") {
    const zero = new Prisma.Decimal(0), claim = input.amounts.costAmount ?? zero
    const variance = input.amounts.varianceAmount ?? zero
    const difference = input.amounts.netAmount.minus(claim)
    const direction = difference.gte(0) ? "CREDIT" : "DEBIT"
    const expected = new Map([
      ["ACCOUNTS_PAYABLE", { debit: input.amounts.grossAmount, credit: zero }],
      ["SUPPLIER_RETURN_CLAIM", { debit: zero, credit: claim }],
      ["INPUT_VAT", { debit: zero, credit: input.amounts.taxAmount }],
      ["INVENTORY_VARIANCE", { debit: direction === "DEBIT" ? variance : zero, credit: direction === "CREDIT" ? variance : zero }],
    ])
    const matches = input.postingPurpose === AccountingPostingPurpose.SUPPLIER_CREDIT_NOTE &&
      typeof input.conditionContext.receiptCreditRecognitionHash === "string" && input.conditionContext.receiptCreditRecognitionHash.length > 0 &&
      input.conditionContext.receiptCreditVarianceDirection === direction && variance.eq(difference.abs()) &&
      input.amounts.netAmount.gte(0) && input.amounts.taxAmount.gte(0) && claim.gte(0) &&
      input.amounts.sourceAmount.eq(input.amounts.grossAmount) && input.amounts.netAmount.plus(input.amounts.taxAmount).eq(input.amounts.grossAmount) &&
      postingLines.every(line => !!line.resolvedMappingKey && expected.has(line.resolvedMappingKey)) &&
      [...expected].every(([key, amount]) => {
        const lines = postingLines.filter(line => line.resolvedMappingKey === key)
        return lines.reduce((sum, line) => sum.plus(line.debit), zero).eq(amount.debit) &&
          lines.reduce((sum, line) => sum.plus(line.credit), zero).eq(amount.credit)
      })
    if (!matches) {
      const blockerCode = "SUPPLIER_CREDIT_RECOGNITION_RULE_REVIEW"
      const message = "Supplier credit rules must release the verified payable, tax, return claim and allocated receipt rounding variance. Review the source allocation and resolved accounts."
      const ledgerBatch = await createLedgerBlocker(tx, {
        organizationId: input.organizationId, periodId: input.periodId, sourceType: input.sourceType,
        sourceId: input.sourceId, postingPurpose: input.postingPurpose, actorId: input.actorId,
        documentHash: input.documentHash, blockerCode, message,
        metadata: safeJson({ ...input.metadata, postingRuleId: rule.id, postingRuleCode: rule.code }),
      })
      return { ledgerBatch, ledgerStatus: "BLOCKED_PENDING_RULES", blockerCode, blockerMessage: message }
    }
  }

  if (input.sourceType === AccountingSourceType.SUPPLIER_INVOICE && input.conditionContext?.receiptRecognition === "ACCRUAL") {
    const zero = new Prisma.Decimal(0)
    const variance = input.amounts.varianceAmount ?? zero
    const nonStock = input.conditionContext.receiptResidualTreatment === "NON_STOCK"
    // Non-stock identifies the source, not its statutory classification. Only
    // an explicit tenant rule can choose its account; generic inventory recipes
    // must not silently capitalize the residual. Validate actual accounts again
    // so a stale direct account reference cannot evade tenant/leaf controls.
    const residualLines = nonStock ? postingLines.filter(line => line.explicitNonStockTreatment &&
      line.amountSource === PostingRuleAmountSource.SOURCE_AMOUNT && line.debit.gt(0) && line.credit.eq(0)) : []
    const residualAccounts = residualLines.length ? await tx.chartOfAccount.findMany({
      where: { organizationId: input.organizationId, id: { in: [...new Set(residualLines.map(line => line.accountId))] }, isActive: true, deletedAt: null },
      include: { _count: { select: { children: true } } },
    }) : []
    const protectedMappings = new Set(["INVENTORY", "GRNI", "INPUT_VAT", "ACCOUNTS_PAYABLE", "ACCOUNTS_RECEIVABLE", "INVENTORY_VARIANCE", "SUPPLIER_RETURN_CLAIM", "BANK", "CASH_ON_HAND", "MOBILE_MONEY_CLEARING", "CARD_CLEARING", "CHEQUE_CLEARING"])
    const residualValid = !nonStock || (
      input.amounts.sourceAmount.gte(0) &&
      residualLines.reduce((sum, line) => sum.plus(line.debit), zero).eq(input.amounts.sourceAmount) &&
      residualLines.every(line => {
        const account = residualAccounts.find(candidate => candidate.id === line.accountId)
        return !!account && account.organizationId === input.organizationId && account.isActive && !account.deletedAt && account._count.children === 0 &&
          !account.isControlAccount && (account.type === "ASSET" || account.type === "EXPENSE") && account.normalBalance === "DEBIT" &&
          (!account.currency || account.currency.trim().toUpperCase() === input.currency.trim().toUpperCase()) &&
          !protectedMappings.has(normalizeMappingKey(account.mappingKey) ?? "")
      })
    )
    const controlledLines = nonStock ? postingLines.filter(line => !residualLines.includes(line)) : postingLines
    const expected = new Map<string, { debit: Prisma.Decimal; credit: Prisma.Decimal }>([
      ["INVENTORY", { debit: nonStock ? zero : input.amounts.sourceAmount, credit: zero }],
      ["GRNI", { debit: input.amounts.costAmount ?? zero, credit: zero }],
      ["INPUT_VAT", { debit: input.amounts.taxAmount, credit: zero }],
      ["ACCOUNTS_PAYABLE", { debit: zero, credit: input.amounts.grossAmount }],
      ["INVENTORY_VARIANCE", {
        debit: input.conditionContext.receiptVarianceDirection === "DEBIT" ? variance : zero,
        credit: input.conditionContext.receiptVarianceDirection === "CREDIT" ? variance : zero,
      }],
    ])
    const matches = residualValid && controlledLines.every(line => !!line.resolvedMappingKey && expected.has(line.resolvedMappingKey)) &&
      [...expected].every(([key, amount]) => {
        const lines = controlledLines.filter(line => line.resolvedMappingKey === key)
        return lines.reduce((sum, line) => sum.plus(line.debit), zero).eq(amount.debit) &&
          lines.reduce((sum, line) => sum.plus(line.credit), zero).eq(amount.credit)
      })
    if (!matches) {
      const message = nonStock
        ? "Configure an explicit NON_STOCK source-amount debit to a tenant-owned active asset or expense leaf account compatible with the invoice currency and outside inventory, settlement and control accounts. Clear only the verified accrual, tax and price variance, then review and retry this invoice's accounting."
        : "Supplier invoice rules must clear the verified receipt accrual, retain only unrecognized inventory and account for the price variance. Review the rule before recovery."
      const blockerCode = nonStock ? "AP_NON_STOCK_TREATMENT_REVIEW" : "AP_RECEIPT_RECOGNITION_RULE_REVIEW"
      const ledgerBatch = await createLedgerBlocker(tx, {
        organizationId: input.organizationId, periodId: input.periodId, sourceType: input.sourceType,
        sourceId: input.sourceId, postingPurpose: input.postingPurpose, actorId: input.actorId,
        documentHash: input.documentHash, blockerCode, message,
        metadata: safeJson({ ...input.metadata, postingRuleId: rule.id, postingRuleCode: rule.code }),
      })
      return { ledgerBatch, ledgerStatus: "BLOCKED_PENDING_RULES", blockerCode, blockerMessage: message }
    }
  }

  if (postingLines.length < 2 || !debitTotal.eq(creditTotal) || debitTotal.lte(0)) {
    const message = `AP posting rule ${rule.code} did not produce a balanced non-zero journal entry.`
    const ledgerBatch = await createLedgerBlocker(tx, {
      organizationId: input.organizationId,
      periodId: input.periodId,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      postingPurpose: input.postingPurpose,
      actorId: input.actorId,
      documentHash: input.documentHash,
      blockerCode: "AP_POSTING_RULE_UNBALANCED",
      message,
      metadata: safeJson({
        ...input.metadata,
        postingRuleId: rule.id,
        postingRuleCode: rule.code,
        debitTotal: debitTotal.toFixed(2),
        creditTotal: creditTotal.toFixed(2),
      }),
    })

    return {
      ledgerBatch,
      ledgerStatus: "BLOCKED_PENDING_RULES",
      blockerCode: "AP_POSTING_RULE_UNBALANCED",
      blockerMessage: message,
    }
  }

  const ledgerBatch = await createLedgerPostingBatch(
    {
      organizationId: input.organizationId,
      periodId: input.periodId,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      postingPurpose: input.postingPurpose,
      idempotencyKey: `${input.sourceType}:${input.sourceId}:${input.postingPurpose}:posted`,
      metadata: safeJson({
        ...input.metadata,
        postingRuleId: rule.id,
        postingRuleCode: rule.code,
        documentHash: input.documentHash ?? null,
      }),
    },
    tx,
  )

  const now = new Date()
  const postedBatch = await tx.ledgerPostingBatch.update({
    where: { id: ledgerBatch.id },
    data: {
      status: LedgerPostingBatchStatus.POSTED,
      postedAt: now,
      errorMessage: null,
      metadata: safeJson({
        ...input.metadata,
        postingRuleId: rule.id,
        postingRuleCode: rule.code,
        debitTotal: debitTotal.toFixed(2),
        creditTotal: creditTotal.toFixed(2),
        documentHash: input.documentHash ?? null,
      }),
    },
  })

  const journalEntry = await tx.journalEntry.create({
    include: { lines: true },
    data: {
      organizationId: input.organizationId,
      journalId: journal.id,
      periodId: input.periodId,
      postingBatchId: postedBatch.id,
      entryNumber: await nextAPJournalEntryNumber(tx, input.organizationId, input.sourceDate, input.journalPrefix),
      entryDate: input.sourceDate,
      status: JournalEntryStatus.POSTED,
      currency: input.currency,
      memo: input.memo,
      reference: input.sourceNumber,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      postingPurpose: input.postingPurpose,
      postedAt: now,
      postedById: input.actorId ?? null,
      createdById: input.actorId ?? null,
      lines: {
        create: postingLines.map((line, index) => ({
          organizationId: input.organizationId,
          accountId: line.accountId,
          lineNumber: index + 1,
          description: line.description,
          debit: line.debit,
          credit: line.credit,
          currency: input.currency,
          exchangeRate: new Prisma.Decimal(1),
          baseDebit: line.debit,
          baseCredit: line.credit,
          supplierId: input.supplierId,
          metadata: safeJson({
            postingRuleId: rule.id,
            postingRuleCode: rule.code,
            postingRuleLineNumber: line.lineNumber,
            mappingKey: line.mappingKey,
            amountSource: line.amountSource,
          }),
        })),
      },
    },
  })

  const sourceLink = await linkAccountingSource(
    {
      organizationId: input.organizationId,
      postingBatchId: postedBatch.id,
      journalEntryId: journalEntry.id,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      sourceNumber: input.sourceNumber,
      sourceDate: input.sourceDate,
      metadata: safeJson({
        postingRuleId: rule.id,
        postingRuleCode: rule.code,
        documentHash: input.documentHash ?? null,
      }),
    },
    tx,
  )

  const verifiedBatch = await tx.ledgerPostingBatch.update({
    where: { id: postedBatch.id },
    data: { metadata: safeJson({ ...asRecord(postedBatch.metadata), apPostingRequestHash: input.metadata?.apPostingRequestHash, apJournalEvidenceHash: apJournalEvidenceHash(journalEntry) }) },
  })

  await tx.ledgerAuditEvent.create({
    data: {
      organizationId: input.organizationId,
      actorId: input.actorId ?? null,
      action: "PURCHASING_AP_LEDGER_POSTED",
      resourceType: "LedgerPostingBatch",
      resourceId: postedBatch.id,
      postingBatchId: postedBatch.id,
      journalEntryId: journalEntry.id,
      message: `AP ledger posting ${input.sourceNumber} posted with rule ${rule.code}.`,
      metadata: safeJson({
        sourceType: input.sourceType,
        sourceId: input.sourceId,
        postingPurpose: input.postingPurpose,
        postingRuleId: rule.id,
        postingRuleCode: rule.code,
        accountingSourceLinkId: sourceLink.id,
        debitTotal: debitTotal.toFixed(2),
        creditTotal: creditTotal.toFixed(2),
      }),
    },
  })

  await recordPostedJournalCloseInvalidationInTx(
    tx,
    input.organizationId,
    {
      journalEntryId: journalEntry.id,
      periodId: input.periodId,
      entryDate: input.sourceDate,
      correlationId: postedBatch.id,
      staleReason: "Purchasing/AP journal posting changed certified close evidence.",
    },
    {
      actorId: input.actorId,
      now,
    },
  )

  return {
    ledgerBatch: verifiedBatch,
    ledgerStatus: "POSTED",
    journalEntryId: journalEntry.id,
    accountingSourceLinkId: sourceLink.id,
  }
}

export type PurchaseCorrectionLedgerInput = {
  organizationId: string
  sourceType:
    | typeof AccountingSourceType.PURCHASE_RETURN
    | typeof AccountingSourceType.SUPPLIER_CREDIT_NOTE
  sourceId: string
  sourceNumber: string
  sourceDate: Date
  supplierId: string
  currency: string
  actorId?: string | null
  documentHash: string
  sourceAmount: Prisma.Decimal.Value
  netAmount: Prisma.Decimal.Value
  grossAmount: Prisma.Decimal.Value
  taxAmount: Prisma.Decimal.Value
  costAmount: Prisma.Decimal.Value
  varianceAmount?: Prisma.Decimal.Value
  metadata: Record<string, unknown>
  sourceReviewBlocker?: { code: string; message: string }
  receiptReturnRecognitionHash?: string
  receiptCreditRecognitionHash?: string
  receiptCreditVarianceDirection?: "DEBIT" | "CREDIT"
}

export async function postPurchaseCorrectionLedgerInTx(
  tx: Prisma.TransactionClient,
  input: PurchaseCorrectionLedgerInput,
): Promise<APPostingStatus> {
  const period = await getOpenPeriodForDate(input.organizationId, input.sourceDate, tx)
  const isReturn = input.sourceType === AccountingSourceType.PURCHASE_RETURN

  if (isReturn && (input.sourceReviewBlocker || !input.receiptReturnRecognitionHash)) {
    const blockerCode = input.sourceReviewBlocker?.code ?? "PURCHASE_RETURN_SOURCE_REVIEW"
    const blockerMessage = input.sourceReviewBlocker?.message ?? "Verify the original inventory recognition and exact return allocation before accounting release."
    const ledgerBatch = await createLedgerBlocker(tx, {
      organizationId: input.organizationId, periodId: period.id, sourceType: input.sourceType,
      sourceId: input.sourceId, postingPurpose: AccountingPostingPurpose.PURCHASE_RETURN,
      actorId: input.actorId, documentHash: input.documentHash, blockerCode, message: blockerMessage,
      metadata: safeJson(input.metadata),
    })
    return { ledgerBatch, ledgerStatus: "BLOCKED_PENDING_RULES", blockerCode, blockerMessage }
  }

  return createAPLedgerPosting(tx, {
    organizationId: input.organizationId,
    periodId: period.id,
    sourceType: input.sourceType,
    sourceId: input.sourceId,
    sourceNumber: input.sourceNumber,
    sourceDate: input.sourceDate,
    postingPurpose: isReturn
      ? AccountingPostingPurpose.PURCHASE_RETURN
      : AccountingPostingPurpose.SUPPLIER_CREDIT_NOTE,
    actorId: input.actorId,
    supplierId: input.supplierId,
    currency: input.currency,
    journalType: JournalType.PURCHASE,
    journalPrefix: isReturn ? "APRET" : "APCR",
    memo: isReturn ? `Purchase return ${input.sourceNumber}` : `Supplier credit note ${input.sourceNumber}`,
    documentHash: input.documentHash,
    amounts: {
      sourceAmount: decimal2(input.sourceAmount),
      netAmount: decimal2(input.netAmount),
      grossAmount: decimal2(input.grossAmount),
      taxAmount: decimal2(input.taxAmount),
      costAmount: decimal2(input.costAmount),
      varianceAmount: decimal2(input.varianceAmount ?? 0),
    },
    conditionContext: { correctionDirection: "CORRECTION", ...(isReturn ? {
      receiptReturnRecognition: "VERIFIED", receiptReturnRecognitionHash: input.receiptReturnRecognitionHash,
    } : {}), ...(input.receiptCreditRecognitionHash ? {
      receiptCreditRecognition: "VERIFIED", receiptCreditRecognitionHash: input.receiptCreditRecognitionHash,
      receiptCreditVarianceDirection: input.receiptCreditVarianceDirection,
    } : {}) },
    blockerCode: isReturn ? "PURCHASE_RETURN_POSTING_RULE_REVIEW" : "SUPPLIER_CREDIT_POSTING_RULE_REVIEW",
    blockerMessage: isReturn
      ? "Purchase return requires configured inventory, supplier-claim, and GRNI posting rules."
      : "Supplier credit requires configured AP, supplier-claim, and input-VAT posting rules.",
    metadata: input.metadata,
  })
}

async function queueOutboundSupplierPaymentReconciliation(
  tx: Prisma.TransactionClient,
  input: {
    organizationId: string
    supplierPaymentId: string
    paymentNumber: string
    supplierId: string
    bankAccountId: string
    amount: Prisma.Decimal
    currency: string
    paymentDate: Date
    method: PaymentMethod
    ledgerPostingBatchId: string
    ledgerStatus: APPostingStatus["ledgerStatus"]
    actorId?: string | null
    evidenceHash?: string | null
    documentHash?: string | null
  },
) {
  const idempotencyKey = `supplier-payment:${input.supplierPaymentId}:outbound`
  const payload = {
    supplierPaymentId: input.supplierPaymentId,
    paymentNumber: input.paymentNumber,
    supplierId: input.supplierId,
    bankAccountId: input.bankAccountId,
    amount: input.amount.toFixed(2),
    currency: input.currency,
    method: input.method,
    paymentDate: input.paymentDate.toISOString(),
    ledgerPostingBatchId: input.ledgerPostingBatchId,
    ledgerStatus: input.ledgerStatus,
  }
  const payloadHash = prefixedHash(payload)

  const paymentTransaction =
    (await tx.paymentTransaction.findFirst({
      where: {
        organizationId: input.organizationId,
        idempotencyKey,
      },
    })) ||
    (await tx.paymentTransaction.create({
      data: {
        organizationId: input.organizationId,
        ledgerPostingBatchId: input.ledgerPostingBatchId,
        direction: PaymentDirection.OUTBOUND,
        state: input.ledgerStatus === "POSTED" ? PaymentTransactionState.PENDING : PaymentTransactionState.SUSPENSE,
        amount: input.amount,
        currencyCode: input.currency,
        providerReference: input.paymentNumber,
        idempotencyKey,
        sourceType: "SUPPLIER_PAYMENT",
        sourceId: input.supplierPaymentId,
        payloadHash,
        occurredAt: input.paymentDate,
        metadata: safeJson({
          supplierId: input.supplierId,
          bankAccountId: input.bankAccountId,
          method: input.method,
          evidenceHash: input.evidenceHash ?? null,
          documentHash: input.documentHash ?? null,
          ledgerStatus: input.ledgerStatus,
        }),
      },
    }))

  const exceptionType =
    input.ledgerStatus === "POSTED"
      ? PaymentExceptionType.MISSING_STATEMENT_LINE
      : PaymentExceptionType.SUSPENSE_POSTING_BLOCKED
  const reconciliationStatus = input.ledgerStatus === "POSTED" ? "AWAITING_STATEMENT_MATCH" : "LEDGER_BLOCKED"

  const paymentException =
    (await tx.paymentException.findFirst({
      where: {
        organizationId: input.organizationId,
        paymentTransactionId: paymentTransaction.id,
        type: exceptionType,
        status: {
          notIn: [PaymentExceptionStatus.RESOLVED, PaymentExceptionStatus.DISMISSED],
        },
      },
    })) ||
    (await tx.paymentException.create({
      data: {
        organizationId: input.organizationId,
        paymentTransactionId: paymentTransaction.id,
        type: exceptionType,
        severity: input.ledgerStatus === "POSTED" ? ExceptionSeverity.MEDIUM : ExceptionSeverity.HIGH,
        status: PaymentExceptionStatus.OPEN,
        sourceType: "SUPPLIER_PAYMENT",
        sourceId: input.supplierPaymentId,
        evidence: safeJson(payload),
        correlationId: input.supplierPaymentId,
        metadata: safeJson({
          reconciliationStatus,
          supplierId: input.supplierId,
          paymentNumber: input.paymentNumber,
          method: input.method,
          ledgerPostingBatchId: input.ledgerPostingBatchId,
        }),
      },
    }))

  return {
    paymentTransaction,
    paymentException,
    reconciliationStatus,
    payloadHash,
  }
}

async function writeAudit(
  tx: Prisma.TransactionClient,
  input: {
    organizationId: string
    entityType: string
    entityId: string
    action: string
    actorId?: string | null
    changes?: unknown
  },
) {
  await tx.auditLog.create({
    data: {
      organizationId: input.organizationId,
      entityType: input.entityType,
      entityId: input.entityId,
      action: input.action,
      userId: input.actorId ?? null,
      changes: input.changes === undefined ? undefined : safeJson(input.changes),
    },
  })
}

async function nextSupplierPaymentNumber(tx: Prisma.TransactionClient, organizationId: string, paymentDate: Date) {
  const prefix = `SPAY-${compactDate(paymentDate)}`
  const count = await tx.supplierPayment.count({
    where: {
      organizationId,
      paymentNumber: { startsWith: prefix },
    },
  })

  return `${prefix}-${String(count + 1).padStart(4, "0")}`
}

async function nextAPJournalEntryNumber(
  tx: Prisma.TransactionClient,
  organizationId: string,
  entryDate: Date,
  prefix: "APINV" | "APPAY" | "APRET" | "APCR" | "APGR",
) {
  const datedPrefix = `${prefix}-${compactDate(entryDate)}`
  const lockKey = JSON.stringify(["ap-journal-number", organizationId, datedPrefix])
  await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtextextended(${lockKey}, 0))::text`
  const count = await tx.journalEntry.count({
    where: {
      organizationId,
      entryNumber: { startsWith: datedPrefix },
    },
  })

  return `${datedPrefix}-${String(count + 1).padStart(4, "0")}`
}

async function assertSupplier(tx: Prisma.TransactionClient, organizationId: string, supplierId: string) {
  const supplier = await tx.supplier.findFirst({
    where: {
      id: supplierId,
      organizationId,
      deletedAt: null,
    },
    select: {
      id: true,
      organizationId: true,
      name: true,
      isActive: true,
      currentBalance: true,
    },
  })

  if (!supplier) throw new NotFoundError("Supplier not found for this organization.")
  if (!supplier.isActive) throw new BusinessRuleError("Supplier is inactive.")
  return supplier
}

export async function buildInvoiceLinePlans(
  tx: Prisma.TransactionClient,
  input: {
    organizationId: string
    supplierId: string
    purchaseOrderId?: string
    // Revalidation counts other invoices, then reserves this invoice's lines once.
    excludeSupplierInvoiceId?: string
    lines: Array<{
      purchaseOrderLineId?: string
      goodsReceiptLineId: string
      itemId?: string
      description: string
      quantity: string | number
      unitCost: string | number
      taxRate?: string | number
      notes?: string
    }>
  },
) {
  const plans: InvoiceLinePlan[] = []
  const reservedByReceipt = new Map<string, Prisma.Decimal>()
  const receiptLineIds = [...new Set(input.lines.map(line => line.goodsReceiptLineId))]
  if (receiptLineIds.length) await tx.$queryRaw(Prisma.sql`SELECT r.id FROM goods_receipts r JOIN goods_receipt_lines l ON l."goodsReceiptId" = r.id WHERE r."organizationId" = ${input.organizationId} AND l.id IN (${Prisma.join(receiptLineIds)}) ORDER BY r.id FOR SHARE OF r`)

  for (const line of input.lines) {
    const quantity = decimal3(line.quantity)
    const unitCost = decimal2(line.unitCost)
    const taxRate = decimal3(line.taxRate ?? 0)
    if (quantity.lte(0)) throw new BusinessRuleError("Supplier invoice line quantity must be greater than zero.")
    if (unitCost.lt(0)) throw new BusinessRuleError("Supplier invoice line unit cost cannot be negative.")
    if (taxRate.lt(0)) throw new BusinessRuleError("Supplier invoice line tax rate cannot be negative.")

    const receiptLine = await tx.goodsReceiptLine.findFirst({
      where: {
        id: line.goodsReceiptLineId,
        goodsReceipt: {
          organizationId: input.organizationId,
          deletedAt: null,
          status: {
            in: [GoodsReceiptStatus.RECEIVED, GoodsReceiptStatus.COMPLETED],
          },
        },
        purchaseOrderLine: {
          purchaseOrder: {
            organizationId: input.organizationId,
            supplierId: input.supplierId,
            deletedAt: null,
            ...(input.purchaseOrderId ? { id: input.purchaseOrderId } : {}),
            status: {
              in: [
                PurchaseOrderStatus.APPROVED,
                PurchaseOrderStatus.PARTIALLY_RECEIVED,
                PurchaseOrderStatus.RECEIVED,
                PurchaseOrderStatus.COMPLETED,
                // Cancellation stops the remainder, not payment obligations for received goods.
                PurchaseOrderStatus.CANCELLED,
              ],
            },
          },
        },
      },
      include: {
        goodsReceipt: {
          select: {
            id: true,
            purchaseOrderId: true,
            organizationId: true,
            status: true,
          },
        },
        purchaseOrderLine: {
          select: {
            id: true,
            purchaseOrderId: true,
            itemId: true,
            receivedQuantity: true,
            unitCost: true,
          },
        },
      },
    })

    if (!receiptLine) {
      throw new BusinessRuleError("Supplier invoice line requires received goods evidence for this supplier.")
    }
    if (receiptLine.goodsReceipt.purchaseOrderId !== receiptLine.purchaseOrderLine.purchaseOrderId || receiptLine.itemId !== receiptLine.purchaseOrderLine.itemId) {
      throw new BusinessRuleError("Supplier invoice receipt and purchase order evidence are inconsistent.")
    }

    if (line.purchaseOrderLineId && line.purchaseOrderLineId !== receiptLine.purchaseOrderLineId) {
      throw new BusinessRuleError(
        "Supplier invoice line purchase order evidence does not match the goods receipt line.",
      )
    }

    if (line.itemId && line.itemId !== receiptLine.itemId) {
      throw new BusinessRuleError("Supplier invoice line item does not match the goods receipt line.")
    }

    const returned = await netUninvoicedReceiptReturns(tx, { organizationId: input.organizationId, supplierId: input.supplierId, lines: [receiptLine] })
    const alreadyInvoiced = await tx.supplierInvoiceLine.aggregate({
      _sum: { quantity: true },
      where: {
        goodsReceiptLineId: receiptLine.id,
        ...(input.excludeSupplierInvoiceId ? { supplierInvoiceId: { not: input.excludeSupplierInvoiceId } } : {}),
        supplierInvoice: {
          organizationId: input.organizationId,
          deletedAt: null,
          status: { notIn: [SupplierInvoiceStatus.CANCELLED] },
        },
      },
    })

    const previouslyInvoiced = decimal3(alreadyInvoiced._sum.quantity)
    const remainingReceived = decimal3(receiptLine.receivedQuantity).minus(previouslyInvoiced).minus(returned.get(receiptLine.id) ?? 0).toDecimalPlaces(3)
    const reservedQuantity = (reservedByReceipt.get(receiptLine.id) ?? new Prisma.Decimal(0)).plus(quantity)
    if (reservedQuantity.gt(remainingReceived)) {
      throw new BusinessRuleError("Supplier invoice quantity exceeds received and uninvoiced goods.")
    }
    reservedByReceipt.set(receiptLine.id, reservedQuantity)

    const priceVariance = unitCost.minus(decimal2(receiptLine.unitCost)).times(quantity).toDecimalPlaces(2)

    const lineSubtotal = quantity.times(unitCost).toDecimalPlaces(2)
    const taxAmount = lineSubtotal.times(taxRate).div(100).toDecimalPlaces(2)
    const lineTotal = lineSubtotal.plus(taxAmount).toDecimalPlaces(2)

    plans.push({
      availableQuantity: remainingReceived,
      purchaseOrderLineId: receiptLine.purchaseOrderLineId,
      goodsReceiptLineId: receiptLine.id,
      goodsReceiptId: receiptLine.goodsReceiptId,
      itemId: receiptLine.itemId,
      description: line.description,
      quantity,
      unitCost,
      taxRate,
      taxAmount,
      lineSubtotal,
      lineTotal,
      priceVariance,
    })
  }

  return plans
}

export async function getAPWorkbenchData(
  input: { organizationId: string; limit?: number },
  client: DbClient = db,
): Promise<APWorkbenchData> {
  const limit = Math.max(1, Math.min(input.limit ?? 20, 50))
  const organizationId = input.organizationId

  const [
    postedInvoices,
    paymentPendingInvoices,
    matchExceptions,
    pendingBankChangeCount,
    releasedPaymentCount,
    ledgerBlockerCount,
    reconciliationBlockerCount,
    recentInvoices,
    pendingBankChanges,
    releasedPayments,
    ledgerBlockers,
  ] = await Promise.all([
    client.supplierInvoice.count({
      where: {
        organizationId,
        deletedAt: null,
        status: SupplierInvoiceStatus.POSTED,
      },
    }),
    client.supplierInvoice.count({
      where: {
        organizationId,
        deletedAt: null,
        status: SupplierInvoiceStatus.PAYMENT_PENDING,
      },
    }),
    client.threeWayMatch.count({
      where: { organizationId, status: ThreeWayMatchStatus.EXCEPTION },
    }),
    client.supplierBankChangeRequest.count({
      where: { organizationId, status: SupplierBankChangeStatus.PENDING },
    }),
    client.supplierPayment.count({
      where: {
        organizationId,
        deletedAt: null,
        status: SupplierPaymentStatus.RELEASED,
      },
    }),
    client.ledgerPostingBatch.count({
      where: {
        organizationId,
        status: {
          in: [LedgerPostingBatchStatus.PENDING, LedgerPostingBatchStatus.FAILED],
        },
        sourceType: {
          in: [AccountingSourceType.SUPPLIER_INVOICE, AccountingSourceType.SUPPLIER_PAYMENT],
        },
      },
    }),
    client.paymentException.count({
      where: {
        organizationId,
        sourceType: "SUPPLIER_PAYMENT",
        status: {
          notIn: [PaymentExceptionStatus.RESOLVED, PaymentExceptionStatus.DISMISSED],
        },
      },
    }),
    client.supplierInvoice.findMany({
      where: {
        organizationId,
        deletedAt: null,
        status: {
          in: [SupplierInvoiceStatus.POSTED, SupplierInvoiceStatus.PAYMENT_PENDING, SupplierInvoiceStatus.DISPUTED],
        },
      },
      orderBy: [{ invoiceDate: "desc" }, { createdAt: "desc" }],
      take: limit,
      select: {
        id: true,
        invoiceNumber: true,
        status: true,
        total: true,
        amountPaid: true,
        currency: true,
        invoiceDate: true,
        ledgerPostingBatchId: true,
        metadata: true,
        supplier: { select: { name: true } },
      },
    }),
    client.supplierBankChangeRequest.findMany({
      where: { organizationId, status: SupplierBankChangeStatus.PENDING },
      orderBy: { requestedAt: "asc" },
      take: limit,
      select: {
        id: true,
        supplierId: true,
        requestedById: true,
        requestedAt: true,
        reason: true,
        bankAccountId: true,
        supplier: { select: { name: true } },
      },
    }),
    client.supplierPayment.findMany({
      where: {
        organizationId,
        deletedAt: null,
        status: SupplierPaymentStatus.RELEASED,
      },
      orderBy: [{ paymentDate: "desc" }, { createdAt: "desc" }],
      take: limit,
      select: {
        id: true,
        paymentNumber: true,
        amount: true,
        currency: true,
        method: true,
        paymentDate: true,
        ledgerPostingBatchId: true,
        postedBusinessEventId: true,
        metadata: true,
        supplier: { select: { name: true } },
      },
    }),
    client.ledgerPostingBatch.findMany({
      where: {
        organizationId,
        status: {
          in: [LedgerPostingBatchStatus.PENDING, LedgerPostingBatchStatus.FAILED],
        },
        sourceType: {
          in: [AccountingSourceType.SUPPLIER_INVOICE, AccountingSourceType.SUPPLIER_PAYMENT],
        },
      },
      orderBy: { createdAt: "asc" },
      take: limit,
      select: {
        id: true,
        sourceType: true,
        sourceId: true,
        postingPurpose: true,
        status: true,
        errorMessage: true,
        createdAt: true,
      },
    }),
  ])

  const ledgerBatchIds = [
    ...recentInvoices.map((invoice) => invoice.ledgerPostingBatchId),
    ...releasedPayments.map((payment) => payment.ledgerPostingBatchId),
  ].filter(Boolean) as string[]
  const releasedPaymentIds = releasedPayments.map((payment) => payment.id)
  const [receiptLedgerBatches, paymentTransactions, paymentExceptions] = await Promise.all([
    ledgerBatchIds.length
      ? client.ledgerPostingBatch.findMany({
          where: {
            organizationId,
            id: { in: Array.from(new Set(ledgerBatchIds)) },
          },
          select: {
            id: true,
            status: true,
            errorMessage: true,
            metadata: true,
          },
        })
      : Promise.resolve([]),
    releasedPaymentIds.length
      ? client.paymentTransaction.findMany({
          where: {
            organizationId,
            sourceType: "SUPPLIER_PAYMENT",
            sourceId: { in: releasedPaymentIds },
          },
          select: { id: true, sourceId: true, state: true, metadata: true },
        })
      : Promise.resolve([]),
    releasedPaymentIds.length
      ? client.paymentException.findMany({
          where: {
            organizationId,
            sourceType: "SUPPLIER_PAYMENT",
            sourceId: { in: releasedPaymentIds },
            status: {
              notIn: [PaymentExceptionStatus.RESOLVED, PaymentExceptionStatus.DISMISSED],
            },
          },
          orderBy: { createdAt: "desc" },
          select: {
            id: true,
            sourceId: true,
            type: true,
            status: true,
            metadata: true,
          },
        })
      : Promise.resolve([]),
  ])

  const ledgerBatchById = new Map(receiptLedgerBatches.map((batch) => [batch.id, batch]))
  const paymentTransactionBySourceId = new Map(
    paymentTransactions
      .filter((transaction) => transaction.sourceId)
      .map((transaction) => [transaction.sourceId!, transaction]),
  )
  const paymentExceptionBySourceId = new Map(
    paymentExceptions.filter((exception) => exception.sourceId).map((exception) => [exception.sourceId!, exception]),
  )

  const ledgerStatusFor = (batchId: string | null, metadata: unknown) => {
    const metadataStatus = metadataString(metadata, "ledgerStatus")
    if (metadataStatus) return metadataStatus
    if (!batchId) return "NOT_POSTED"
    return ledgerBatchById.get(batchId)?.status ?? "UNKNOWN"
  }

  const ledgerBlockerCodeFor = (batchId: string | null, metadata: unknown) =>
    metadataString(metadata, "ledgerBlockerCode") ||
    metadataString(ledgerBatchById.get(batchId ?? "")?.metadata, "blockerCode")

  const ledgerBlockerMessageFor = (batchId: string | null, metadata: unknown) =>
    metadataString(metadata, "ledgerBlockerMessage") || ledgerBatchById.get(batchId ?? "")?.errorMessage || null

  return {
    organizationId,
    asOf: new Date().toISOString(),
    counts: {
      postedInvoices,
      paymentPendingInvoices,
      matchExceptions,
      pendingBankChanges: pendingBankChangeCount,
      releasedPayments: releasedPaymentCount,
      ledgerBlockers: ledgerBlockerCount,
      reconciliationBlockers: reconciliationBlockerCount,
    },
    queues: {
      recentInvoices: recentInvoices.map((invoice) => ({
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        supplierName: invoice.supplier.name,
        status: invoice.status,
        total: decimalString(invoice.total),
        amountPaid: decimalString(invoice.amountPaid),
        currency: invoice.currency,
        invoiceDate: invoice.invoiceDate.toISOString(),
        ledgerPostingBatchId: invoice.ledgerPostingBatchId,
        ledgerStatus: ledgerStatusFor(invoice.ledgerPostingBatchId, invoice.metadata),
        ledgerBlockerCode: ledgerBlockerCodeFor(invoice.ledgerPostingBatchId, invoice.metadata),
        ledgerBlockerMessage: ledgerBlockerMessageFor(invoice.ledgerPostingBatchId, invoice.metadata),
        countryPackStatus: metadataString(invoice.metadata, "countryPackStatus"),
        countryPackVersion: metadataString(invoice.metadata, "countryPackVersion"),
        countryPackResolutionHash: metadataString(invoice.metadata, "countryPackResolutionHash"),
        taxTreatmentStatus: metadataString(invoice.metadata, "taxTreatmentStatus"),
        withholdingTreatmentStatus: metadataString(invoice.metadata, "withholdingTreatmentStatus"),
        operatorActionRequired: metadataBoolean(invoice.metadata, "operatorActionRequired"),
      })),
      pendingBankChanges: pendingBankChanges.map((change) => ({
        id: change.id,
        supplierId: change.supplierId,
        supplierName: change.supplier.name,
        requestedById: change.requestedById,
        requestedAt: change.requestedAt.toISOString(),
        reason: change.reason,
        bankAccountId: change.bankAccountId,
      })),
      releasedPayments: releasedPayments.map((payment) => ({
        id: payment.id,
        paymentNumber: payment.paymentNumber,
        supplierName: payment.supplier.name,
        amount: decimalString(payment.amount),
        currency: payment.currency,
        method: payment.method,
        paymentDate: payment.paymentDate.toISOString(),
        ledgerPostingBatchId: payment.ledgerPostingBatchId,
        postedBusinessEventId: payment.postedBusinessEventId,
        ledgerStatus: ledgerStatusFor(payment.ledgerPostingBatchId, payment.metadata),
        ledgerBlockerCode: ledgerBlockerCodeFor(payment.ledgerPostingBatchId, payment.metadata),
        ledgerBlockerMessage: ledgerBlockerMessageFor(payment.ledgerPostingBatchId, payment.metadata),
        reconciliationStatus:
          metadataString(payment.metadata, "reconciliationStatus") ||
          metadataString(paymentExceptionBySourceId.get(payment.id)?.metadata, "reconciliationStatus") ||
          paymentTransactionBySourceId.get(payment.id)?.state ||
          null,
        paymentTransactionId: paymentTransactionBySourceId.get(payment.id)?.id ?? null,
        paymentExceptionId: paymentExceptionBySourceId.get(payment.id)?.id ?? null,
        countryPackStatus: metadataString(payment.metadata, "countryPackStatus"),
        withholdingTreatmentStatus: metadataString(payment.metadata, "withholdingTreatmentStatus"),
        operatorActionRequired: metadataBoolean(payment.metadata, "operatorActionRequired"),
      })),
      ledgerBlockers: ledgerBlockers.map((blocker) => ({
        id: blocker.id,
        sourceType: blocker.sourceType,
        sourceId: blocker.sourceId,
        postingPurpose: blocker.postingPurpose,
        status: blocker.status,
        errorMessage: blocker.errorMessage,
        createdAt: blocker.createdAt.toISOString(),
      })),
    },
  }
}

export async function postSupplierInvoice(input: PostSupplierInvoiceInput, client: DbClient = db) {
  const parsed = postSupplierInvoiceInputSchema.parse(input)
  if (!parsed.createdById) {
    throw new BusinessRuleError("Supplier invoice preparation requires an authenticated maker.")
  }
  if (parsed.approvedById && parsed.approvedById === parsed.createdById) {
    throw new BusinessRuleError("Supplier invoice posting requires an independent approver.")
  }
  const invoiceDate = parseDate(parsed.invoiceDate)
  const dueDate = parsed.dueDate ? parseDate(parsed.dueDate) : undefined
  const currency = normalizeCurrency(parsed.currency)
  const idempotencyPayloadHash = parsed.idempotencyKey
    ? prefixedHash({
        operation: "postSupplierInvoice",
        supplierId: parsed.supplierId,
        purchaseOrderId: parsed.purchaseOrderId ?? null,
        invoiceNumber: normalizeInvoiceNumber(parsed.invoiceNumber),
        invoiceDate: invoiceDate.toISOString(),
        dueDate: dueDate?.toISOString() ?? null,
        currency,
        lines: parsed.lines.map((line) => ({
          purchaseOrderLineId: line.purchaseOrderLineId ?? null,
          goodsReceiptLineId: line.goodsReceiptLineId,
          itemId: line.itemId ?? null,
          description: line.description.trim(),
          quantity: String(line.quantity),
          unitCost: String(line.unitCost),
          taxRate: String(line.taxRate ?? 0),
        })),
      })
    : null

  return inTransaction(client, async (tx) => {
    // Serialize preparation before replay/quantity reads, including invoices without a PO ID.
    // The next waiter observes committed reservations and can replay the completed invoice.
    await tx.$queryRaw`SELECT id FROM suppliers WHERE id = ${parsed.supplierId} AND "organizationId" = ${parsed.organizationId} FOR UPDATE`
    const supplier = await assertSupplier(tx, parsed.organizationId, parsed.supplierId)

    if (parsed.idempotencyKey) {
      const existing = await tx.supplierInvoice.findFirst({
        where: {
          organizationId: parsed.organizationId,
          idempotencyKey: parsed.idempotencyKey,
          deletedAt: null,
        },
      })
      if (existing) {
        assertIdempotencyPayloadMatches(
          existing.metadata,
          idempotencyPayloadHash,
          "Supplier invoice idempotency key was reused with a different payload.",
        )
        return {
          supplierInvoice: existing,
          postingBatchId: existing.ledgerPostingBatchId,
          businessEventId: existing.postedBusinessEventId,
          ledgerStatus: "IDEMPOTENT_REPLAY" as const,
        }
      }
    }

    if (parsed.purchaseOrderId) {
      await tx.$queryRaw`SELECT id FROM purchase_orders WHERE id = ${parsed.purchaseOrderId} AND "organizationId" = ${parsed.organizationId} FOR UPDATE`
      const purchaseOrder = await tx.purchaseOrder.findFirst({
        where: {
          id: parsed.purchaseOrderId,
          organizationId: parsed.organizationId,
          supplierId: parsed.supplierId,
          deletedAt: null,
        },
        select: { id: true, status: true },
      })

      if (!purchaseOrder) throw new NotFoundError("Purchase order not found for this supplier.")
      if (
        purchaseOrder.status === PurchaseOrderStatus.DRAFT ||
        purchaseOrder.status === PurchaseOrderStatus.SUBMITTED
      ) {
        throw new BusinessRuleError(
          "Supplier invoices can only be posted against approved or received purchase orders.",
        )
      }
    }

    const linePlans = await buildInvoiceLinePlans(tx, {
      organizationId: parsed.organizationId,
      supplierId: parsed.supplierId,
      purchaseOrderId: parsed.purchaseOrderId,
      lines: parsed.lines,
    })

    const subtotal = linePlans
      .reduce((total, line) => total.plus(line.lineSubtotal), new Prisma.Decimal(0))
      .toDecimalPlaces(2)
    const taxAmount = linePlans
      .reduce((total, line) => total.plus(line.taxAmount), new Prisma.Decimal(0))
      .toDecimalPlaces(2)
    const total = subtotal.plus(taxAmount).toDecimalPlaces(2)
    if (total.lte(0)) throw new BusinessRuleError("Supplier invoice total must be greater than zero.")
    const priceVariance = linePlans
      .reduce((variance, line) => variance.plus(line.priceVariance), new Prisma.Decimal(0))
      .toDecimalPlaces(2)
    const varianceAmount = linePlans
      .reduce((variance, line) => variance.plus(line.priceVariance.abs()), new Prisma.Decimal(0))
      .toDecimalPlaces(2)
    const requiresMatchException = varianceAmount.gt(0)
    if (requiresMatchException && parsed.approvedById) {
      throw new BusinessRuleError(
        "Supplier invoice posting is blocked until its exact-match variance has an approved active exception.",
      )
    }

    const countryPackStatus = await resolveAPCountryPackStatus(tx, {
      organizationId: parsed.organizationId,
      documentDate: invoiceDate,
      taxAmount,
      purpose: "SUPPLIER_INVOICE",
    })

    const fingerprint = duplicateFingerprint({
      organizationId: parsed.organizationId,
      supplierId: parsed.supplierId,
      invoiceNumber: parsed.invoiceNumber,
      total,
      currency,
    })

    const duplicate = await tx.supplierInvoice.findFirst({
      where: {
        organizationId: parsed.organizationId,
        deletedAt: null,
        OR: [
          {
            supplierId: parsed.supplierId,
            invoiceNumber: parsed.invoiceNumber.trim(),
          },
          { duplicateFingerprint: fingerprint },
        ],
      },
      select: { id: true, invoiceNumber: true },
    })

    if (duplicate) {
      throw new ConflictError(`Supplier invoice ${parsed.invoiceNumber} is already recorded for this supplier.`)
    }

    const period = await getOpenPeriodForDate(parsed.organizationId, invoiceDate, tx)
    const evidencePayload = {
      supplierId: parsed.supplierId,
      invoiceNumber: parsed.invoiceNumber.trim(),
      invoiceDate: invoiceDate.toISOString(),
      total: total.toFixed(2),
      currency,
      lineCount: linePlans.length,
      goodsReceiptLineIds: linePlans.map((line) => line.goodsReceiptLineId),
    }
    const documentHash = parsed.documentHash ?? prefixedHash(evidencePayload)

    const invoice = await tx.supplierInvoice.create({
      data: {
        organizationId: parsed.organizationId,
        supplierId: parsed.supplierId,
        purchaseOrderId: parsed.purchaseOrderId ?? null,
        invoiceNumber: parsed.invoiceNumber.trim(),
        invoiceDate,
        dueDate: dueDate ?? null,
        status: parsed.approvedById
          ? SupplierInvoiceStatus.POSTED
          : requiresMatchException
            ? SupplierInvoiceStatus.DISPUTED
            : SupplierInvoiceStatus.MATCHED,
        subtotal,
        taxAmount,
        discount: new Prisma.Decimal(0),
        total,
        amountPaid: new Prisma.Decimal(0),
        currency,
        duplicateFingerprint: fingerprint,
        idempotencyKey: parsed.idempotencyKey ?? null,
        documentHash,
        evidenceHash: parsed.evidenceHash ?? prefixedHash(evidencePayload),
        createdById: parsed.createdById ?? null,
        approvedById: parsed.approvedById ?? null,
        postedAt: parsed.approvedById ? invoiceDate : null,
        notes: parsed.notes ?? null,
        metadata: safeJson({
          gate: "011-purchasing-ap-controls",
          normalizedInvoiceNumber: normalizeInvoiceNumber(parsed.invoiceNumber),
          idempotencyPayloadHash,
          countryPackStatus: countryPackStatus.countryPackStatus,
          countryCode: countryPackStatus.countryCode,
          countryPackVersion: countryPackStatus.countryPackVersion,
          countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
          taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
          withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
          operatorActionRequired: countryPackStatus.operatorActionRequired,
          countryPackErrorCode: countryPackStatus.errorCode ?? null,
          countryPackErrorMessage: countryPackStatus.errorMessage ?? null,
        }),
        lines: {
          create: linePlans.map((line) => ({
            organizationId: parsed.organizationId,
            purchaseOrderLineId: line.purchaseOrderLineId,
            goodsReceiptLineId: line.goodsReceiptLineId,
            itemId: line.itemId,
            description: line.description,
            quantity: line.quantity,
            unitCost: line.unitCost,
            taxRate: line.taxRate,
            taxAmount: line.taxAmount,
            lineTotal: line.lineTotal,
            matchStatus: line.priceVariance.eq(0)
              ? ThreeWayMatchStatus.MATCHED
              : ThreeWayMatchStatus.EXCEPTION,
          })),
        },
      },
      include: { lines: true },
    })

    const distinctGoodsReceiptIds = Array.from(new Set(linePlans.map((line) => line.goodsReceiptId)))
    const match = await tx.threeWayMatch.create({
      data: {
        organizationId: parsed.organizationId,
        supplierInvoiceId: invoice.id,
        purchaseOrderId: parsed.purchaseOrderId ?? null,
        goodsReceiptId: distinctGoodsReceiptIds.length === 1 ? distinctGoodsReceiptIds[0] : null,
        status: requiresMatchException ? ThreeWayMatchStatus.EXCEPTION : ThreeWayMatchStatus.MATCHED,
        matchedAt: invoiceDate,
        matchedById: parsed.createdById,
        toleranceAmount: new Prisma.Decimal(0),
        varianceAmount,
        quantityVariance: new Prisma.Decimal(0),
        priceVariance,
        evidenceHash: prefixedHash({
          invoiceId: invoice.id,
          lineIds: invoice.lines.map((line) => line.id),
          goodsReceiptLineIds: linePlans.map((line) => line.goodsReceiptLineId),
          priceVariance: priceVariance.toFixed(2),
          varianceAmount: varianceAmount.toFixed(2),
        }),
        metadata: safeJson({
          supplierId: supplier.id,
          supplierName: supplier.name,
          purchaseOrderId: parsed.purchaseOrderId ?? null,
        }),
      },
    })

    if (!parsed.approvedById) {
      await writeAudit(tx, {
        organizationId: parsed.organizationId,
        entityType: "SupplierInvoice",
        entityId: invoice.id,
        action: "SUPPLIER_INVOICE_PREPARED",
        actorId: parsed.createdById,
        changes: {
          after: {
            supplierId: supplier.id,
            invoiceNumber: invoice.invoiceNumber,
            total: total.toFixed(2),
            threeWayMatchId: match.id,
            status: invoice.status,
            matchStatus: match.status,
            varianceAmount: varianceAmount.toFixed(2),
          },
        },
      })

      return {
        supplierInvoice: invoice,
        threeWayMatch: match,
        postingBatchId: null,
        businessEventId: null,
        ledgerStatus: requiresMatchException
          ? ("PENDING_MATCH_EXCEPTION" as const)
          : ("PENDING_APPROVAL" as const),
      }
    }

    const receiptRecognition = await resolveInvoiceReceiptRecognition(tx, {
      organizationId: parsed.organizationId, supplierId: invoice.supplierId, invoiceId: invoice.id,
      currency, subtotal, total, taxAmount, lines: invoice.lines,
    })
    const balanceAfter = decimal2(supplier.currentBalance).plus(total).toDecimalPlaces(2)
    await tx.supplier.update({
      where: { id: supplier.id },
      data: { currentBalance: balanceAfter },
    })
    await tx.supplierLedgerEntry.create({
      data: {
        organizationId: parsed.organizationId,
        supplierId: supplier.id,
        entryDate: invoiceDate,
        type: LedgerEntryType.PURCHASE,
        debit: total,
        credit: new Prisma.Decimal(0),
        balanceAfter,
        description: `Supplier invoice ${invoice.invoiceNumber}`,
        referenceType: "SUPPLIER_INVOICE",
        referenceId: invoice.id,
      },
    })

    const postingResult = await createAPLedgerPosting(tx, {
      organizationId: parsed.organizationId,
      periodId: period.id,
      sourceType: AccountingSourceType.SUPPLIER_INVOICE,
      sourceId: invoice.id,
      sourceNumber: invoice.invoiceNumber,
      sourceDate: invoiceDate,
      postingPurpose: AccountingPostingPurpose.SUPPLIER_INVOICE,
      actorId: parsed.approvedById ?? parsed.createdById ?? null,
      supplierId: supplier.id,
      currency,
      journalType: JournalType.PURCHASE,
      journalPrefix: "APINV",
      memo: `Supplier invoice ${invoice.invoiceNumber}`,
      documentHash,
      amounts: receiptRecognition.amounts,
      conditionContext: receiptRecognition.conditionContext,
      blockerCode: "AP_POSTING_RULE_REVIEW",
      blockerMessage: "Supplier invoice AP posting requires configured SYSCOHADA purchase/input VAT/AP rules.",
      metadata: {
        invoiceNumber: invoice.invoiceNumber,
        supplierId: supplier.id,
        total: total.toFixed(2),
        currency,
        ...(receiptRecognition.recognition ? { receiptRecognition: receiptRecognition.recognition } : {}),
        countryPackStatus: countryPackStatus.countryPackStatus,
        countryPackVersion: countryPackStatus.countryPackVersion,
        countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
        taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
        withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
      },
    })
    const ledgerBatch = postingResult.ledgerBatch

    const eventResult = await recordBusinessEventInTx(tx, {
      organizationId: parsed.organizationId,
      eventType: "purchase.supplier_invoice.posted",
      eventSource: "INTERNAL",
      schemaVersion: 1,
      idempotencyKey: parsed.idempotencyKey ?? `supplier-invoice:${invoice.id}`,
      payload: {
        invoiceId: invoice.id,
        supplierId: supplier.id,
        purchaseOrderId: parsed.purchaseOrderId ?? null,
        invoiceNumber: invoice.invoiceNumber,
        total: total.toFixed(2),
        currency,
        threeWayMatchId: match.id,
        ledgerPostingBatchId: ledgerBatch.id,
        journalEntryId: postingResult.journalEntryId ?? null,
        ledgerStatus: postingResult.ledgerStatus,
        ...(receiptRecognition.recognition ? { receiptRecognitionHash: hashBusinessPayload(receiptRecognition.recognition) } : {}),
        makerId: invoice.createdById,
        approverId: invoice.approvedById,
        matchStatus: match.status,
      },
      occurredAt: invoiceDate,
      actorId: parsed.approvedById ?? parsed.createdById,
      sourceType: AccountingSourceType.SUPPLIER_INVOICE,
      sourceId: invoice.id,
      postingBatchId: ledgerBatch.id,
      documentHash,
      metadata: {
        ledgerStatus: postingResult.ledgerStatus,
        blockerCode: postingResult.blockerCode ?? null,
        countryPackStatus: countryPackStatus.countryPackStatus,
        countryPackVersion: countryPackStatus.countryPackVersion,
        countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
        gate: "011-purchasing-ap-controls",
        // Record only what the persisted invoice and its exact match establish.
        // This adds recovery evidence; it does not introduce a lifecycle gate.
        makerCheckerVerified: Boolean(
          invoice.createdById && invoice.approvedById && invoice.createdById !== invoice.approvedById &&
          invoice.createdById === parsed.createdById && invoice.approvedById === parsed.approvedById &&
          invoice.status === SupplierInvoiceStatus.POSTED && invoice.postedAt &&
          match.supplierInvoiceId === invoice.id && match.organizationId === parsed.organizationId &&
          match.status === ThreeWayMatchStatus.MATCHED && match.varianceAmount.eq(0),
        ),
      },
      outboxMessages: [
        {
          channel: "NOTIFICATION",
          eventName: "supplier_invoice.posted",
          destination: "accounting",
          payload: {
            severity: postingResult.ledgerStatus === "POSTED" ? "info" : "warning",
            invoiceId: invoice.id,
            supplierId: supplier.id,
            total: total.toFixed(2),
            ledgerStatus: postingResult.ledgerStatus,
            blockerCode: postingResult.blockerCode ?? null,
          },
        },
      ],
    })

    await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)
    const postedInvoice = await tx.supplierInvoice.update({
      where: { id: invoice.id },
      data: {
        ledgerPostingBatchId: ledgerBatch.id,
        postedBusinessEventId: eventResult.event.id,
        metadata: safeJson({
          gate: "011-purchasing-ap-controls",
          normalizedInvoiceNumber: normalizeInvoiceNumber(parsed.invoiceNumber),
          idempotencyPayloadHash,
          ledgerStatus: postingResult.ledgerStatus,
          ledgerBlockerCode: postingResult.blockerCode ?? null,
          ledgerBlockerMessage: postingResult.blockerMessage ?? null,
          journalEntryId: postingResult.journalEntryId ?? null,
          accountingSourceLinkId: postingResult.accountingSourceLinkId ?? null,
          ...(receiptRecognition.recognition ? { receiptRecognition: receiptRecognition.recognition } : {}),
          countryPackStatus: countryPackStatus.countryPackStatus,
          countryCode: countryPackStatus.countryCode,
          countryPackVersion: countryPackStatus.countryPackVersion,
          countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
          taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
          withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
          operatorActionRequired: countryPackStatus.operatorActionRequired,
          countryPackErrorCode: countryPackStatus.errorCode ?? null,
          countryPackErrorMessage: countryPackStatus.errorMessage ?? null,
        }),
      },
      include: { lines: true, threeWayMatches: true },
    })

    await writeAudit(tx, {
      organizationId: parsed.organizationId,
      entityType: "SupplierInvoice",
      entityId: invoice.id,
      action: "SUPPLIER_INVOICE_POSTED",
      actorId: parsed.approvedById ?? parsed.createdById ?? null,
      changes: {
        after: {
          supplierId: supplier.id,
          invoiceNumber: invoice.invoiceNumber,
          total: total.toFixed(2),
          ledgerPostingBatchId: ledgerBatch.id,
          businessEventId: eventResult.event.id,
          ledgerStatus: postingResult.ledgerStatus,
          journalEntryId: postingResult.journalEntryId ?? null,
        },
      },
    })

    return {
      supplierInvoice: postedInvoice,
      threeWayMatch: match,
      postingBatchId: ledgerBatch.id,
      businessEventId: eventResult.event.id,
      ledgerStatus: postingResult.ledgerStatus,
    }
  })
}

export async function prepareSupplierInvoice(input: PostSupplierInvoiceInput, client: DbClient = db) {
  return postSupplierInvoice({ ...input, approvedById: undefined }, client)
}

export async function expireMatchExceptionInTx(tx: Prisma.TransactionClient, exception: Prisma.SupplierInvoiceMatchExceptionGetPayload<{}>, actorId: string, observedAt: Date) {
  if ((exception.status !== "OPEN" && exception.status !== "APPROVED") || exception.expiresAt > observedAt) throw new ConflictError("Match exception is not eligible for expiry.")
  const claim = await tx.supplierInvoiceMatchException.updateMany({
    where: { id: exception.id, organizationId: exception.organizationId, status: exception.status, expiresAt: { lte: observedAt } },
    data: { status: SupplierInvoiceMatchExceptionStatus.EXPIRED },
  })
  if (claim.count !== 1) throw new ConflictError("Match exception changed before expiry was recorded.")
  const recorded = await recordBusinessEventInTx(tx, {
    organizationId: exception.organizationId, eventType: "purchase.supplier_invoice.match_exception.expired", eventSource: "INTERNAL", schemaVersion: 1,
    idempotencyKey: `supplier-invoice-match-exception:${exception.id}:expired`, actorId,
    sourceType: AccountingSourceType.SUPPLIER_INVOICE, sourceId: exception.supplierInvoiceId, occurredAt: observedAt,
    payload: { matchExceptionId: exception.id, supplierInvoiceId: exception.supplierInvoiceId, previousStatus: exception.status, status: "EXPIRED", effectiveAt: exception.expiresAt.toISOString(), observedAt: observedAt.toISOString(), policyVersion: exception.policyVersion },
    outboxMessages: [{ channel: "NOTIFICATION", eventName: "supplier_invoice.match_exception.expired", destination: "accounting", payload: { severity: "warning", matchExceptionId: exception.id, supplierInvoiceId: exception.supplierInvoiceId, expiresAt: exception.expiresAt.toISOString() } }],
  })
  await markBusinessEventAppliedInTx(tx, exception.organizationId, recorded.event.id)
  await writeAudit(tx, { organizationId: exception.organizationId, entityType: "SupplierInvoiceMatchException", entityId: exception.id, action: "SUPPLIER_INVOICE_MATCH_EXCEPTION_EXPIRED", actorId, changes: { before: { status: exception.status }, after: { status: "EXPIRED", effectiveAt: exception.expiresAt.toISOString(), observedAt: observedAt.toISOString(), businessEventId: recorded.event.id } } })
}

export async function lockMatchExceptionInvoice(tx: Prisma.TransactionClient, organizationId: string, invoiceId: string) {
  // Use the invoice-posting lock order so approval cannot cross an exception decision.
  await tx.$queryRaw`SELECT s.id FROM suppliers s JOIN supplier_invoices i ON i."supplierId" = s.id WHERE i.id = ${invoiceId} AND i."organizationId" = ${organizationId} AND s."organizationId" = ${organizationId} FOR UPDATE OF s`
  await tx.$queryRaw`SELECT id FROM supplier_invoices WHERE id = ${invoiceId} AND "organizationId" = ${organizationId} FOR UPDATE`
  await tx.$queryRaw`SELECT id FROM supplier_invoice_lines WHERE "supplierInvoiceId" = ${invoiceId} AND "organizationId" = ${organizationId} FOR SHARE`
  await tx.$queryRaw`SELECT id FROM three_way_matches WHERE "supplierInvoiceId" = ${invoiceId} AND "organizationId" = ${organizationId} ORDER BY id FOR SHARE`
  await tx.$queryRaw`SELECT r.id FROM supplier_invoice_lines l JOIN goods_receipt_lines rl ON rl.id = l."goodsReceiptLineId" JOIN goods_receipts r ON r.id = rl."goodsReceiptId" JOIN purchase_order_lines pl ON pl.id = rl."purchaseOrderLineId" JOIN purchase_orders p ON p.id = pl."purchaseOrderId" WHERE l."supplierInvoiceId" = ${invoiceId} AND l."organizationId" = ${organizationId} AND r."organizationId" = ${organizationId} AND p."organizationId" = ${organizationId} ORDER BY r.id, rl.id FOR SHARE OF r, rl, pl, p`
}

export async function requestSupplierInvoiceMatchException(
  input: RequestSupplierInvoiceMatchExceptionInput,
  client: DbClient = db,
) {
  const parsed = requestSupplierInvoiceMatchExceptionInputSchema.parse(input)
  const expiresAt = parseDate(parsed.expiresAt)
  const now = new Date()
  if (expiresAt <= now) {
    throw new BusinessRuleError("Supplier invoice match exception expiry must be in the future.")
  }

  try {
    return await inTransaction(client, async (tx) => {
      await lockMatchExceptionInvoice(tx, parsed.organizationId, parsed.supplierInvoiceId)
      const now = new Date()
      if (expiresAt <= now) throw new BusinessRuleError("Supplier invoice match exception expiry must be in the future.")
      const invoice = await tx.supplierInvoice.findFirst({
        where: {
          id: parsed.supplierInvoiceId,
          organizationId: parsed.organizationId,
          deletedAt: null,
        },
        include: { lines: true, threeWayMatches: true, supplier: true },
      })
      if (!invoice) throw new NotFoundError("Supplier invoice not found for this organization.")
      if (!invoice.createdById || invoice.createdById !== parsed.requestedById) {
        throw new BusinessRuleError("Only the supplier invoice maker can request its match exception.")
      }
      if (invoice.status !== SupplierInvoiceStatus.DISPUTED) {
        throw new BusinessRuleError("Only a supplier invoice with an exact-match variance can request an exception.")
      }

      const match = invoice.threeWayMatches.find(
        (candidate) => candidate.status === ThreeWayMatchStatus.EXCEPTION,
      )
      if (!match) {
        throw new BusinessRuleError("Supplier invoice requires unresolved three-way match evidence.")
      }

      const duplicate = await tx.supplierInvoiceMatchException.findFirst({
        where: {
          organizationId: parsed.organizationId,
          threeWayMatchId: match.id,
          status: {
            in: [
              SupplierInvoiceMatchExceptionStatus.OPEN,
              SupplierInvoiceMatchExceptionStatus.APPROVED,
            ],
          },
          expiresAt: { gt: now },
        },
        select: { id: true, status: true },
      })
      if (duplicate) {
        throw new ConflictError("An active match exception already exists for this supplier invoice match.")
      }

      await validateInvoiceApprovalSource(tx, invoice, parsed.organizationId)

      const priorRequests = await tx.supplierInvoiceMatchException.findMany({ where: { organizationId: parsed.organizationId, supplierInvoiceId: invoice.id }, orderBy: { id: "asc" } })
      for (const prior of priorRequests) {
        if ((prior.status === "OPEN" || prior.status === "APPROVED") && prior.expiresAt <= now) await expireMatchExceptionInTx(tx, prior, parsed.requestedById, now)
      }

      const matchException = await tx.supplierInvoiceMatchException.create({
        data: {
          organizationId: parsed.organizationId,
          supplierInvoiceId: invoice.id,
          threeWayMatchId: match.id,
          status: SupplierInvoiceMatchExceptionStatus.OPEN,
          policyVersion: EXACT_THREE_WAY_MATCH_EXCEPTION_POLICY_VERSION,
          reason: parsed.reason,
          evidenceReference: parsed.evidenceReference,
          varianceAmount: match.varianceAmount,
          priceVariance: match.priceVariance,
          requestedById: parsed.requestedById,
          expiresAt,
          metadata: safeJson({
            invoiceNumber: invoice.invoiceNumber,
            purchaseOrderId: invoice.purchaseOrderId ?? null,
            threeWayMatchStatus: match.status,
          }),
        },
      })

      const eventResult = await recordBusinessEventInTx(tx, {
        organizationId: parsed.organizationId,
        eventType: "purchase.supplier_invoice.match_exception.requested",
        eventSource: "INTERNAL",
        schemaVersion: 1,
        idempotencyKey: `supplier-invoice-match-exception:${matchException.id}:requested`,
        payload: {
          matchExceptionId: matchException.id,
          supplierInvoiceId: invoice.id,
          threeWayMatchId: match.id,
          policyVersion: EXACT_THREE_WAY_MATCH_EXCEPTION_POLICY_VERSION,
          varianceAmount: decimal2(match.varianceAmount).toFixed(2),
          priceVariance: decimal2(match.priceVariance).toFixed(2),
          sourceHash: invoicePreparationSourceHash(invoice),
          priorRequestIds: priorRequests.map(prior => prior.id),
          reason: parsed.reason,
          evidenceReference: parsed.evidenceReference,
          requesterId: parsed.requestedById,
          expiresAt: expiresAt.toISOString(),
        },
        occurredAt: now,
        actorId: parsed.requestedById,
        sourceType: AccountingSourceType.SUPPLIER_INVOICE,
        sourceId: invoice.id,
        documentHash: invoice.documentHash ?? undefined,
        metadata: {
          gate: "011-purchasing-ap-controls",
          evidenceReference: parsed.evidenceReference,
        },
        outboxMessages: [
          {
            channel: "NOTIFICATION",
            eventName: "supplier_invoice.match_exception.requested",
            destination: "accounting",
            payload: {
              severity: "warning",
              matchExceptionId: matchException.id,
              supplierInvoiceId: invoice.id,
              policyVersion: EXACT_THREE_WAY_MATCH_EXCEPTION_POLICY_VERSION,
              expiresAt: expiresAt.toISOString(),
            },
          },
        ],
      })
      await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)

      await writeAudit(tx, {
        organizationId: parsed.organizationId,
        entityType: "SupplierInvoiceMatchException",
        entityId: matchException.id,
        action: "SUPPLIER_INVOICE_MATCH_EXCEPTION_REQUESTED",
        actorId: parsed.requestedById,
        changes: {
          after: {
            supplierInvoiceId: invoice.id,
            threeWayMatchId: match.id,
            status: SupplierInvoiceMatchExceptionStatus.OPEN,
            policyVersion: EXACT_THREE_WAY_MATCH_EXCEPTION_POLICY_VERSION,
            reason: parsed.reason,
            evidenceReference: parsed.evidenceReference,
            expiresAt: expiresAt.toISOString(),
          },
        },
      })

      return { matchException, businessEventId: eventResult.event.id }
    })
  } catch (error) {
    if (error instanceof ApplicationError) throw error
    // The reviewed service owns serializable retry. Preserve database aborts so
    // it can restart the whole transaction with the same command.
    if (error instanceof Prisma.PrismaClientKnownRequestError && (error.code === "P2034" || error.code === "P2010" && ["40001", "40P01"].includes(String(error.meta?.code)))) throw error
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      throw new ConflictError("An active match exception already exists for this supplier invoice match.")
    }
    throw new ApplicationError(
      "INTERNAL_ERROR",
      "Supplier invoice match exception request could not be completed safely.",
      500,
      false,
    )
  }
}

export async function validateMatchExceptionReviewSource(tx: Prisma.TransactionClient, matchException: Prisma.SupplierInvoiceMatchExceptionGetPayload<{}>, organizationId: string) {
  const invoice = await tx.supplierInvoice.findFirst({ where: { id: matchException.supplierInvoiceId, organizationId: organizationId, deletedAt: null }, include: { lines: true, threeWayMatches: true, supplier: true } })
  if (!invoice) throw new NotFoundError("Supplier invoice not found for this organization.")
  const source = await validateInvoiceApprovalSource(tx, invoice, organizationId)
  const request = await tx.businessEvent.findFirst({ where: { organizationId: organizationId, eventSource: "INTERNAL", idempotencyKey: `supplier-invoice-match-exception:${matchException.id}:requested` } })
  const proof = request?.payload && typeof request.payload === "object" && !Array.isArray(request.payload) ? request.payload : {}
  if (!source.requiresMatchException || !invoice.createdById || matchException.requestedById !== invoice.createdById || matchException.threeWayMatchId !== source.match.id || matchException.policyVersion !== EXACT_THREE_WAY_MATCH_EXCEPTION_POLICY_VERSION || !matchException.varianceAmount.eq(source.variance) || !matchException.priceVariance.eq(source.priceVariance) || !request || request.eventType !== "purchase.supplier_invoice.match_exception.requested" || request.schemaVersion !== 1 || request.status !== "APPLIED" || !request.processedAt || request.actorId !== invoice.createdById || request.sourceType !== "SUPPLIER_INVOICE" || request.sourceId !== invoice.id || request.payloadHash !== hashBusinessPayload(request.payload) || proof.matchExceptionId !== matchException.id || proof.supplierInvoiceId !== invoice.id || proof.threeWayMatchId !== source.match.id || proof.policyVersion !== matchException.policyVersion || proof.requesterId !== invoice.createdById || proof.expiresAt !== matchException.expiresAt.toISOString() || proof.varianceAmount !== source.variance.toFixed(2) || proof.priceVariance !== source.priceVariance.toFixed(2) || proof.reason !== matchException.reason || proof.evidenceReference !== matchException.evidenceReference || proof.sourceHash !== invoicePreparationSourceHash(invoice)) {
    throw new BusinessRuleError("Match exception source evidence changed or is incomplete; reconcile the request before review.", "INVOICE_EVIDENCE_REQUIRED")
  }

  return { request, sourceHash: proof.sourceHash }
}

export async function reviewSupplierInvoiceMatchException(
  input: ReviewSupplierInvoiceMatchExceptionInput,
  client: DbClient = db,
) {
  const parsed = reviewSupplierInvoiceMatchExceptionInputSchema.parse(input)
  const outcome = await inTransaction(client, async (tx) => {
    let matchException = await tx.supplierInvoiceMatchException.findFirst({
      where: {
        id: parsed.matchExceptionId,
        organizationId: parsed.organizationId,
      },
    })
    if (!matchException) throw new NotFoundError("Supplier invoice match exception not found for this organization.")
    await lockMatchExceptionInvoice(tx, parsed.organizationId, matchException.supplierInvoiceId)
    await tx.$queryRaw`SELECT id FROM supplier_invoice_match_exceptions WHERE id = ${parsed.matchExceptionId} AND "organizationId" = ${parsed.organizationId} FOR UPDATE`
    matchException = await tx.supplierInvoiceMatchException.findFirst({ where: { id: parsed.matchExceptionId, organizationId: parsed.organizationId } })
    if (!matchException) throw new NotFoundError("Supplier invoice match exception not found for this organization.")
    const now = new Date()
    if (matchException.requestedById === parsed.reviewedById) {
      throw new BusinessRuleError("Supplier invoice match exceptions require an independent approver.")
    }
    if (matchException.status !== SupplierInvoiceMatchExceptionStatus.OPEN) {
      throw new ConflictError("Supplier invoice match exception is no longer open for review.")
    }

    if (matchException.expiresAt <= now) {
      await expireMatchExceptionInTx(tx, matchException, parsed.reviewedById, now)
      return { kind: "expired" as const }
    }

    const approved = parsed.decision === "APPROVE"
    // Refusal closes a request; it does not authorize its underlying variance.
    // Preserve invalid historical proof and record that it could not be verified.
    let proof: Awaited<ReturnType<typeof validateMatchExceptionReviewSource>> | null = null
    try { proof = await validateMatchExceptionReviewSource(tx, matchException, parsed.organizationId) }
    catch (error) {
      if (approved || (!(error instanceof BusinessRuleError) && !(error instanceof NotFoundError))) throw error
    }
    const status = approved
      ? SupplierInvoiceMatchExceptionStatus.APPROVED
      : SupplierInvoiceMatchExceptionStatus.REJECTED
    const claim = await tx.supplierInvoiceMatchException.updateMany({
      where: {
        id: matchException.id,
        organizationId: parsed.organizationId,
        status: SupplierInvoiceMatchExceptionStatus.OPEN,
      },
      data: {
        status,
        approvedById: approved ? parsed.reviewedById : null,
        rejectedById: approved ? null : parsed.reviewedById,
        decidedAt: now,
        decisionReason: parsed.decisionReason ?? null,
      },
    })
    if (claim.count !== 1) {
      throw new ConflictError("Supplier invoice match exception review was already claimed; reload before retrying.")
    }

    const reviewedException = await tx.supplierInvoiceMatchException.findFirst({
      where: {
        id: matchException.id,
        organizationId: parsed.organizationId,
      },
    })
    if (!reviewedException) {
      throw new ConflictError("Supplier invoice match exception review evidence could not be reloaded.")
    }

    const eventResult = await recordBusinessEventInTx(tx, {
      organizationId: parsed.organizationId,
      eventType: approved
        ? "purchase.supplier_invoice.match_exception.approved"
        : "purchase.supplier_invoice.match_exception.rejected",
      eventSource: "INTERNAL",
      schemaVersion: 1,
      idempotencyKey: `supplier-invoice-match-exception:${matchException.id}:${status.toLowerCase()}`,
      payload: {
        matchExceptionId: matchException.id,
        supplierInvoiceId: matchException.supplierInvoiceId,
        threeWayMatchId: matchException.threeWayMatchId,
        policyVersion: matchException.policyVersion,
        requesterId: matchException.requestedById,
        reviewerId: parsed.reviewedById,
        decision: parsed.decision,
        requestEventId: proof?.request.id ?? null,
        sourceHash: proof?.sourceHash ?? null,
        sourceVerification: proof ? "VERIFIED" : "UNVERIFIED",
        expiresAt: matchException.expiresAt.toISOString(),
      },
      occurredAt: now,
      actorId: parsed.reviewedById,
      sourceType: AccountingSourceType.SUPPLIER_INVOICE,
      sourceId: matchException.supplierInvoiceId,
      metadata: {
        gate: "011-purchasing-ap-controls",
        decisionReason: parsed.decisionReason ?? null,
      },
      outboxMessages: [
        {
          channel: "NOTIFICATION",
          eventName: approved
            ? "supplier_invoice.match_exception.approved"
            : "supplier_invoice.match_exception.rejected",
          destination: "accounting",
          payload: {
            severity: approved ? "info" : "warning",
            matchExceptionId: matchException.id,
            supplierInvoiceId: matchException.supplierInvoiceId,
            expiresAt: matchException.expiresAt.toISOString(),
          },
        },
      ],
    })
    await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)

    await writeAudit(tx, {
      organizationId: parsed.organizationId,
      entityType: "SupplierInvoiceMatchException",
      entityId: matchException.id,
      action: approved
        ? "SUPPLIER_INVOICE_MATCH_EXCEPTION_APPROVED"
        : "SUPPLIER_INVOICE_MATCH_EXCEPTION_REJECTED",
      actorId: parsed.reviewedById,
      changes: {
        before: { status: SupplierInvoiceMatchExceptionStatus.OPEN },
        after: {
          status,
          reviewerId: parsed.reviewedById,
          decisionReason: parsed.decisionReason ?? null,
        },
      },
    })

    return {
      kind: "reviewed" as const,
      matchException: reviewedException,
      businessEventId: eventResult.event.id,
    }
  })

  if (outcome.kind === "expired") {
    throw new BusinessRuleError("Supplier invoice match exception has expired and cannot be approved.")
  }
  return outcome
}

type InvoiceApprovalSource = Prisma.SupplierInvoiceGetPayload<{ include: { lines: true; threeWayMatches: true; supplier: { select: { id: true; name: true; currentBalance: true; isActive: true; organizationId: true } } } }>

export async function validateInvoiceApprovalSource(tx: Prisma.TransactionClient, invoice: InvoiceApprovalSource, organizationId: string) {
  if (
    invoice.status !== SupplierInvoiceStatus.MATCHED &&
    invoice.status !== SupplierInvoiceStatus.DISPUTED
  ) {
    throw new BusinessRuleError("Only matched or exception-approved supplier invoices can be posted.")
  }
  const requiresMatchException = invoice.status === SupplierInvoiceStatus.DISPUTED
  const match = invoice.threeWayMatches.find((candidate) =>
    requiresMatchException
      ? candidate.status === ThreeWayMatchStatus.EXCEPTION
      : candidate.status === ThreeWayMatchStatus.MATCHED,
  )
  if (!match) {
    throw new BusinessRuleError(
      requiresMatchException
        ? "Supplier invoice requires unresolved exception evidence before posting."
        : "Supplier invoice requires matched three-way evidence before posting.",
    )
  }

  // A saved MATCHED label is not proof that the underlying amounts and receipts
  // still agree. Recompute before claiming approval or creating a liability.
  if (invoice.supplier.organizationId !== organizationId || invoice.threeWayMatches.length !== 1 || match.organizationId !== organizationId || match.supplierInvoiceId !== invoice.id || match.purchaseOrderId !== invoice.purchaseOrderId || invoice.lines.length === 0 || invoice.lines.some(line => line.organizationId !== organizationId || line.supplierInvoiceId !== invoice.id || !line.goodsReceiptLineId)) {
    throw new BusinessRuleError("Supplier invoice source evidence is missing, ambiguous or outside this organization.", "INVOICE_EVIDENCE_REQUIRED")
  }
  if (invoice.approvedById || invoice.postedAt || invoice.postedBusinessEventId || invoice.ledgerPostingBatchId || !invoice.amountPaid.eq(0) || !invoice.discount.eq(0)) {
    throw new BusinessRuleError("Supplier invoice has existing effects or unsupported adjustments; reconcile it before approval.", "INVOICE_EVIDENCE_REQUIRED")
  }
  const existingLiability = await tx.supplierLedgerEntry.findFirst({ where: { organizationId: organizationId, referenceType: "SUPPLIER_INVOICE", referenceId: invoice.id }, select: { id: true } })
  if (existingLiability) throw new BusinessRuleError("Supplier invoice already has liability evidence; reconcile it before approval.", "INVOICE_EVIDENCE_REQUIRED")
  const existingBatches = await tx.ledgerPostingBatch.findMany({ where: { organizationId: organizationId, sourceType: AccountingSourceType.SUPPLIER_INVOICE, sourceId: invoice.id }, select: { id: true }, take: 1 })
  if (existingBatches.length > 0) throw new BusinessRuleError("Supplier invoice already has posting evidence; reconcile it before approval.", "INVOICE_EVIDENCE_REQUIRED")
  const linePlans = await buildInvoiceLinePlans(tx, {
    organizationId: organizationId, supplierId: invoice.supplierId,
    purchaseOrderId: invoice.purchaseOrderId ?? undefined, excludeSupplierInvoiceId: invoice.id,
    lines: invoice.lines.map(line => ({ goodsReceiptLineId: line.goodsReceiptLineId!, purchaseOrderLineId: line.purchaseOrderLineId ?? undefined, itemId: line.itemId ?? undefined, description: line.description, quantity: line.quantity.toString(), unitCost: line.unitCost.toString(), taxRate: line.taxRate.toString() })),
  })
  const sum = (value: (line: InvoiceLinePlan) => Prisma.Decimal) => linePlans.reduce((total, line) => total.plus(value(line)), new Prisma.Decimal(0)).toDecimalPlaces(2)
  const subtotal = sum(line => line.lineSubtotal), tax = sum(line => line.taxAmount), variance = sum(line => line.priceVariance.abs()), priceVariance = sum(line => line.priceVariance)
  if (!invoice.subtotal.eq(subtotal) || !invoice.taxAmount.eq(tax) || !invoice.total.eq(subtotal.plus(tax)) || invoice.total.lte(0) || linePlans.some((plan, index) => !invoice.lines[index].taxAmount.eq(plan.taxAmount) || !invoice.lines[index].lineTotal.eq(plan.lineTotal) || invoice.lines[index].matchStatus !== (plan.priceVariance.eq(0) ? ThreeWayMatchStatus.MATCHED : ThreeWayMatchStatus.EXCEPTION)) || !match.varianceAmount.eq(variance) || !match.priceVariance.eq(priceVariance) || !match.quantityVariance.eq(0) || !match.toleranceAmount.eq(0) || requiresMatchException !== variance.gt(0)) {
    throw new BusinessRuleError("Supplier invoice totals or match variance changed; reconcile the source before approval.", "INVOICE_EVIDENCE_REQUIRED")
  }

  return { requiresMatchException, match, variance, priceVariance }
}

export async function approveSupplierInvoice(input: ApproveSupplierInvoiceInput, client: DbClient = db) {
  const parsed = approveSupplierInvoiceInputSchema.parse(input)

  const outcome = await inTransaction(client, async (tx) => {
    // Match preparation's supplier-first lock order. Different invoices for one
    // supplier must not calculate liability balances from the same old snapshot.
    await tx.$queryRaw`SELECT s.id FROM suppliers s JOIN supplier_invoices i ON i."supplierId" = s.id WHERE i.id = ${parsed.supplierInvoiceId} AND i."organizationId" = ${parsed.organizationId} AND s."organizationId" = ${parsed.organizationId} FOR UPDATE OF s`
    await tx.$queryRaw`SELECT id FROM supplier_invoices WHERE id = ${parsed.supplierInvoiceId} AND "organizationId" = ${parsed.organizationId} FOR UPDATE`
    await tx.$queryRaw`SELECT id FROM supplier_invoice_lines WHERE "supplierInvoiceId" = ${parsed.supplierInvoiceId} AND "organizationId" = ${parsed.organizationId} ORDER BY id FOR SHARE`
    await tx.$queryRaw`SELECT id FROM three_way_matches WHERE "supplierInvoiceId" = ${parsed.supplierInvoiceId} AND "organizationId" = ${parsed.organizationId} ORDER BY id FOR SHARE`
    await tx.$queryRaw`SELECT r.id FROM supplier_invoice_lines l JOIN goods_receipt_lines rl ON rl.id = l."goodsReceiptLineId" JOIN goods_receipts r ON r.id = rl."goodsReceiptId" JOIN purchase_order_lines pl ON pl.id = rl."purchaseOrderLineId" JOIN purchase_orders p ON p.id = pl."purchaseOrderId" WHERE l."supplierInvoiceId" = ${parsed.supplierInvoiceId} AND l."organizationId" = ${parsed.organizationId} AND r."organizationId" = ${parsed.organizationId} AND p."organizationId" = ${parsed.organizationId} ORDER BY r.id, rl.id FOR SHARE OF r, rl, pl, p`
    const approvalAt = new Date()
    const invoice = await tx.supplierInvoice.findFirst({
      where: {
        id: parsed.supplierInvoiceId,
        organizationId: parsed.organizationId,
        deletedAt: null,
      },
      include: {
        lines: true,
        threeWayMatches: true,
        supplier: {
          select: {
            id: true,
            name: true,
            currentBalance: true,
            isActive: true,
            organizationId: true,
          },
        },
      },
    })

    if (!invoice) throw new NotFoundError("Supplier invoice not found for this organization.")
    if (!invoice.createdById) throw new BusinessRuleError("Supplier invoice is missing maker evidence.")
    if (invoice.createdById === parsed.approvedById) {
      throw new BusinessRuleError("Supplier invoice posting requires an independent approver.")
    }

    if (
      invoice.status === SupplierInvoiceStatus.POSTED ||
      invoice.status === SupplierInvoiceStatus.PAYMENT_PENDING ||
      invoice.status === SupplierInvoiceStatus.PAID
    ) {
      if (invoice.approvedById !== parsed.approvedById) {
        throw new ConflictError("Supplier invoice was already approved by another actor.")
      }
      return {
        kind: "posted" as const,
        value: {
          supplierInvoice: invoice,
          threeWayMatch: invoice.threeWayMatches[0] ?? null,
          postingBatchId: invoice.ledgerPostingBatchId,
          businessEventId: invoice.postedBusinessEventId,
          ledgerStatus: metadataString(invoice.metadata, "ledgerStatus") ?? "UNVERIFIED",
        },
      }
    }

    const { requiresMatchException, match, variance, priceVariance } = await validateInvoiceApprovalSource(tx, invoice, parsed.organizationId)

    let activeMatchException: { id: string; expiresAt: Date } | null = null
    if (requiresMatchException) {
      const exception = await tx.supplierInvoiceMatchException.findFirst({
        where: {
          organizationId: parsed.organizationId,
          supplierInvoiceId: invoice.id,
          threeWayMatchId: match.id,
          status: SupplierInvoiceMatchExceptionStatus.APPROVED,
        },
        orderBy: { decidedAt: "desc" },
      })
      if (!exception) {
        throw new BusinessRuleError(
          "Supplier invoice posting is blocked until its exact-match variance has an approved active exception.",
        )
      }
      activeMatchException = exception
      if (activeMatchException.expiresAt <= approvalAt) {
        await expireMatchExceptionInTx(tx, exception, parsed.approvedById, approvalAt)
        return { kind: "expired" as const }
      }
      if (exception.policyVersion !== EXACT_THREE_WAY_MATCH_EXCEPTION_POLICY_VERSION || exception.requestedById !== invoice.createdById || !exception.approvedById || exception.approvedById === exception.requestedById || !exception.decidedAt || exception.decidedAt > approvalAt || !exception.varianceAmount.eq(variance) || !exception.priceVariance.eq(priceVariance)) {
        throw new BusinessRuleError("Approved match exception does not cover the current invoice variance.", "INVOICE_EVIDENCE_REQUIRED")
      }
    }
    if (!invoice.supplier.isActive) throw new BusinessRuleError("Supplier is inactive.")

    const claim = await tx.supplierInvoice.updateMany({
      where: {
        id: invoice.id,
        organizationId: parsed.organizationId,
        status: invoice.status,
        approvedById: null,
        deletedAt: null,
      },
      data: {
        status: SupplierInvoiceStatus.POSTED,
        approvedById: parsed.approvedById,
        postedAt: approvalAt,
      },
    })
    if (claim.count !== 1) {
      throw new ConflictError("Supplier invoice approval was already claimed; reload before retrying.")
    }

    if (activeMatchException) {
      const resolved = await tx.supplierInvoiceMatchException.updateMany({
        where: {
          id: activeMatchException.id,
          organizationId: parsed.organizationId,
          status: SupplierInvoiceMatchExceptionStatus.APPROVED,
          expiresAt: { gt: approvalAt },
        },
        data: {
          status: SupplierInvoiceMatchExceptionStatus.RESOLVED,
          resolvedById: parsed.approvedById,
          resolvedAt: approvalAt,
        },
      })
      if (resolved.count !== 1) {
        throw new ConflictError("Approved match exception is no longer active; reload before posting.")
      }
      const acceptedMatch = await tx.threeWayMatch.updateMany({
        where: {
          id: match.id,
          organizationId: parsed.organizationId,
          status: ThreeWayMatchStatus.EXCEPTION,
        },
        data: { status: ThreeWayMatchStatus.APPROVED_EXCEPTION },
      })
      if (acceptedMatch.count !== 1) {
        throw new ConflictError("Three-way match exception evidence changed; reload before posting.")
      }
    }

    const period = await getOpenPeriodForDate(parsed.organizationId, invoice.invoiceDate, tx)
    const countryPackStatus = await resolveAPCountryPackStatus(tx, {
      organizationId: parsed.organizationId,
      documentDate: invoice.invoiceDate,
      taxAmount: invoice.taxAmount,
      purpose: "SUPPLIER_INVOICE",
    })
    const documentHash =
      invoice.documentHash ??
      prefixedHash({
        invoiceId: invoice.id,
        supplierId: invoice.supplierId,
        invoiceNumber: invoice.invoiceNumber,
        total: invoice.total.toFixed(2),
        currency: invoice.currency,
      })

    const receiptRecognition = await resolveInvoiceReceiptRecognition(tx, {
      organizationId: parsed.organizationId, supplierId: invoice.supplierId, invoiceId: invoice.id,
      currency: invoice.currency, subtotal: invoice.subtotal, total: invoice.total,
      taxAmount: invoice.taxAmount, lines: invoice.lines,
    })
    const balanceAfter = decimal2(invoice.supplier.currentBalance).plus(invoice.total).toDecimalPlaces(2)
    await tx.supplier.update({
      where: { id: invoice.supplier.id },
      data: { currentBalance: balanceAfter },
    })
    await tx.supplierLedgerEntry.create({
      data: {
        organizationId: parsed.organizationId,
        supplierId: invoice.supplier.id,
        entryDate: invoice.invoiceDate,
        type: LedgerEntryType.PURCHASE,
        debit: invoice.total,
        credit: new Prisma.Decimal(0),
        balanceAfter,
        description: `Supplier invoice ${invoice.invoiceNumber}`,
        referenceType: "SUPPLIER_INVOICE",
        referenceId: invoice.id,
      },
    })

    const postingResult = await createAPLedgerPosting(tx, {
      organizationId: parsed.organizationId,
      periodId: period.id,
      sourceType: AccountingSourceType.SUPPLIER_INVOICE,
      sourceId: invoice.id,
      sourceNumber: invoice.invoiceNumber,
      sourceDate: invoice.invoiceDate,
      postingPurpose: AccountingPostingPurpose.SUPPLIER_INVOICE,
      actorId: parsed.approvedById,
      supplierId: invoice.supplier.id,
      currency: invoice.currency,
      journalType: JournalType.PURCHASE,
      journalPrefix: "APINV",
      memo: `Supplier invoice ${invoice.invoiceNumber}`,
      documentHash,
      amounts: receiptRecognition.amounts,
      conditionContext: receiptRecognition.conditionContext,
      blockerCode: "AP_POSTING_RULE_REVIEW",
      blockerMessage: "Supplier invoice AP posting requires configured SYSCOHADA purchase/input VAT/AP rules.",
      metadata: {
        invoiceNumber: invoice.invoiceNumber,
        supplierId: invoice.supplier.id,
        total: invoice.total.toFixed(2),
        currency: invoice.currency,
        ...(receiptRecognition.recognition ? { receiptRecognition: receiptRecognition.recognition } : {}),
        countryPackStatus: countryPackStatus.countryPackStatus,
        countryPackVersion: countryPackStatus.countryPackVersion,
        countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
        taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
        withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
      },
    })
    const ledgerBatch = postingResult.ledgerBatch

    const eventResult = await recordBusinessEventInTx(tx, {
      organizationId: parsed.organizationId,
      eventType: "purchase.supplier_invoice.posted",
      eventSource: "INTERNAL",
      schemaVersion: 1,
      idempotencyKey: `supplier-invoice:${invoice.id}:posted`,
      payload: {
        invoiceId: invoice.id,
        supplierId: invoice.supplier.id,
        purchaseOrderId: invoice.purchaseOrderId,
        invoiceNumber: invoice.invoiceNumber,
        total: invoice.total.toFixed(2),
        currency: invoice.currency,
        threeWayMatchId: match.id,
        ledgerPostingBatchId: ledgerBatch.id,
        journalEntryId: postingResult.journalEntryId ?? null,
        ledgerStatus: postingResult.ledgerStatus,
        makerId: invoice.createdById,
        ...(receiptRecognition.recognition ? { receiptRecognitionHash: hashBusinessPayload(receiptRecognition.recognition) } : {}),
        approverId: parsed.approvedById,
        matchExceptionId: activeMatchException?.id ?? null,
        matchStatus: activeMatchException
          ? ThreeWayMatchStatus.APPROVED_EXCEPTION
          : ThreeWayMatchStatus.MATCHED,
      },
      occurredAt: approvalAt,
      actorId: parsed.approvedById,
      sourceType: AccountingSourceType.SUPPLIER_INVOICE,
      sourceId: invoice.id,
      postingBatchId: ledgerBatch.id,
      documentHash,
      metadata: {
        ledgerStatus: postingResult.ledgerStatus,
        blockerCode: postingResult.blockerCode ?? null,
        countryPackStatus: countryPackStatus.countryPackStatus,
        countryPackVersion: countryPackStatus.countryPackVersion,
        countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
        gate: "011-purchasing-ap-controls",
        makerCheckerVerified: true,
      },
      outboxMessages: [
        {
          channel: "NOTIFICATION",
          eventName: "supplier_invoice.posted",
          destination: "accounting",
          payload: {
            severity: postingResult.ledgerStatus === "POSTED" ? "info" : "warning",
            invoiceId: invoice.id,
            supplierId: invoice.supplier.id,
            total: invoice.total.toFixed(2),
            ledgerStatus: postingResult.ledgerStatus,
            blockerCode: postingResult.blockerCode ?? null,
          },
        },
      ],
    })

    await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)
    const postedInvoice = await tx.supplierInvoice.update({
      where: { id: invoice.id },
      data: {
        ledgerPostingBatchId: ledgerBatch.id,
        postedBusinessEventId: eventResult.event.id,
        metadata: safeJson({
          ...asRecord(invoice.metadata),
          ...(receiptRecognition.recognition ? { receiptRecognition: receiptRecognition.recognition } : {}),
          ledgerStatus: postingResult.ledgerStatus,
          ledgerBlockerCode: postingResult.blockerCode ?? null,
          ledgerBlockerMessage: postingResult.blockerMessage ?? null,
          journalEntryId: postingResult.journalEntryId ?? null,
          accountingSourceLinkId: postingResult.accountingSourceLinkId ?? null,
          countryPackStatus: countryPackStatus.countryPackStatus,
          countryCode: countryPackStatus.countryCode,
          countryPackVersion: countryPackStatus.countryPackVersion,
          countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
          taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
          withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
          operatorActionRequired: countryPackStatus.operatorActionRequired,
          countryPackErrorCode: countryPackStatus.errorCode ?? null,
          countryPackErrorMessage: countryPackStatus.errorMessage ?? null,
          makerCheckerVerified: true,
        }),
      },
      include: { lines: true, threeWayMatches: true },
    })

    await writeAudit(tx, {
      organizationId: parsed.organizationId,
      entityType: "SupplierInvoice",
      entityId: invoice.id,
      action: "SUPPLIER_INVOICE_APPROVED_AND_POSTED",
      actorId: parsed.approvedById,
      changes: {
        before: {
          status: invoice.status,
          createdById: invoice.createdById,
        },
        after: {
          status: SupplierInvoiceStatus.POSTED,
          approvedById: parsed.approvedById,
          ledgerPostingBatchId: ledgerBatch.id,
          businessEventId: eventResult.event.id,
          ledgerStatus: postingResult.ledgerStatus,
        },
      },
    })

    return {
      kind: "posted" as const,
      value: {
        supplierInvoice: postedInvoice,
        threeWayMatch: activeMatchException
          ? { ...match, status: ThreeWayMatchStatus.APPROVED_EXCEPTION }
          : match,
        postingBatchId: ledgerBatch.id,
        businessEventId: eventResult.event.id,
        ledgerStatus: postingResult.ledgerStatus,
      },
    }
  })

  if (outcome.kind === "expired") {
    throw new BusinessRuleError("Supplier invoice match exception has expired; posting remains blocked.")
  }
  return outcome.value
}
export async function requestSupplierBankChange(input: RequestSupplierBankChangeInput, client: DbClient = db) {
  const parsed = requestSupplierBankChangeInputSchema.parse(input)

  return inTransaction(client, async (tx) => {
    const supplier = await assertSupplier(tx, parsed.organizationId, parsed.supplierId)
    if (parsed.bankAccountId) {
      const bankAccount = await tx.supplierBankAccount.findFirst({
        where: {
          id: parsed.bankAccountId,
          organizationId: parsed.organizationId,
          supplierId: parsed.supplierId,
          deletedAt: null,
        },
        select: { id: true },
      })
      if (!bankAccount) throw new NotFoundError("Supplier bank account not found for this supplier.")
    }

    const requestPayload = {
      supplierId: supplier.id,
      bankAccountId: parsed.bankAccountId ?? null,
      bankName: parsed.bankName ?? null,
      accountName: parsed.accountName ?? null,
      accountNumberHash: hashSecret(parsed.accountNumber),
      mobileMoneyProvider: parsed.mobileMoneyProvider ?? null,
      mobileMoneyPhoneHash: hashSecret(parsed.mobileMoneyPhone),
      requestedById: parsed.requestedById,
    }

    const change = await tx.supplierBankChangeRequest.create({
      data: {
        organizationId: parsed.organizationId,
        supplierId: supplier.id,
        bankAccountId: parsed.bankAccountId ?? null,
        status: SupplierBankChangeStatus.PENDING,
        requestedById: parsed.requestedById,
        reason: parsed.reason ?? null,
        newBankName: parsed.bankName ?? null,
        newAccountName: parsed.accountName ?? null,
        newAccountNumberMasked: maskSecret(parsed.accountNumber),
        newAccountNumberHash: hashSecret(parsed.accountNumber),
        newMobileMoneyProvider: parsed.mobileMoneyProvider ?? null,
        newMobileMoneyPhoneMasked: maskSecret(parsed.mobileMoneyPhone),
        newMobileMoneyPhoneHash: hashSecret(parsed.mobileMoneyPhone),
        changeHash: prefixedHash(requestPayload),
        documentHash: parsed.documentHash ?? prefixedHash(requestPayload),
        metadata: parsed.metadata ? safeJson(parsed.metadata) : undefined,
      },
    })

    const eventResult = await recordBusinessEventInTx(tx, {
      organizationId: parsed.organizationId,
      eventType: "supplier.bank_change.requested",
      eventSource: "INTERNAL",
      schemaVersion: 1,
      idempotencyKey: `supplier-bank-change-requested:${change.id}`,
      payload: {
        changeRequestId: change.id,
        supplierId: supplier.id,
        bankAccountId: parsed.bankAccountId ?? null,
        changeHash: change.changeHash,
      },
      occurredAt: change.requestedAt,
      actorId: parsed.requestedById,
      documentHash: change.documentHash ?? undefined,
      metadata: { gate: "011-purchasing-ap-controls" },
      outboxMessages: [
        {
          channel: "NOTIFICATION",
          eventName: "supplier_bank_change.pending_approval",
          destination: "manager",
          payload: {
            severity: "warning",
            changeRequestId: change.id,
            supplierId: supplier.id,
            supplierName: supplier.name,
          },
        },
      ],
    })
    await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)
    await writeAudit(tx, {
      organizationId: parsed.organizationId,
      entityType: "SupplierBankChangeRequest",
      entityId: change.id,
      action: "SUPPLIER_BANK_CHANGE_REQUESTED",
      actorId: parsed.requestedById,
      changes: {
        after: { supplierId: supplier.id, changeHash: change.changeHash },
      },
    })

    return { bankChangeRequest: change, businessEventId: eventResult.event.id }
  })
}

export async function approveSupplierBankChange(input: ApproveSupplierBankChangeInput, client: DbClient = db) {
  const parsed = approveSupplierBankChangeInputSchema.parse(input)

  return inTransaction(client, async (tx) => {
    const change = await tx.supplierBankChangeRequest.findFirst({
      where: {
        id: parsed.changeRequestId,
        organizationId: parsed.organizationId,
        status: SupplierBankChangeStatus.PENDING,
      },
      include: { supplier: true },
    })

    if (!change) throw new NotFoundError("Pending supplier bank change request not found.")
    if (change.requestedById === parsed.approvedById) {
      throw new BusinessRuleError("A separate approver is required for supplier bank changes.")
    }

    const approvedAt = new Date()
    const existingPrimary = await tx.supplierBankAccount.count({
      where: {
        organizationId: parsed.organizationId,
        supplierId: change.supplierId,
        status: SupplierBankAccountStatus.APPROVED,
        isPrimary: true,
        deletedAt: null,
      },
    })

    const accountData = {
      organizationId: parsed.organizationId,
      supplierId: change.supplierId,
      bankName: change.newBankName,
      accountName: change.newAccountName,
      accountNumberMasked: change.newAccountNumberMasked,
      accountNumberHash: change.newAccountNumberHash,
      mobileMoneyProvider: change.newMobileMoneyProvider,
      mobileMoneyPhoneMasked: change.newMobileMoneyPhoneMasked,
      mobileMoneyPhoneHash: change.newMobileMoneyPhoneHash,
      status: SupplierBankAccountStatus.APPROVED,
      requestedById: change.requestedById,
      approvedById: parsed.approvedById,
      approvedAt,
      evidenceHash: change.changeHash,
      documentHash: parsed.documentHash ?? change.documentHash,
      isPrimary: existingPrimary === 0,
      metadata: safeJson({
        approvedFromChangeRequestId: change.id,
        gate: "011-purchasing-ap-controls",
      }),
    }

    const bankAccount = change.bankAccountId
      ? await tx.supplierBankAccount.update({
          where: { id: change.bankAccountId },
          data: accountData,
        })
      : await tx.supplierBankAccount.create({ data: accountData })

    const approvedChange = await tx.supplierBankChangeRequest.update({
      where: { id: change.id },
      data: {
        status: SupplierBankChangeStatus.APPROVED,
        bankAccountId: bankAccount.id,
        approvedById: parsed.approvedById,
        approvedAt,
      },
    })

    const eventResult = await recordBusinessEventInTx(tx, {
      organizationId: parsed.organizationId,
      eventType: "supplier.bank_change.approved",
      eventSource: "INTERNAL",
      schemaVersion: 1,
      idempotencyKey: `supplier-bank-change-approved:${approvedChange.id}`,
      payload: {
        changeRequestId: approvedChange.id,
        supplierId: change.supplierId,
        bankAccountId: bankAccount.id,
        changeHash: approvedChange.changeHash,
      },
      occurredAt: approvedAt,
      actorId: parsed.approvedById,
      documentHash: approvedChange.documentHash ?? undefined,
      metadata: { gate: "011-purchasing-ap-controls" },
      outboxMessages: [
        {
          channel: "NOTIFICATION",
          eventName: "supplier_bank_change.approved",
          destination: "accounting",
          payload: {
            severity: "info",
            changeRequestId: approvedChange.id,
            supplierId: change.supplierId,
            bankAccountId: bankAccount.id,
          },
        },
      ],
    })
    await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)
    await writeAudit(tx, {
      organizationId: parsed.organizationId,
      entityType: "SupplierBankChangeRequest",
      entityId: change.id,
      action: "SUPPLIER_BANK_CHANGE_APPROVED",
      actorId: parsed.approvedById,
      changes: {
        before: { status: SupplierBankChangeStatus.PENDING },
        after: {
          status: SupplierBankChangeStatus.APPROVED,
          bankAccountId: bankAccount.id,
        },
      },
    })

    return {
      bankChangeRequest: approvedChange,
      bankAccount,
      businessEventId: eventResult.event.id,
    }
  })
}

export async function approveSupplierBankChangeWithControls(
  input: ApproveSupplierBankChangeInput,
  control: APControlActorContext,
  client: DbClient = db,
) {
  const parsed = approveSupplierBankChangeInputSchema.parse(input)
  assertControlActorMatches(control, parsed.organizationId, [parsed.approvedById])

  const change = await loadSupplierBankChangeApprovalSubject(client, parsed.organizationId, parsed.changeRequestId)
  const controlInput = sensitiveInput(control, {
    action: "supplier.bank-change.approve",
    resourceType: "SupplierBankChangeRequest",
    resourceId: parsed.changeRequestId,
    subjectActorId: change?.requestedById ?? null,
    metadata: {
      supplierId: change?.supplierId,
    },
  })

  await auditDeniedSensitiveAction(client, controlInput)
  return inTransaction(client, async (tx) => {
    await auditAllowedSensitiveAction(tx, controlInput)
    return approveSupplierBankChange(parsed, tx)
  })
}

export async function approveSupplierPayment(input: ApproveSupplierPaymentInput, client: DbClient = db) {
  const parsed = approveSupplierPaymentInputSchema.parse(input)
  const paymentDate = parseDate(parsed.paymentDate)
  const method = parsed.method as PaymentMethod
  const idempotencyPayloadHash = parsed.idempotencyKey
    ? prefixedHash({
        operation: "approveSupplierPayment",
        supplierPaymentRequestId: parsed.supplierPaymentRequestId,
        supplierId: parsed.supplierId,
        bankAccountId: parsed.bankAccountId,
        method,
        paymentDate: paymentDate.toISOString(),
        requestedById: parsed.requestedById,
        approvedById: parsed.approvedById,
        allocations: [...parsed.allocations]
          .map((allocation) => ({
            supplierInvoiceId: allocation.supplierInvoiceId,
            amount: decimal2(allocation.amount).toFixed(2),
          }))
          .sort((left, right) => left.supplierInvoiceId.localeCompare(right.supplierInvoiceId)),
      })
    : null

  return inTransaction(client, async (tx) => {
    if (parsed.supplierPaymentRequestId) await tx.$queryRaw`SELECT id FROM supplier_payments WHERE id = ${parsed.supplierPaymentRequestId} AND "organizationId" = ${parsed.organizationId} FOR UPDATE`
    const request = parsed.supplierPaymentRequestId ? await assertPaymentRequestApprovalTerms(tx, parsed) : null
    await lockSupplierPaymentSources(tx, parsed.organizationId, parsed.supplierId, parsed.allocations.map(allocation => allocation.supplierInvoiceId))
    const supplier = await assertSupplier(tx, parsed.organizationId, parsed.supplierId)

    if (parsed.requestedById === parsed.approvedById) {
      throw new BusinessRuleError("A separate approver is required before approving supplier payments.")
    }

    if (parsed.idempotencyKey) {
      const existing = await tx.supplierPayment.findFirst({
        where: {
          organizationId: parsed.organizationId,
          idempotencyKey: parsed.idempotencyKey,
          deletedAt: null,
        },
        include: { allocations: true },
      })
      if (existing) {
        if (request && existing.id !== request.payment.id) throw new ConflictError("This approval reference belongs to another payment request.")
        assertIdempotencyPayloadMatches(
          existing.metadata,
          idempotencyPayloadHash,
          "Supplier payment approval idempotency key was reused with a different payload.",
          "approvalIdempotencyPayloadHash",
        )
        return {
          supplierPayment: existing,
          businessEventId: existing.postedBusinessEventId,
          approvalStatus: "IDEMPOTENT_REPLAY" as const,
        }
      }
    }

    if (request && request.payment.status !== "DRAFT") throw new ConflictError("Payment request is no longer awaiting approval.")
    const bankAccount = await tx.supplierBankAccount.findFirst({
      where: {
        id: parsed.bankAccountId,
        organizationId: parsed.organizationId,
        supplierId: parsed.supplierId,
        deletedAt: null,
      },
      select: { id: true, status: true },
    })
    if (!bankAccount || bankAccount.status !== SupplierBankAccountStatus.APPROVED) {
      throw new BusinessRuleError("Payment approval is blocked until the supplier bank destination is approved.")
    }

    const pendingBankChanges = await tx.supplierBankChangeRequest.count({
      where: {
        organizationId: parsed.organizationId,
        supplierId: parsed.supplierId,
        status: SupplierBankChangeStatus.PENDING,
      },
    })
    if (pendingBankChanges > 0) {
      throw new BusinessRuleError("Payment approval is blocked while a supplier bank change is pending approval.")
    }

    const allocationIds = parsed.allocations.map((allocation) => allocation.supplierInvoiceId)
    if (allocationIds.length !== new Set(allocationIds).size) {
      throw new BusinessRuleError("Supplier payment cannot contain duplicate invoice allocations.")
    }

    const invoices = await tx.supplierInvoice.findMany({
      where: {
        id: { in: allocationIds },
        organizationId: parsed.organizationId,
        supplierId: parsed.supplierId,
        deletedAt: null,
        status: {
          in: [SupplierInvoiceStatus.POSTED, SupplierInvoiceStatus.PAYMENT_PENDING],
        },
      },
    })

    if (invoices.length !== allocationIds.length) {
      throw new BusinessRuleError("Supplier payment can only apply to posted unpaid supplier invoices.")
    }

    const balances = await readSupplierPaymentBalances(tx, parsed.organizationId, invoices, normalizeCurrency(invoices[0]?.currency))
    const invoiceById = new Map(invoices.map((invoice) => [invoice.id, invoice]))
    let totalPayment = new Prisma.Decimal(0)
    const allocationPlans = parsed.allocations.map((allocation) => {
      const invoice = invoiceById.get(allocation.supplierInvoiceId)
      if (!invoice) throw new BusinessRuleError("Supplier payment allocation invoice is not payable.")
      const amount = decimal2(allocation.amount)
      if (amount.lte(0)) throw new BusinessRuleError("Supplier payment allocation amount must be greater than zero.")
      const outstanding = balances.get(invoice.id)!
      if (amount.gt(outstanding)) {
        throw new BusinessRuleError("Supplier payment allocation exceeds outstanding supplier invoice balance.")
      }
      totalPayment = totalPayment.plus(amount).toDecimalPlaces(2)
      return { invoice, amount }
    })

    if (totalPayment.lte(0)) throw new BusinessRuleError("Supplier payment amount must be greater than zero.")

    const countryPackStatus = await resolveAPCountryPackStatus(tx, {
      organizationId: parsed.organizationId,
      documentDate: paymentDate,
      taxAmount: new Prisma.Decimal(0),
      purpose: "SUPPLIER_PAYMENT",
    })

    const paymentNumber = await nextSupplierPaymentNumber(tx, parsed.organizationId, paymentDate)
    const evidencePayload = {
      supplierId: supplier.id,
      bankAccountId: bankAccount.id,
      paymentNumber,
      amount: totalPayment.toFixed(2),
      method,
      allocationIds,
      requestedById: parsed.requestedById,
      approvedById: parsed.approvedById,
    }
    const documentHash = parsed.documentHash ?? prefixedHash(evidencePayload)
    const evidenceHash = parsed.evidenceHash ?? prefixedHash({ ...evidencePayload, status: "APPROVED" })

    const paymentWrite = {
      data: {
        organizationId: parsed.organizationId,
        supplierId: supplier.id,
        bankAccountId: bankAccount.id,
        paymentNumber,
        status: SupplierPaymentStatus.APPROVED,
        method,
        amount: totalPayment,
        currency: normalizeCurrency(invoices[0]?.currency),
        paymentDate,
        idempotencyKey: parsed.idempotencyKey ?? null,
        documentHash,
        evidenceHash,
        requestedById: parsed.requestedById,
        approvedById: parsed.approvedById,
        approvedAt: paymentDate,
        releasedById: null,
        releasedAt: null,
        notes: parsed.notes ?? null,
        metadata: safeJson({
          ...asRecord(request?.payment.metadata),
          gate: "011-purchasing-ap-controls",
          approvalStatus: "APPROVED",
          bankDestinationEvidence: "approved",
          approvalIdempotencyPayloadHash: idempotencyPayloadHash,
          idempotencyPayloadHash,
          countryPackStatus: countryPackStatus.countryPackStatus,
          countryCode: countryPackStatus.countryCode,
          countryPackVersion: countryPackStatus.countryPackVersion,
          countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
          taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
          withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
          operatorActionRequired: countryPackStatus.operatorActionRequired,
          countryPackErrorCode: countryPackStatus.errorCode ?? null,
          countryPackErrorMessage: countryPackStatus.errorMessage ?? null,
        }),
        allocations: {
          create: allocationPlans.map((allocation) => ({
            organizationId: parsed.organizationId,
            supplierInvoiceId: allocation.invoice.id,
            amount: allocation.amount,
          })),
        },
      },
      include: { allocations: true },
    } satisfies Prisma.SupplierPaymentCreateArgs
    const { allocations: _allocations, ...paymentData } = paymentWrite.data
    const payment = request ? await tx.supplierPayment.update({ where: { id: request.payment.id }, data: paymentData, include: { allocations: true } }) : await tx.supplierPayment.create(paymentWrite)

    const eventResult = await recordBusinessEventInTx(tx, {
      organizationId: parsed.organizationId,
      eventType: "supplier.payment.approved",
      eventSource: "INTERNAL",
      schemaVersion: 1,
      idempotencyKey: parsed.idempotencyKey
        ? `${parsed.idempotencyKey}:approved`
        : `supplier-payment-approved:${payment.id}`,
      payload: {
        supplierPaymentId: payment.id,
        supplierId: supplier.id,
        bankAccountId: bankAccount.id,
        amount: totalPayment.toFixed(2),
        method,
        allocationIds,
      },
      occurredAt: paymentDate,
      actorId: parsed.approvedById,
      documentHash,
      metadata: {
        approvalStatus: "APPROVED",
        countryPackStatus: countryPackStatus.countryPackStatus,
        countryPackVersion: countryPackStatus.countryPackVersion,
        countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
        gate: "011-purchasing-ap-controls",
      },
      outboxMessages: [
        {
          channel: "NOTIFICATION",
          eventName: "supplier_payment.approved",
          destination: "accounting",
          payload: {
            severity: "warning",
            supplierPaymentId: payment.id,
            supplierId: supplier.id,
            amount: totalPayment.toFixed(2),
            approvalStatus: "APPROVED",
          },
        },
      ],
    })
    await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)
    await writeAudit(tx, {
      organizationId: parsed.organizationId,
      entityType: "SupplierPayment",
      entityId: payment.id,
      action: "SUPPLIER_PAYMENT_APPROVED",
      actorId: parsed.approvedById,
      changes: {
        after: {
          supplierId: supplier.id,
          bankAccountId: bankAccount.id,
          amount: totalPayment.toFixed(2),
          paymentNumber,
          requestedById: parsed.requestedById,
          approvedById: parsed.approvedById,
          businessEventId: eventResult.event.id,
        },
      },
    })

    return {
      supplierPayment: payment,
      businessEventId: eventResult.event.id,
      approvalStatus: "APPROVED" as const,
    }
  })
}

export async function approveSupplierPaymentWithControls(
  input: ApproveSupplierPaymentInput,
  control: APControlActorContext,
  client: DbClient = db,
) {
  const parsed = approveSupplierPaymentInputSchema.parse(input)
  assertControlActorMatches(control, parsed.organizationId, [parsed.approvedById])

  const controlInput = sensitiveInput(control, {
    action: "supplier.payment.approve",
    resourceType: "SupplierPayment",
    resourceId: parsed.idempotencyKey ?? parsed.supplierId,
    subjectActorId: parsed.requestedById,
    metadata: {
      supplierId: parsed.supplierId,
      bankAccountId: parsed.bankAccountId,
      allocationCount: parsed.allocations.length,
    },
  })

  await auditDeniedSensitiveAction(client, controlInput)
  return inTransaction(client, async (tx) => {
    await assertPaymentRequestApprovalTerms(tx, parsed)
    await auditAllowedSensitiveAction(tx, controlInput)
    return approveSupplierPayment(parsed, tx)
  })
}

export async function releaseSupplierPayment(input: ReleaseSupplierPaymentInput, client: DbClient = db) {
  const parsed = releaseSupplierPaymentInputSchema.parse(input)

  return inTransaction(client, async (tx) => {
    await tx.$queryRaw`SELECT id FROM supplier_payments WHERE "organizationId" = ${parsed.organizationId} AND id = ${parsed.supplierPaymentId} FOR UPDATE`
    const approvedPayment = await tx.supplierPayment.findFirst({
      where: {
        id: parsed.supplierPaymentId,
        organizationId: parsed.organizationId,
        deletedAt: null,
      },
      include: { allocations: true },
    })

    if (!approvedPayment) throw new NotFoundError("Supplier payment approval evidence was not found.")

    const paymentDate = parseDate(parsed.paymentDate, approvedPayment.paymentDate ?? new Date())
    const releasedById = parsed.releasedById
    const requestedById = approvedPayment.requestedById
    const approvedById = approvedPayment.approvedById
    const bankAccountId = approvedPayment.bankAccountId
    const method = approvedPayment.method as PaymentMethod
    const releaseIdempotencyPayloadHash = parsed.idempotencyKey
      ? prefixedHash({
          operation: "releaseSupplierPayment",
          supplierPaymentId: approvedPayment.id,
          paymentDate: paymentDate.toISOString(),
          requestedById,
          approvedById,
          releasedById,
        })
      : null

    if (
      approvedPayment.status === SupplierPaymentStatus.RELEASED ||
      approvedPayment.status === SupplierPaymentStatus.POSTED
    ) {
      assertIdempotencyPayloadMatches(
        approvedPayment.metadata,
        releaseIdempotencyPayloadHash,
        "Supplier payment release idempotency key was reused with a different payload.",
        "releaseIdempotencyPayloadHash",
      )
      if (releaseIdempotencyPayloadHash && metadataString(approvedPayment.metadata, "releaseIdempotencyPayloadHash")) {
        return {
          supplierPayment: approvedPayment,
          postingBatchId: approvedPayment.ledgerPostingBatchId,
          businessEventId: approvedPayment.postedBusinessEventId,
          ledgerStatus: "IDEMPOTENT_REPLAY" as const,
        }
      }
      throw new BusinessRuleError("Supplier payment has already been released.")
    }

    if (approvedPayment.status !== SupplierPaymentStatus.APPROVED) {
      throw new BusinessRuleError("Supplier payment must be approved before release.")
    }
    if (!approvedById) {
      throw new BusinessRuleError("Supplier payment approval evidence is incomplete.")
    }
    if (!bankAccountId) {
      throw new BusinessRuleError("Supplier payment approval evidence is missing the bank destination.")
    }
    if (requestedById === approvedById) {
      throw new BusinessRuleError("A separate approver is required before releasing supplier payments.")
    }
    if (requestedById === releasedById) {
      throw new BusinessRuleError("A separate releaser is required before releasing supplier payments.")
    }
    if (approvedById === releasedById) {
      throw new BusinessRuleError("A separate releaser is required from the supplier payment approver before release.")
    }

    if (parsed.supplierId && parsed.supplierId !== approvedPayment.supplierId) {
      throw new BusinessRuleError("Supplier payment release payload does not match the approved supplier.")
    }
    if (parsed.bankAccountId && parsed.bankAccountId !== bankAccountId) {
      throw new BusinessRuleError("Supplier payment release payload does not match the approved bank destination.")
    }
    if (parsed.method && parsed.method !== method) {
      throw new BusinessRuleError("Supplier payment release payload does not match the approved payment method.")
    }
    if (parsed.requestedById && parsed.requestedById !== requestedById) {
      throw new BusinessRuleError("Supplier payment release payload does not match the original requester.")
    }
    if (parsed.approvedById && parsed.approvedById !== approvedById) {
      throw new BusinessRuleError("Supplier payment release payload does not match the stored approver.")
    }

    const storedAllocationSignature = approvedPayment.allocations
      .map((allocation) => `${allocation.supplierInvoiceId}:${decimal2(allocation.amount).toFixed(2)}`)
      .sort()
      .join("|")
    if (parsed.allocations) {
      const releaseAllocationSignature = parsed.allocations
        .map((allocation) => `${allocation.supplierInvoiceId}:${decimal2(allocation.amount).toFixed(2)}`)
        .sort()
        .join("|")
      if (releaseAllocationSignature !== storedAllocationSignature) {
        throw new BusinessRuleError("Supplier payment release allocations do not match the approved payment.")
      }
    }

    await lockSupplierPaymentSources(tx, parsed.organizationId, approvedPayment.supplierId, approvedPayment.allocations.map(allocation => allocation.supplierInvoiceId))
    const supplier = await assertSupplier(tx, parsed.organizationId, approvedPayment.supplierId)

    const bankAccount = await tx.supplierBankAccount.findFirst({
      where: {
        id: bankAccountId,
        organizationId: parsed.organizationId,
        supplierId: approvedPayment.supplierId,
        deletedAt: null,
      },
      select: { id: true, status: true },
    })
    if (!bankAccount || bankAccount.status !== SupplierBankAccountStatus.APPROVED) {
      throw new BusinessRuleError("Payment is blocked until the supplier bank destination is approved.")
    }

    const pendingBankChanges = await tx.supplierBankChangeRequest.count({
      where: {
        organizationId: parsed.organizationId,
        supplierId: approvedPayment.supplierId,
        status: SupplierBankChangeStatus.PENDING,
      },
    })
    if (pendingBankChanges > 0) {
      throw new BusinessRuleError("Payment is blocked while a supplier bank change is pending approval.")
    }

    const allocationIds = approvedPayment.allocations.map((allocation) => allocation.supplierInvoiceId)
    if (allocationIds.length === 0) {
      throw new BusinessRuleError("Supplier payment approval has no invoice allocations.")
    }
    if (allocationIds.length !== new Set(allocationIds).size) {
      throw new BusinessRuleError("Supplier payment cannot contain duplicate invoice allocations.")
    }

    const invoices = await tx.supplierInvoice.findMany({
      where: {
        id: { in: allocationIds },
        organizationId: parsed.organizationId,
        supplierId: approvedPayment.supplierId,
        deletedAt: null,
        status: {
          in: [SupplierInvoiceStatus.POSTED, SupplierInvoiceStatus.PAYMENT_PENDING],
        },
      },
    })

    if (invoices.length !== allocationIds.length) {
      throw new BusinessRuleError("Supplier payment can only apply to posted unpaid supplier invoices.")
    }

    const balances = await readSupplierPaymentBalances(tx, parsed.organizationId, invoices, normalizeCurrency(approvedPayment.currency))
    const invoiceById = new Map(invoices.map((invoice) => [invoice.id, invoice]))
    let totalPayment = new Prisma.Decimal(0)
    const allocationPlans = approvedPayment.allocations.map((allocation) => {
      const invoice = invoiceById.get(allocation.supplierInvoiceId)
      if (!invoice) throw new BusinessRuleError("Supplier payment allocation invoice is not payable.")
      const amount = decimal2(allocation.amount)
      if (amount.lte(0)) throw new BusinessRuleError("Supplier payment allocation amount must be greater than zero.")
      const outstanding = balances.get(invoice.id)!
      if (amount.gt(outstanding)) {
        throw new BusinessRuleError("Supplier payment allocation exceeds outstanding supplier invoice balance.")
      }
      totalPayment = totalPayment.plus(amount).toDecimalPlaces(2)
      return { invoice, amount, outstanding }
    })

    if (totalPayment.lte(0)) throw new BusinessRuleError("Supplier payment amount must be greater than zero.")
    if (!totalPayment.eq(decimal2(approvedPayment.amount))) {
      throw new BusinessRuleError("Supplier payment release total does not match the approved amount.")
    }

    const countryPackStatus = await resolveAPCountryPackStatus(tx, {
      organizationId: parsed.organizationId,
      documentDate: paymentDate,
      taxAmount: new Prisma.Decimal(0),
      purpose: "SUPPLIER_PAYMENT",
    })

    const period = await getOpenPeriodForDate(parsed.organizationId, paymentDate, tx)
    const evidencePayload = {
      supplierId: supplier.id,
      bankAccountId: bankAccount.id,
      paymentNumber: approvedPayment.paymentNumber,
      amount: totalPayment.toFixed(2),
      method,
      allocationIds,
    }
    const documentHash = parsed.documentHash ?? approvedPayment.documentHash ?? prefixedHash(evidencePayload)
    const evidenceHash = parsed.evidenceHash ?? approvedPayment.evidenceHash ?? prefixedHash(evidencePayload)

    const payment = await tx.supplierPayment.update({
      where: { id: approvedPayment.id },
      data: {
        status: SupplierPaymentStatus.RELEASED,
        paymentDate,
        releasedById,
        releasedAt: new Date(),
        evidenceHash,
        documentHash,
        notes: parsed.notes ?? approvedPayment.notes,
        metadata: safeJson({
          ...asRecord(approvedPayment.metadata),
          gate: "011-purchasing-ap-controls",
          approvalStatus: "APPROVED",
          releaseStatus: "RELEASED",
          bankDestinationEvidence: "approved",
          releaseIdempotencyPayloadHash,
          idempotencyPayloadHash: releaseIdempotencyPayloadHash,
          countryPackStatus: countryPackStatus.countryPackStatus,
          countryCode: countryPackStatus.countryCode,
          countryPackVersion: countryPackStatus.countryPackVersion,
          countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
          taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
          withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
          operatorActionRequired: countryPackStatus.operatorActionRequired,
          countryPackErrorCode: countryPackStatus.errorCode ?? null,
          countryPackErrorMessage: countryPackStatus.errorMessage ?? null,
        }),
      },
      include: { allocations: true },
    })

    for (const allocation of allocationPlans) {
      const nextPaid = decimal2(allocation.invoice.amountPaid).plus(allocation.amount).toDecimalPlaces(2)
      const nextStatus = allocation.outstanding.minus(allocation.amount).lte(0)
        ? SupplierInvoiceStatus.PAID
        : SupplierInvoiceStatus.PAYMENT_PENDING
      await tx.supplierInvoice.update({
        where: { id: allocation.invoice.id },
        data: {
          amountPaid: nextPaid,
          status: nextStatus,
        },
      })
    }

    const balanceAfter = decimal2(supplier.currentBalance).minus(totalPayment).toDecimalPlaces(2)
    await tx.supplier.update({
      where: { id: supplier.id },
      data: { currentBalance: balanceAfter },
    })
    await tx.supplierLedgerEntry.create({
      data: {
        organizationId: parsed.organizationId,
        supplierId: supplier.id,
        entryDate: paymentDate,
        type: LedgerEntryType.PAYMENT,
        debit: new Prisma.Decimal(0),
        credit: totalPayment,
        balanceAfter,
        description: `Supplier payment ${payment.paymentNumber}`,
        referenceType: "SUPPLIER_PAYMENT",
        referenceId: payment.id,
      },
    })

    const postingResult = await createAPLedgerPosting(tx, {
      organizationId: parsed.organizationId,
      periodId: period.id,
      sourceType: AccountingSourceType.SUPPLIER_PAYMENT,
      sourceId: payment.id,
      sourceNumber: payment.paymentNumber,
      sourceDate: paymentDate,
      postingPurpose: AccountingPostingPurpose.SUPPLIER_PAYMENT,
      actorId: releasedById,
      supplierId: supplier.id,
      currency: payment.currency,
      journalType: method === PaymentMethod.CASH ? JournalType.CASH : JournalType.BANK,
      journalPrefix: "APPAY",
      memo: `Supplier payment ${payment.paymentNumber}`,
      documentHash,
      amounts: {
        sourceAmount: totalPayment,
        netAmount: totalPayment,
        grossAmount: totalPayment,
        taxAmount: new Prisma.Decimal(0),
      },
      conditionContext: { paymentMethod: method },
      blockerCode: "SUPPLIER_PAYMENT_POSTING_REVIEW",
      blockerMessage:
        "Supplier payment release requires configured SYSCOHADA AP settlement posting and reconciliation rules.",
      metadata: {
        paymentNumber: payment.paymentNumber,
        supplierId: supplier.id,
        amount: totalPayment.toFixed(2),
        method,
        countryPackStatus: countryPackStatus.countryPackStatus,
        countryPackVersion: countryPackStatus.countryPackVersion,
        countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
        withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
      },
    })
    const ledgerBatch = postingResult.ledgerBatch

    const reconciliationResult = await queueOutboundSupplierPaymentReconciliation(tx, {
      organizationId: parsed.organizationId,
      supplierPaymentId: payment.id,
      paymentNumber: payment.paymentNumber,
      supplierId: supplier.id,
      bankAccountId: bankAccount.id,
      amount: totalPayment,
      currency: payment.currency,
      paymentDate,
      method,
      ledgerPostingBatchId: ledgerBatch.id,
      ledgerStatus: postingResult.ledgerStatus,
      actorId: releasedById,
      evidenceHash: payment.evidenceHash,
      documentHash,
    })

    const eventResult = await recordBusinessEventInTx(tx, {
      organizationId: parsed.organizationId,
      eventType: "supplier.payment.released",
      eventSource: "INTERNAL",
      schemaVersion: 1,
      idempotencyKey: parsed.idempotencyKey ? `${parsed.idempotencyKey}:released` : `supplier-payment:${payment.id}`,
      payload: {
        supplierPaymentId: payment.id,
        supplierId: supplier.id,
        bankAccountId: bankAccount.id,
        amount: totalPayment.toFixed(2),
        method,
        allocationIds,
        approvedById,
        releasedById,
        ledgerPostingBatchId: ledgerBatch.id,
        journalEntryId: postingResult.journalEntryId ?? null,
        ledgerStatus: postingResult.ledgerStatus,
        paymentTransactionId: reconciliationResult.paymentTransaction.id,
        paymentExceptionId: reconciliationResult.paymentException.id,
        reconciliationStatus: reconciliationResult.reconciliationStatus,
      },
      occurredAt: paymentDate,
      actorId: releasedById,
      sourceType: AccountingSourceType.SUPPLIER_PAYMENT,
      sourceId: payment.id,
      postingBatchId: ledgerBatch.id,
      documentHash,
      metadata: {
        ledgerStatus: postingResult.ledgerStatus,
        blockerCode: postingResult.blockerCode ?? null,
        reconciliationStatus: reconciliationResult.reconciliationStatus,
        paymentTransactionId: reconciliationResult.paymentTransaction.id,
        paymentExceptionId: reconciliationResult.paymentException.id,
        countryPackStatus: countryPackStatus.countryPackStatus,
        countryPackVersion: countryPackStatus.countryPackVersion,
        countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
        gate: "011-purchasing-ap-controls",
      },
      outboxMessages: [
        {
          channel: "NOTIFICATION",
          eventName: "supplier_payment.released",
          destination: "accounting",
          payload: {
            severity: postingResult.ledgerStatus === "POSTED" ? "info" : "critical",
            supplierPaymentId: payment.id,
            supplierId: supplier.id,
            amount: totalPayment.toFixed(2),
            ledgerStatus: postingResult.ledgerStatus,
            blockerCode: postingResult.blockerCode ?? null,
          },
        },
        {
          channel: "NOTIFICATION",
          eventName: "supplier_payment.reconciliation_required",
          destination: "reconciliation",
          payload: {
            severity: "warning",
            supplierPaymentId: payment.id,
            paymentNumber: payment.paymentNumber,
            amount: totalPayment.toFixed(2),
            method,
            paymentTransactionId: reconciliationResult.paymentTransaction.id,
            paymentExceptionId: reconciliationResult.paymentException.id,
            reconciliationStatus: reconciliationResult.reconciliationStatus,
          },
        },
      ],
    })

    await markBusinessEventAppliedInTx(tx, parsed.organizationId, eventResult.event.id)
    const releasedPayment = await tx.supplierPayment.update({
      where: { id: payment.id },
      data: {
        ledgerPostingBatchId: ledgerBatch.id,
        postedBusinessEventId: eventResult.event.id,
        metadata: safeJson({
          ...asRecord(payment.metadata),
          gate: "011-purchasing-ap-controls",
          approvalStatus: "APPROVED",
          releaseStatus: "RELEASED",
          bankDestinationEvidence: "approved",
          releaseIdempotencyPayloadHash,
          idempotencyPayloadHash: releaseIdempotencyPayloadHash,
          ledgerStatus: postingResult.ledgerStatus,
          ledgerBlockerCode: postingResult.blockerCode ?? null,
          ledgerBlockerMessage: postingResult.blockerMessage ?? null,
          journalEntryId: postingResult.journalEntryId ?? null,
          accountingSourceLinkId: postingResult.accountingSourceLinkId ?? null,
          reconciliationStatus: reconciliationResult.reconciliationStatus,
          paymentTransactionId: reconciliationResult.paymentTransaction.id,
          paymentExceptionId: reconciliationResult.paymentException.id,
          reconciliationPayloadHash: reconciliationResult.payloadHash,
          countryPackStatus: countryPackStatus.countryPackStatus,
          countryCode: countryPackStatus.countryCode,
          countryPackVersion: countryPackStatus.countryPackVersion,
          countryPackResolutionHash: countryPackStatus.countryPackResolutionHash,
          taxTreatmentStatus: countryPackStatus.taxTreatmentStatus,
          withholdingTreatmentStatus: countryPackStatus.withholdingTreatmentStatus,
          operatorActionRequired: countryPackStatus.operatorActionRequired,
          countryPackErrorCode: countryPackStatus.errorCode ?? null,
          countryPackErrorMessage: countryPackStatus.errorMessage ?? null,
        }),
      },
      include: { allocations: true },
    })

    await writeAudit(tx, {
      organizationId: parsed.organizationId,
      entityType: "SupplierPayment",
      entityId: payment.id,
      action: "SUPPLIER_PAYMENT_RELEASED",
      actorId: releasedById,
      changes: {
        after: {
          supplierId: supplier.id,
          amount: totalPayment.toFixed(2),
          paymentNumber: payment.paymentNumber,
          approvedById,
          releasedById,
          ledgerPostingBatchId: ledgerBatch.id,
          businessEventId: eventResult.event.id,
          ledgerStatus: postingResult.ledgerStatus,
          paymentTransactionId: reconciliationResult.paymentTransaction.id,
          paymentExceptionId: reconciliationResult.paymentException.id,
          reconciliationStatus: reconciliationResult.reconciliationStatus,
        },
      },
    })

    return {
      supplierPayment: releasedPayment,
      postingBatchId: ledgerBatch.id,
      businessEventId: eventResult.event.id,
      ledgerStatus: postingResult.ledgerStatus,
      paymentTransactionId: reconciliationResult.paymentTransaction.id,
      paymentExceptionId: reconciliationResult.paymentException.id,
      reconciliationStatus: reconciliationResult.reconciliationStatus,
    }
  })
}

export async function releaseSupplierPaymentWithControls(
  input: ReleaseSupplierPaymentInput,
  control: APControlActorContext,
  client: DbClient = db,
) {
  const parsed = releaseSupplierPaymentInputSchema.parse(input)
  const releasedById = parsed.releasedById
  assertControlActorMatches(control, parsed.organizationId, [releasedById])

  const subject = await loadSupplierPaymentControlSubject(client, parsed.organizationId, parsed.supplierPaymentId)
  const controlInput = sensitiveInput(control, {
    action: "supplier.payment.release",
    resourceType: "SupplierPayment",
    resourceId: parsed.supplierPaymentId,
    subjectActorId: subject?.requestedById ?? null,
    metadata: {
      supplierId: subject?.supplierId ?? parsed.supplierId,
      bankAccountId: subject?.bankAccountId ?? parsed.bankAccountId,
      approvedById: subject?.approvedById ?? parsed.approvedById,
      status: subject?.status,
    },
  })

  await auditDeniedSensitiveAction(client, controlInput)
  return inTransaction(client, async (tx) => {
    const request = await readVerifiedPaymentApproval(tx, parsed.organizationId, parsed.supplierPaymentId)
    if (parsed.paymentDate && new Date(parsed.paymentDate).toISOString().slice(0, 10) !== request.draft.paymentDate) throw new BusinessRuleError("Changed payment dates require a new reviewed request.", "REVIEW_REQUIRED")
    if ((parsed.notes !== undefined && parsed.notes !== request.payment.notes) || (parsed.documentHash !== undefined && parsed.documentHash !== request.payment.documentHash) || (parsed.evidenceHash !== undefined && parsed.evidenceHash !== request.payment.evidenceHash)) throw new BusinessRuleError("Changed payment evidence or notes require a new reviewed request.", "REVIEW_REQUIRED")
    await auditAllowedSensitiveAction(tx, controlInput)
    return releaseSupplierPayment(
      {
        ...parsed,
        supplierId: subject?.supplierId ?? parsed.supplierId,
        bankAccountId: subject?.bankAccountId ?? parsed.bankAccountId,
        requestedById: subject?.requestedById ?? parsed.requestedById,
        approvedById: subject?.approvedById ?? parsed.approvedById,
        releasedById,
      },
      tx,
    )
  })
}
