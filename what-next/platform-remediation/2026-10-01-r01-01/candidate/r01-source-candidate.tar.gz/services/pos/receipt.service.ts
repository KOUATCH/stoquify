import {
  AccountingSourceType,
  FiscalDocumentStatus,
  FiscalDocumentType,
  type Prisma,
} from "@prisma/client"
import { db } from "@/prisma/db"
import { queueWhatsAppReceiptDeliveryInTx } from "@/services/communication/whatsapp-receipt-outbox.service"
import { sendWhatsAppReceipt } from "@/services/communication/whatsapp-receipt.provider"
import { BusinessRuleError, NotFoundError } from "@/services/_shared/action-errors"
import { moneyToNumber } from "./money"
import {
  getSalesReceiptSchema,
  salesReceiptLookupSchema,
  sendReceiptServiceSchema,
  type ReceiptChannel,
  type ReceiptLocale,
  type SendReceiptServiceInput,
} from "./pos.schemas"
import {
  normalizeReceiptDestination,
  receiptDeliveryProviderMethod,
  type DeliverableReceiptChannel,
} from "./receipt-channels"
import {
  assertPublicReceiptAccessToken,
  issuePublicReceiptAccessToken,
} from "./public-receipt-token-registry.service"

export type ReceiptDeliveryStatus = "PENDING" | "SENT" | "FAILED" | "SKIPPED"

export type ReceiptLegalDeliveryStatus =
  | "NOT_CREATED"
  | "CERTIFIED"
  | "ALLOWED_WITH_STATUS"
  | "BLOCKED_UNTIL_CERTIFIED"
  | "PENDING_REGULATORY_PROCESSING"
  | "REQUIRES_EXPERT_REVIEW"

export type ReceiptCertificationStatus = {
  fiscalDocumentId: string | null
  documentType: string | null
  fiscalDocumentStatus: string
  submissionId: string | null
  submissionStatus: string | null
  authorityChannel: string | null
  authorityReference: string | null
  legalNumber: string | null
  provisionalNumber: string | null
  certifiedAt: string | null
  rejectedAt: string | null
  rejectionReason: string | null
  certificationArtifactHash: string | null
  countryCode: string | null
  countryPackVersion: string | null
  countryPackVerificationStatus: string | null
  legalDeliveryStatus: ReceiptLegalDeliveryStatus
  legalDeliveryBlocked: boolean
  legalDeliveryBlockReason: string | null
  fiscalizationRequestId?: string | null
  regulatoryProcessingStatus?: string
}

export type SalesReceiptPayload = {
  receipt: {
    id: string
    orderNumber: string
    customerName: string
    customerEmail?: string
    customerPhone?: string
    total: number
    subtotal: number
    tax: number
    taxRate: number
    discount: number
    paymentMethod: string
    paymentStatus: string
    cashier: string
    terminal: string
    sessionNumber: string
    locale: ReceiptLocale
    createdAt: string
    items: Array<{
      id: string
      name: string
      sku: string
      quantity: number
      unitPrice: number
      totalPrice: number
      taxRate: number
    }>
    payments: Array<{
      id: string
      paymentNumber: string
      method: string
      amount: number
      status: string
      cashTendered?: number
      changeGiven?: number
      createdAt: string
    }>
  }
  certification: ReceiptCertificationStatus
  business: {
    name: string
    address: string
    city: string
    phone: string
    email: string
    website: string
    taxId: string
    currency: string
  }
  location: {
    name: string
    address: string
    city: string
    phone: string
  }
  generatedAt: string
  digitalReceiptUrl: string
}

export type ReceiptDeliveryResult = {
  channel: ReceiptChannel
  status: ReceiptDeliveryStatus
  destination?: string
  providerReference?: string
  destinationHash?: string
  retryable: boolean
  message: string
  digitalReceiptUrl: string
}

export type ReceiptDeliveryProviderInput = {
  receipt: SalesReceiptPayload
  destination?: string
  locale: ReceiptLocale
  organizationId: string
  userId: string
}

export interface ReceiptDeliveryProvider {
  sendPrintReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult>
  sendEmailReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult>
  sendSmsReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult>
  sendWhatsAppReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult>
}

class StubReceiptDeliveryProvider implements ReceiptDeliveryProvider {
  async sendPrintReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult> {
    return this.pending("PRINT", input)
  }

  async sendEmailReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult> {
    return this.pending("EMAIL", input)
  }

  async sendSmsReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult> {
    return this.pending("SMS", input)
  }

  async sendWhatsAppReceipt(input: ReceiptDeliveryProviderInput): Promise<ReceiptDeliveryResult> {
    return sendWhatsAppReceipt(input)
  }

  private async pending(
    channel: DeliverableReceiptChannel,
    input: ReceiptDeliveryProviderInput,
  ): Promise<ReceiptDeliveryResult> {
    return {
      channel,
      status: "PENDING",
      destination: input.destination,
      providerReference: `stub-${channel.toLowerCase()}-${Date.now()}`,
      retryable: false,
      message: `${channel} receipt provider is not configured; delivery attempt was recorded.`,
      digitalReceiptUrl: input.receipt.digitalReceiptUrl,
    }
  }
}

const defaultReceiptProvider = new StubReceiptDeliveryProvider()

function displayName(firstName?: string | null, lastName?: string | null, fallback?: string | null) {
  return [firstName, lastName].filter(Boolean).join(" ") || fallback || "Cashier"
}

function digitalReceiptUrl(salesOrderId: string, receiptToken?: string | null) {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, "")
  const encodedSalesOrderId = encodeURIComponent(salesOrderId)
  if (!receiptToken) return ""

  const tokenQuery = `?token=${encodeURIComponent(receiptToken)}`
  return baseUrl
    ? `${baseUrl}/digital-receipt/${encodedSalesOrderId}${tokenQuery}`
    : `/digital-receipt/${encodedSalesOrderId}${tokenQuery}`
}

function tenderLabel(method: string) {
  return method === "CREDIT" ? "ON_ACCOUNT" : method
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

function certificationPolicyValue(
  policy: Prisma.JsonValue | null | undefined,
  key: string,
) {
  if (!isRecord(policy)) return null
  const value = policy[key]
  return typeof value === "string" ? value : null
}

function emptyReceiptCertificationStatus(
  request?: {
    id: string
    status: string
    lastErrorMessage: string | null
  } | null,
): ReceiptCertificationStatus {
  const pending = Boolean(request)
  return {
    fiscalDocumentId: null,
    documentType: null,
    fiscalDocumentStatus: pending
      ? "PENDING_REGULATORY_PROCESSING"
      : "NOT_CREATED",
    submissionId: null,
    submissionStatus: null,
    authorityChannel: null,
    authorityReference: null,
    legalNumber: null,
    provisionalNumber: null,
    certifiedAt: null,
    rejectedAt: null,
    rejectionReason: null,
    certificationArtifactHash: null,
    countryCode: null,
    countryPackVersion: null,
    countryPackVerificationStatus: null,
    legalDeliveryStatus: pending
      ? "PENDING_REGULATORY_PROCESSING"
      : "NOT_CREATED",
    legalDeliveryBlocked: false,
    legalDeliveryBlockReason: request?.lastErrorMessage ?? null,
    fiscalizationRequestId: request?.id ?? null,
    regulatoryProcessingStatus: request?.status ?? "NOT_REQUESTED",
  }
}

function resolveReceiptLegalDeliveryStatus(input: {
  fiscalDocumentStatus: string
  certificationPolicySnapshot: Prisma.JsonValue | null
}) {
  if (input.fiscalDocumentStatus === FiscalDocumentStatus.CERTIFIED) {
    return {
      legalDeliveryStatus: "CERTIFIED" as const,
      legalDeliveryBlocked: false,
      legalDeliveryBlockReason: null,
    }
  }

  const legalDeliveryWhenUncertified = certificationPolicyValue(
    input.certificationPolicySnapshot,
    "legalDeliveryWhenUncertified",
  )

  if (legalDeliveryWhenUncertified === "BLOCK") {
    return {
      legalDeliveryStatus: "BLOCKED_UNTIL_CERTIFIED" as const,
      legalDeliveryBlocked: true,
      legalDeliveryBlockReason:
        "Country-pack policy blocks legal receipt delivery until certification or approved fallback evidence exists.",
    }
  }

  if (legalDeliveryWhenUncertified === "ALLOW_WITH_STATUS") {
    return {
      legalDeliveryStatus: "ALLOWED_WITH_STATUS" as const,
      legalDeliveryBlocked: false,
      legalDeliveryBlockReason: null,
    }
  }

  return {
    legalDeliveryStatus: "REQUIRES_EXPERT_REVIEW" as const,
    legalDeliveryBlocked: true,
    legalDeliveryBlockReason:
      "Country-pack policy requires expert review before legal receipt delivery can be treated as allowed.",
  }
}

async function getReceiptCertificationStatus(
  organizationId: string,
  salesOrderId: string,
): Promise<ReceiptCertificationStatus> {
  const fiscalDocument = await db.fiscalDocument.findFirst({
    where: {
      organizationId,
      sourceType: AccountingSourceType.POS_SALE,
      sourceId: salesOrderId,
      documentType: FiscalDocumentType.POS_RECEIPT,
    },
    include: {
      submissions: {
        orderBy: { createdAt: "desc" },
        take: 1,
      },
    },
    orderBy: { createdAt: "desc" },
  })

  if (!fiscalDocument) {
    if (!("businessEventOutbox" in db)) {
      return emptyReceiptCertificationStatus()
    }

    const request = await db.businessEventOutbox.findFirst({
      where: {
        organizationId,
        channel: "FISCALIZATION",
        businessEvent: {
          is: {
            sourceType: "POS_SALE",
            sourceId: salesOrderId,
          },
        },
      },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        status: true,
        lastErrorMessage: true,
      },
    })

    return emptyReceiptCertificationStatus(request)
  }

  const submission = fiscalDocument.submissions[0] ?? null
  const legalDelivery = resolveReceiptLegalDeliveryStatus({
    fiscalDocumentStatus: fiscalDocument.status,
    certificationPolicySnapshot: fiscalDocument.certificationPolicySnapshot,
  })

  return {
    fiscalDocumentId: fiscalDocument.id,
    documentType: fiscalDocument.documentType,
    fiscalDocumentStatus: fiscalDocument.status,
    submissionId: submission?.id ?? null,
    submissionStatus: submission?.status ?? null,
    authorityChannel: fiscalDocument.authorityChannel,
    authorityReference: fiscalDocument.authorityReference,
    legalNumber: fiscalDocument.legalNumber,
    provisionalNumber: fiscalDocument.provisionalNumber,
    certifiedAt: fiscalDocument.certifiedAt?.toISOString() ?? null,
    rejectedAt: fiscalDocument.rejectedAt?.toISOString() ?? null,
    rejectionReason: fiscalDocument.rejectionReason,
    certificationArtifactHash: fiscalDocument.certificationArtifactHash,
    countryCode: fiscalDocument.countryCode,
    countryPackVersion: fiscalDocument.countryPackVersion,
    countryPackVerificationStatus: fiscalDocument.countryPackVerificationStatus,
    ...legalDelivery,
  }
}

function cleanJson(input: Record<string, unknown>): Prisma.JsonObject {
  return Object.fromEntries(Object.entries(input).filter(([, value]) => value !== undefined)) as Prisma.JsonObject
}

function optionalStringField(source: unknown, key: string) {
  if (!isRecord(source)) return null
  const value = source[key]
  return typeof value === "string" ? value : null
}

type FindSalesReceiptOptions = {
  includeCustomerContact?: boolean
  receiptAccessToken?: string | null
  issuePublicReceiptToken?: boolean
}

async function findSalesReceipt(
  salesOrderId: string,
  organizationId?: string,
  options: FindSalesReceiptOptions = {},
): Promise<SalesReceiptPayload> {
  const includeCustomerContact = options.includeCustomerContact !== false
  const privatePersonSelect = includeCustomerContact ? { email: true } : {}
  const privateCustomerSelect = includeCustomerContact ? { email: true, phone: true, currentBalance: true } : {}

  const sale = await db.salesOrder.findFirst({
    where: {
      id: salesOrderId,
      deletedAt: null,
      ...(organizationId ? { organizationId } : {}),
    },
    include: {
      organization: {
        select: {
          id: true,
          name: true,
          address: true,
          country: true,
          state: true,
          currency: true,
          slug: true,
          defaultLocale: true,
        },
      },
      location: {
        select: {
          id: true,
          name: true,
          address: true,
          phone: true,
          email: true,
        },
      },
      terminal: {
        select: {
          id: true,
          name: true,
          terminalNumber: true,
        },
      },
      session: {
        select: {
          id: true,
          sessionNumber: true,
          user: {
            select: {
              firstName: true,
              lastName: true,
              ...privatePersonSelect,
            },
          },
        },
      },
      createdBy: {
        select: {
          firstName: true,
          lastName: true,
          ...privatePersonSelect,
        },
      },
      customer: {
        select: {
          id: true,
          name: true,
          preferredLocale: true,
          ...privateCustomerSelect,
        },
      },
      lines: {
        include: {
          item: {
            select: {
              id: true,
              nameEn: true,
              nameFr: true,
              sku: true,
            },
          },
        },
        orderBy: { createdAt: "asc" },
      },
      payments: {
        where: { deletedAt: null },
        orderBy: { createdAt: "asc" },
        select: {
          id: true,
          paymentNumber: true,
          method: true,
          amount: true,
          status: true,
          cashTendered: true,
          changeGiven: true,
          createdAt: true,
        },
      },
    },
  })

  if (!sale || sale.status === "DRAFT" || sale.status === "CANCELLED") {
    throw new NotFoundError("Receipt not found")
  }

  const locale = (sale.customer?.preferredLocale || sale.organization.defaultLocale || "EN") as ReceiptLocale
  const cashier = sale.session?.user
    ? displayName(sale.session.user.firstName, sale.session.user.lastName, optionalStringField(sale.session.user, "email"))
    : displayName(sale.createdBy?.firstName, sale.createdBy?.lastName, optionalStringField(sale.createdBy, "email"))
  const primaryPayment = sale.payments[0]
  const firstTaxRate = sale.lines.find((line) => moneyToNumber(line.taxRate) > 0)?.taxRate
  const certification = await getReceiptCertificationStatus(sale.organization.id, sale.id)
  let receiptAccessToken = options.receiptAccessToken ?? null

  if (!receiptAccessToken && options.issuePublicReceiptToken !== false) {
    try {
      const issuedToken = await issuePublicReceiptAccessToken({
        organizationId: sale.organization.id,
        salesOrderId: sale.id,
      })
      receiptAccessToken = issuedToken.token
    } catch (error) {
      if (error instanceof BusinessRuleError) {
        receiptAccessToken = null
      } else {
        throw new BusinessRuleError("Receipt access token could not be issued safely.")
      }
    }
  }

  return {
    receipt: {
      id: sale.id,
      orderNumber: sale.orderNumber,
      customerName: sale.customer.name,
      ...(includeCustomerContact
        ? {
            customerEmail: optionalStringField(sale.customer, "email") || "",
            customerPhone: optionalStringField(sale.customer, "phone") || "",
          }
        : {}),
      total: moneyToNumber(sale.total),
      subtotal: moneyToNumber(sale.subtotal),
      tax: moneyToNumber(sale.taxAmount),
      taxRate: moneyToNumber(firstTaxRate),
      discount: moneyToNumber(sale.discount),
      paymentMethod: primaryPayment ? tenderLabel(primaryPayment.method) : sale.paymentStatus,
      paymentStatus: sale.paymentStatus,
      cashier,
      terminal: sale.terminal?.terminalNumber || sale.terminal?.name || "",
      sessionNumber: sale.session?.sessionNumber || "",
      locale,
      createdAt: sale.orderDate.toISOString(),
      items: sale.lines.map((line) => ({
        id: line.id,
        name: locale === "FR" ? line.item.nameFr || line.item.nameEn : line.item.nameEn,
        sku: line.item.sku,
        quantity: moneyToNumber(line.quantity),
        unitPrice: moneyToNumber(line.unitPrice),
        totalPrice: moneyToNumber(line.lineTotal),
        taxRate: moneyToNumber(line.taxRate),
      })),
      payments: sale.payments.map((payment) => ({
        id: payment.id,
        paymentNumber: payment.paymentNumber,
        method: tenderLabel(payment.method),
        amount: moneyToNumber(payment.amount),
        status: payment.status,
        cashTendered: payment.cashTendered ? moneyToNumber(payment.cashTendered) : undefined,
        changeGiven: payment.changeGiven ? moneyToNumber(payment.changeGiven) : undefined,
        createdAt: payment.createdAt.toISOString(),
      })),
    },
    certification,
    business: {
      name: sale.organization.name,
      address: sale.organization.address || "",
      city: [sale.organization.state, sale.organization.country].filter(Boolean).join(", "),
      phone: sale.location.phone || "",
      email: sale.location.email || "",
      website: "",
      taxId: "",
      currency: sale.organization.currency,
    },
    location: {
      name: sale.location.name,
      address: sale.location.address || "",
      city: "",
      phone: sale.location.phone || "",
    },
    generatedAt: new Date().toISOString(),
    digitalReceiptUrl: digitalReceiptUrl(sale.id, receiptAccessToken),
  }
}

async function recordDeliveryAudit(
  input: SendReceiptServiceInput,
  receipt: SalesReceiptPayload,
  result: ReceiptDeliveryResult,
) {
  await db.auditLog.create({
    data: {
      entityType: "SalesOrder",
      entityId: input.salesOrderId,
      action: `RECEIPT_${input.channel}`,
      organizationId: input.organizationId,
      userId: input.userId,
      changes: cleanJson({
        channel: result.channel,
        status: result.status,
        destination: result.destination,
        providerReference: result.providerReference,
        destinationHash: result.destinationHash,
        retryable: result.retryable,
        message: result.message,
        orderNumber: receipt.receipt.orderNumber,
        digitalReceiptPath: `/digital-receipt/${encodeURIComponent(input.salesOrderId)}`,
      }),
    },
  })
}

export async function getSalesReceipt(rawInput: unknown): Promise<SalesReceiptPayload> {
  const input = getSalesReceiptSchema.parse(rawInput)
  return findSalesReceipt(input.salesOrderId, input.organizationId)
}

/**
 * Produces the private, non-statutory receipt snapshot embedded in the POS
 * commit result. It deliberately excludes customer contact data and never
 * issues a bearer-style public receipt token, making the envelope safe to
 * retain for exact idempotent replay.
 */
export async function getPOSSaleCommitReceipt(rawInput: unknown): Promise<SalesReceiptPayload> {
  const input = getSalesReceiptSchema.parse(rawInput)
  return findSalesReceipt(input.salesOrderId, input.organizationId, {
    includeCustomerContact: false,
    issuePublicReceiptToken: false,
  })
}

export async function getPublicSalesReceipt(rawInput: unknown): Promise<SalesReceiptPayload> {
  const input = salesReceiptLookupSchema.parse(rawInput)

  const access = await assertPublicReceiptAccessToken({
    token: input.receiptAccessToken,
    salesOrderId: input.salesOrderId,
  })

  const payload = await findSalesReceipt(input.salesOrderId, access.organizationId, {
    includeCustomerContact: false,
    receiptAccessToken: input.receiptAccessToken,
    issuePublicReceiptToken: false,
  })

  // Provider rejection and outbox error text are operational diagnostics, not
  // customer receipt content. Preserve the public status without exposing them.
  return {
    ...payload,
    certification: {
      ...payload.certification,
      rejectionReason: null,
      legalDeliveryBlockReason: payload.certification.legalDeliveryBlocked
        ? "The fiscal document is not available for delivery. Contact the store."
        : null,
    },
  }
}

export async function sendReceipt(
  rawInput: unknown,
  provider: ReceiptDeliveryProvider = defaultReceiptProvider,
): Promise<ReceiptDeliveryResult> {
  const input = sendReceiptServiceSchema.parse(rawInput)
  const receipt = await findSalesReceipt(input.salesOrderId, input.organizationId)
  const locale = input.locale || receipt.receipt.locale

  if (input.channel === "NONE") {
    const result: ReceiptDeliveryResult = {
      channel: "NONE",
      status: "SKIPPED",
      retryable: false,
      message: "Receipt delivery skipped by cashier.",
      digitalReceiptUrl: receipt.digitalReceiptUrl,
    }
    await recordDeliveryAudit(input, receipt, result)
    return result
  }

  if (receipt.certification.legalDeliveryBlocked) {
    const result: ReceiptDeliveryResult = {
      channel: input.channel,
      status: "FAILED",
      retryable: false,
      message:
        receipt.certification.legalDeliveryBlockReason ||
        "Receipt delivery is blocked until fiscal certification is complete.",
      digitalReceiptUrl: receipt.digitalReceiptUrl,
    }
    await recordDeliveryAudit(input, receipt, result)
    throw new BusinessRuleError(result.message)
  }

  const destination = normalizeReceiptDestination(input.channel, input.destination)

  if (input.channel === "WHATSAPP") {
    return db.$transaction((tx) =>
      queueWhatsAppReceiptDeliveryInTx(tx, {
        receipt,
        destination,
        locale,
        organizationId: input.organizationId,
        userId: input.userId,
      }),
    )
  }

  const providerInput = {
    receipt,
    destination,
    locale,
    organizationId: input.organizationId,
    userId: input.userId,
  }
  const providerMethod = receiptDeliveryProviderMethod(input.channel)
  const result = await provider[providerMethod](providerInput)

  await recordDeliveryAudit(input, receipt, result)
  return result
}
