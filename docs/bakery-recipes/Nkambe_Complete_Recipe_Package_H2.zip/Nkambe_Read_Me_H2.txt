NKAMBE BAKERY ANTHOLOGY H2 — START HERE

Read Nkambe_Harmonized_Recipe_Booklet_H2.pdf (358 pages, 138 working recipe/component cards).
For baguette production only: Nkambe_Baguette_Production_Planning_H2.pdf (15 pages).
All volumes together: Nkambe_Complete_Harmonized_Collection_H2.pdf (1137 pages).

Edit the RTF files in Word or a compatible editor. Markdown copies are also included.
Use Nkambe_Baguette_Production_Planner_H2.xlsx for editable batches, clocks, dispatch and costing.
Use Nkambe_Editable_Recipe_and_Costing_Registers_H2.xlsx for the general recipe collection.
Read the reader guide and verification record for instructions and limitations.

The exact staggered baguette source was recovered. Its yield, tray/load and timing conflicts are corrected and traceable. The new BAG-H2-01 direct-dough formula remains separate from the poolish and soft-baguette recipes.
All prior recipe coverage and source evidence are retained. The owner-workbook EDC/butter correction, omitted additives, confirmed ingredient prices and safety controls remain in force.

All working recipes and production schedules require physical trials. Missing costs remain unknown. Do not interpret conditional output, finished weight, shelf life or profit illustrations as measured results.
PDF/CSV snapshots do not recalculate. Open and recalculate the workbooks after editing. Native Excel compatibility was not tested.
