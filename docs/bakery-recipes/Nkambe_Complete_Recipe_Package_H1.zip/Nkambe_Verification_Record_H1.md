# Nkambe H1 verification record

8 October 2026

Arithmetic audit: 137 working cards, 914 ingredient rows and 254 historical formula patterns reconciled. Ingredient inputs, retained numerical revisions, commercial scaling, cost extensions and acyclic prepared-component references passed. Unknown prices remain unresolved.

Combined PDF: 1121 pages; 1522 internal-link destinations checked against the component volumes. Printed page numbering remains local to each volume.

| PDF | Pages | Boundary overflow | Missing registered IDs |
|---|---|---|---|
| Nkambe_Formula_Comparison_H1.pdf | 359 | 0 | 0 |
| Nkambe_Research_Recipe_Archive_H1.pdf | 403 | 0 | 0 |
| Nkambe_Harmonized_Recipe_Booklet_H1.pdf | 344 | 0 | 0 |
| Nkambe_Reader_Guide_and_Source_Register_H1.pdf | 15 | 0 | 0 |

Visual checks: all working-book pages viewed as contact overviews; selected working, comparison, archive and source-register pages inspected at readable resolution. This is not a claim that all OCR characters or historical quantities were visually verified. Continuation pages and record counts do not establish unique-product counts.

The workbook structure and formula references were checked. No native Excel recalculation was run; open it in a spreadsheet application to recalculate its formulas. Original workbook formula cells are retained as text in the historical sheet. CSV files hold static snapshots.

Production trials, shelf-life validation, missing price quotes, full operating costs, Top Milk identity and unresolved equipment/process specifications remain open. Research and historical records stay on hold until their listed issues are resolved.
