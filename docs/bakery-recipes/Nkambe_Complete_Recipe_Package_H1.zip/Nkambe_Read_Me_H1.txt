NKAMBE BAKERY RECIPE COLLECTION H1 — 8 October 2026

START: Nkambe_Harmonized_Recipe_Booklet_H1.pdf (344 pages, 137 working recipe/component cards).
ALL IN ONE: Nkambe_Complete_Harmonized_Collection_H1.pdf (1121 pages, guide + three volumes).
EDIT: the RTF booklet in Word and the XLSX registers in Excel. Markdown and CSV alternatives are included.

The collection retains 254 historical numerical formula patterns, 322 research records and 79 earlier handbook variant records. These counts include components, overlapping sources and held records; they are not a count of unique saleable products.

Owner workbook EDC/butter = margarine. Milk tantalizer and improver omitted in revisions. Originals retained for comparison.
Confirmed purchase prices are used. Unknown prices stay blank or UNPRICED. Full operating costs, sale prices and practical validation remain open.
Read the guide for source paths, editing instructions, limits and release priorities. Read C01–C05 before testing perishable products.

Verification: 137 cards and 914 ingredient lines checked; 254 historical sums/revisions checked; 1522 merged internal links checked. Page bounds checked for the three volumes. Visual overview and sample-page review performed; not every OCR numeral has been visually verified. No native Excel recalculation or production validation is claimed.

PDF printed page numbers restart per volume. Use PDF bookmarks to select a volume and its own clickable contents to reach a recipe.
